# 84339 - BASI DI DATI AVANZATE

## Anno Accademico
                2024/2025

- Docente:
Matteo Golfarelli
- Crediti formativi:
                        6
- SSD:
                        ING-INF/05
- Lingua di insegnamento:
                        Italiano

- Moduli:
Matteo Golfarelli
                            (Modulo 1)
                        
                        
                            Alessandra Lumini
                            (Modulo 2)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 19/02/2025 al 28/03/2025
- Orario delle lezioni (Modulo 2)

dal 02/04/2025 al 21/05/2025

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente possiede competenze avanzate e capacità pratiche relativamente alle tecnologie legate alle basi di dati relazionali e non relazionali, nonché la capacità di realizzare applicazioni centrate sull'utilizzo di DBMS.

## Contenuti

----------    Progettazione di DBMS NoSQL     ----------

1. Modelli dati non relazionali (Document-based, Graph-based, Column oriented)
2. Architetture per DBMS non relazionali: Cluster, Sharding e persistenza
3. Progettazione dei dati in DBMS NoSQL
4. Esercitazioni di laboratorio con MongoDB

---------- Programmazione e gestione di DBMS Relazionali ----------

1. Amministrazione di basi di dati
2. Programmazione avanzata di basi di dati e basi di dati attive
3. Ottimizzazione delle prestazioni

## Testi/Bibliografia

Dispense a cura del docente

R. van der Lans Introduzione a SQL . Addison-Wesley, 2001.

R. A. Elmasri, S.B. Navathe. Sistemi di basi di dati - Complementi. Pearson, 2005.

Making Sense of NoSQ. Daniel G. McCreary and Ann M. Kelly. Manning, 2013.

Martin J. Fowler &amp; Pramodkumar J. Sadalage. Nosql Distilled: A Brief Guide to the Emerging World of Polyglot Persistence. Addison Wesley, 2009.

## Metodi didattici

Lezioni in aula ed esercitazioni in laboratorio

## Modalità di verifica e valutazione dell'apprendimento

L'esame consta di due prove scritte. La prima prova è pratica e viene svolta in laboratorio, mira a vautare le capacità dello studente rispetto ai sistemi e alle tecnologie informatiche utilizzate durante il corso. La seconda prova si compone di un insieme di domande aperte su tutto il programma del corso. Durante la prima prova lo studente potrà consultare testi e appunti.

La realizzazione di un elaborato è opzionale e fornirà punti addizionali per il voto finale.

i voti vengono assegnati in base a una valutazione complessiva delle conoscenze, competenze, capacità di presentazione e discussione delle tematiche trattate. I range di voti corrispondono possono essere descritti come segue:

18-23: preparazione e capacità di analisi sufficienti ma relative ad un numero limitato di argomenti affrontati nel corso, utilizzo di un linguaggio complessivamente corretto;

24-27: preparazione tecnicamente adeguata ma con alcuni limiti rispetto agli argomenti trattati, capacità di analisi buone, anche se non particolarmente articolate, espresse in un linguaggio corretto;

28-30: ottima conoscenza di un ampio numero di temi affrontati nel corso, buone capacità di analisi e di critica, padronanza della terminologia specifica;

30L: conoscenza eccellente e molto approfondita ed esaustiva dei temi affrontati nel corso, capacità di analisi critica e di collegamento, padronanza della terminologia specifica.

Nel caso in cui, causa pandemia, non sia possibile svolgere gli esami in presenza ma solo a distanza la stturuttura dell'esame non cambierà.

## Strumenti a supporto della didattica

Le esercitazioni saranno svolte utilizzando il DBMS Oracle 11g e il DBMS MongoDB

## Link ad altre eventuali informazioni

http://bias.csr.unibo.it/golfarelli/BDA/index.htm

## Orario di ricevimento

Consulta il sito web di
                    
                        Matteo Golfarelli

Consulta il sito web di
                        
                            Alessandra Lumini