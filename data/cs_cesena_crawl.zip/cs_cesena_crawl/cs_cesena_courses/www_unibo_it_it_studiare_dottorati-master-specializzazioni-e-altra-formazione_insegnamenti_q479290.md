# 17634 - VISIONE ARTIFICIALE

## Anno Accademico
                2024/2025

- Docente:
Raffaele Cappelli
- Crediti formativi:
                        6
- SSD:
                        ING-INF/05
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 20/02/2025 al 30/05/2025

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente conosce le principali aree applicative della visione artificiale e gli algoritmi di base per l’analisi di immagini e il riconoscimento di oggetti.

## Contenuti

- Strumenti di base per l'elaborazione delle immagini (modelli di colore, convoluzione, topologia digitale e morfologia matematica)
- Tecniche per individuare e segmentare oggetti nelle immagini
- Metodi per il rilevamento e l'inseguimento di oggetti nei video
- Riconoscimento di oggetti da immagini e video

## Testi/Bibliografia

Richard Szeliski, Computer Vision: Algorithms and Applications, 2nd ed., 2022 (il PDF può essere richiesto qui)

## Metodi didattici

- Lezioni frontali
- Esercitazioni guidate in laboratorio

## Modalità di verifica e valutazione dell'apprendimento

La verifica dell'apprendimento avviene attraverso una prova scritta della durata di 90 minuti, durante la quale non è ammesso l'uso di libri, appunti, calcolatrici, o supporti elettronici. La prova d'esame mira a verificare il raggiungimento dei seguenti obiettivi didattici: 1) conoscenza approfondita degli algoritmi e delle tecniche illustrate durante il corso; 2) capacità di implementare tali algoritmi e di applicarli all'interno di programmi che elaborino immagini e video; 3) comprensione del funzionamento di base delle librerie software utilizzate durante le esercitazioni in laboratorio. A tale fine, la prova scritta si compone sia domande teoriche che di esercizi pratici, nei quali si chiede allo studente di implementare algoritmi o porzioni di algoritmi, sfruttando eventualmente alcune funzionalità delle librerie software utilizzate durante le esercitazioni in laboratorio.

## Strumenti a supporto della didattica

Dispense a cura del docente

## Orario di ricevimento

Consulta il sito web di
                    
                        Raffaele Cappelli

### SDGs

<!-- image -->

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.