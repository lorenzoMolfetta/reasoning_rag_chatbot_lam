# 08574 - SISTEMI OPERATIVI

## Anno Accademico
                2024/2025

- Docente:
Vittorio Ghini
- Crediti formativi:
                        12
- SSD:
                        INF/01
- Lingua di insegnamento:
                        Italiano

- Moduli:
Vittorio Ghini
                            (Modulo 1)
                        
                        
                            Stefano Ferretti
                            (Modulo 2)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

                            
                                


Valido anche per
                                
                                    
                                    
                                    Laurea in
                                    
                                        Ingegneria elettronica (cod. 5834)
                                    


                                    
                                    Laurea in
                                    
                                        Ingegneria biomedica (cod. 9082)

- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 19/09/2024 al 17/12/2024

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente acquisisce le problematiche teoriche e pratiche inerenti al progetto di moderni sistemi operativi, approfondendone la struttura, l'implementazione e il funzionamento.

## Contenuti

Introduzione e prospettiva storica.

Richiami di Linguaggio ANSI C.

Shell e shell scripting.

Thread e processi.

Programmazione concorrente.

Deadlock, Starvation e Busy Waiting.

Inter Process Communications.

Gestione della CPU.

Gestione della memoria centrale.

Gestione della memoria secondaria e file system.

Gestione dell'I/O.

Protezione e sicurezza.

Casi applicativi: i sistemi Linux e Windows.

Kernel Linux.

Introduzione alla virtualizzazione, container, docker, kubernetes, servizi IaaS e PaaS.

## Testi/Bibliografia

Silberschatz, P.B. Galvin, G. Gagne, Sistemi operativi. Concetti ed esempi, dalla nona edizione in avanti, Pearson Education Italia (2014)

## Metodi didattici

Lezioni frontali e esercitazioni in laboratorio informatico. I fondamenti teorici alla base dei moderni sistemi operativi sono esposti durante le lezioni frontali. Numerosi esercizi pratici sono svolti in aula ad anticipare gli esercizi che gli studenti dovranno successivamente svolgere nelle esercitazioni guidate in laboratorio, con la supervisione del docente. Estensioni delle esercitazioni sono regolarmente suggerite, e le soluzioni pubblicate sul web, allo scopo di promuovere e favorire lo studio individuale e le attività di laboratorio autonome. Alcune esercitazioni in laboratorio sono rivolte a simulare lo svolgimento della prova pratica che costituirà una delle due prove d'esame.

In considerazione della tipologia di attività e dei metodi didattici adottati, la frequenza di questa attività formativa richiede la preventiva partecipazione di tutti gli studenti ai moduli 1 e 2 di formazione sulla sicurezza nei luoghi di studio, [ https://corsi.unibo.it/laurea/IngegneriaScienzeInformatiche/formazione-obbligatoria-su-sicurezza-e-salute ] in modalità e-learning

## Modalità di verifica e valutazione dell'apprendimento

La prova d’esame mira a verificare il raggiungimento dei seguenti obiettivi didattici:

- conoscenza approfondita degli aspetti teorici, dei requisiti, degli algoritmi e delle scelte progettuali che determinano la realizzazione dei sistemi operativi.

· conoscenza approfondita e capacità di utilizzo degli strumenti, tecniche ed algoritmi che il sistema operativo offre all'utente e all'amministrazione di sistema per realizzare funzionalità di alto livello in contesti diversi,

L'esame consiste di una verifica delle abilità pratiche conseguite dallo studente mediante una prova pratica in laboratorio, seguita da una successiva prova scritta per verificare la conoscenza degli aspetti teorici della disciplina. L'ammissione alla seconda prova teorica è condizionata al superamento con voto sufficiente della prima prova pratica.

La prova pratica dura 1 ora e mezzo ed è svolta nello stesso ambiente di laboratorio e con gli stessi strumenti software che gli studenti utilizzano durante le esercitazioni di laboratorio svolte all'interno del corso. La prova propone una serie di problemi da risolvere mediante l'implementazione di semplici applicazioni e scripts.

La prova teorica consiste di una prova scritta che dura 1 ora e prevede risposte aperte ad una serie di domande. La prova scritta spazia tra tutti gli argomenti presentati durante il corso, con una particolare attenzione a quelli svolte durante le lezioni in classe.

## Strumenti a supporto della didattica

Lezioni: proiezione di diapositive a disposizione via Web e dimostrazioni pratiche dei concetti, algoritmi, tecniche, API e strumenti esposti nelle discussioni a lezione. Le dimostrazioni pratiche utilizzano script e files in codice ANSI C che sono preventivamente messi a disposizione nella pagina web del corso. In tal modo, gli studenti possono meglio seguire le dimostrazioni e replicarle durante la stessa lezione sui lo laptop, verificando personalmente lo sviluppo delle operazioni e individuando e proponendo immediatamente al docente eventuali dubbi, così da sollecitare al massimo l'interazione tra studenti e docente durante le lezioni.

Attività in laboratorio: il docente guida gli studenti nell'imparare progressivamente gli strumenti, le API e le strategie di risoluzione dei problemi concernenti tutti gli argomenti del corso. A ciascuno studente è fornito un proprio ambiente di lavoro virtualizzato, in cui lo studente opera con i privilegi di amministratore di sistema, in modo da effettuare realisticamente procedure operative di amministrazione del sistema virtuale.

Gli studenti possono dispiegare lo stesso ambiente virtuale sui loro personal computer, in modo da poter accedere a casa allo stesso ambiente di lavoro che trovano nei laboratori. Ovviamente, lo stesso ambiente di lavoro virtualizzato viene usato dal docente nelle esercitazioni pratiche svolte durante le lezioni in classe.

## Link ad altre eventuali informazioni

http://www.cs.unibo.it/~ghini/didattica/sistemioperativi/sistemioperativi\_index.html

## Orario di ricevimento

Consulta il sito web di
                    
                        Vittorio Ghini

Consulta il sito web di
                        
                            Stefano Ferretti

### SDGs

<!-- image -->

<!-- image -->

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.