# 72787 - PROGRAMMAZIONE DI SISTEMI MOBILE

## Anno Accademico
                2024/2025

- Docente:
Catia Prandi
- Crediti formativi:
                        6
- SSD:
                        INF/01
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 17/02/2025 al 09/06/2025

## Conoscenze e abilità da conseguire

Al termine del corso lo studente possiede strumenti teorici e pratici fondamentali per lo sviluppo di applicazioni native su piattaforma iOS e Android, oltre ad un'introduzione alla progettazione e sviluppo di applicazioni performanti per device mobili in contesto ibrido. In particolare, lo studente conosce come progettare e sviluppare l'architettura e le interfacce grafiche delle applicazioni mobile.

## Contenuti

1. Progettazione e design di applicazioni mobili (circa il 15% delle ore)

2. Introduzione ad Android (circa il 50% delle ore)

- Architettura di un'applicazione Android
- Componenti e risorse
- Activity e Intent
- Menu, Dialog e Toast
- Material design
- Gestione dei dati
- Volley
- Multithreading e servizi
- Sensori
- Camera
- Mappe e GPS

3. Introduzione ad iOS (circa il 30% delle ore)

- Fondamenti dello sviluppo per iPhone
- il linguaggio Swift
- MVVM e SwiftUI

- UserDefaults
- Core data
- Eventi, multi-touch e gesti
- Multithreading
- Map kit e GPS

4. Introduzione alle applicazioni mobile ibride e principali tecnologie utilizzate (circa il 5% delle ore)

## Testi/Bibliografia

Vista la velocità con il quale il mondo mobile cambia e si aggiorna, non ci sono testi consigliati. Si consiglia quindi di utilizzare il materiale fornito dal docente e presente su Virtuale, incluso il materiale di approfondimento messo a disposizione del docente.

## Metodi didattici

Lezioni frontali in aula e lezioni di esercitazione in laboratorio.

In considerazione della tipologia di attività e dei metodi didattici adottati, la frequenza di questa attività formativa richiede la preventiva partecipazione di tutti gli studenti ai Moduli 1 e 2 di formazione sulla sicurezza nei luoghi di studio, [https://elearning-sicurezza.unibo.it/] in modalità e-learning.

## Modalità di verifica e valutazione dell'apprendimento

Sviluppo progetto (applicazione mobile): punteggio massimo 28.

Approfondimento opzionale su un tema a scelta (da concordare con il docente) relativo al contesto mobile computing: punteggio massimo 4.

Il voto finale risulterà dalla somma dei due punteggi.

## Strumenti a supporto della didattica

Piattaforma Virtuale

## Orario di ricevimento

Consulta il sito web di
                    
                        Catia Prandi

### SDGs

<!-- image -->

<!-- image -->

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.