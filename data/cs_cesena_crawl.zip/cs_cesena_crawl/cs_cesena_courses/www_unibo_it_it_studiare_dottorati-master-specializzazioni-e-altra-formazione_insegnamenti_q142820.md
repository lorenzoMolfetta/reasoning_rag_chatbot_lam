# 14015 - CRITTOGRAFIA

## Anno Accademico
                2024/2025

- Docente:
Luciano Margara
- Crediti formativi:
                        6
- SSD:
                        INF/01
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 17/02/2025 al 26/05/2025

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente:
- conosce i risultati e le tecniche di base della matematica discreta che stanno alla base degli algoritmi crittografici;
- conosce gli algoritmi crittografici di base a chiave pubblica e a chiave segreta;
- conosce le principali problematiche di sicurezza informatica;
- conosce i principali protocolli crittografici moderni;
- è capace di comprendere le principali problematiche inerenti la sicurezza di un sistema informatico;
-conosce i risultati di base della teoria dell’informazione e della compressione dati;
- è in grado di comprendere i collegamenti tra crittografia e teoria dell’informazione.

## Contenuti

- Introduzione e cenni storici

- Crittografia a chiave segreta

- Crittografia a Chiave Pubblica

- Confidenzialità

- Autenticazione

- Integrità

- Firma digitale

- SSL

- PGP

- Certificati

- Meccanismi di trust distribuito

- Cenni di teoria dell'informazione (compressione dati).

## Testi/Bibliografia

Handbook of Applied Cryptography, by A. Menezes, P. van Oorschot, and S. Vanstone, CRC Press, 1996

Computer Security: Principles and Practice (4th Edition), Stallings and Brown, Pearson, 2018.

Computer Security: Art and Science (2nd Edition), Matt Bishop, Addison-Wesley, 2018.

## Metodi didattici

Lezioni frontali ed esercitazioni in aula. I fondamenti teorici 

concernenti i sistemi crittografici e le loro principali applicazioni, e 

le principali problematiche di sicurezza dei sistemi informatici sono 

esposti durante le lezioni frontali. Numerosi esercizi sono svolti in 

aula, in preparazione alla prova d'esame.

Estensioni degli esercizi sono regolarmente suggeriti, e le soluzioni 

pubblicate sul web, allo scopo di promuovere e favorire lo studio 

individuale.

## Modalità di verifica e valutazione dell'apprendimento

La prova d'esame mira a verificare il raggiungimento dei seguenti 

obiettivi didattici:

- conoscenza approfondita degli aspetti teorici, degli algoritmi e delle scelte progettuali che determinano la realizzazione di un sistema crittografico.

- conoscenza delle principali problematiche di sicurezza informatica.

- conoscenza e capacità di utilizzare i principali strumenti 

crittografici applicandoli agli scenari di sicurezza in contesti diversi.

L'esame consiste di una prova scritta, più una prova orale opzionale, in cui si verificano le conoscenze degli aspetti teorici della disciplina 

e la capacità di applicarle a scenari reali in sistemi informatici.

## Strumenti a supporto della didattica

Lezioni: proiezione di diapositive messe a disposizione via Web, dimostrazioni teoriche e pratiche di concetti, algoritmi, tecniche, e strumenti esposti nelle discussioni a lezione.

## Orario di ricevimento

Consulta il sito web di
                    
                        Luciano Margara