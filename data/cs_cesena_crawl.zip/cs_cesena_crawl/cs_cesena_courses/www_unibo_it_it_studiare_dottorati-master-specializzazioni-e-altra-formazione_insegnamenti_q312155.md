# 09032 - INGEGNERIA DEL SOFTWARE

## Anno Accademico
                2024/2025

- Docente:
Stefano Rizzi
- Crediti formativi:
                        6
- SSD:
                        ING-INF/05
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 18/09/2024 al 27/11/2024

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente possiede le nozioni fondamentali riguardanti l'ingegneria del software e la progettazione di sistemi informatici; conosce i metodi che consentono l'impiego corretto delle tecnologie a oggetti.

## Contenuti

Prerequisiti

L’allievo che accede a questo insegnamento conosce le basi dei linguaggi di programmazione e degli algoritmi, e il paradigma a oggetti. Tali conoscenze sono acquisite, di norma, superando gli esami di Programmazione, Algoritmi e Strutture Dati, e Programmazione a Oggetti.

Tutte le lezioni saranno tenute in Italiano. È quindi necessaria la comprensione della lingua italiana per seguire con profitto il corso e per poter utilizzare il materiale didattico fornito.

Programma

1. Il ciclo di vita dei sistemi informatici:
    - fasi e attività;
    - pianificazione, analisi dei requisiti, progettazione.
2. Analisi e progettazione orientate agli oggetti:
    - il paradigma a oggetti: astrazione, incapsulamento, ereditarietà, polimorfismo, delegazione;
    - lo sviluppo di sistemi a oggetti.
3. Il linguaggio UML:
    - diagramma dei casi d'uso;
    - diagramma delle classi;
    - diagramma degli oggetti;
    - diagramma di sequenza;
    - diagramma di collaborazione;
    - diagramma degli stati;
    - diagramma di attività;
    - diagramma dei componenti;
    - diagramma di dispiegamento.
4. Cenni alla progettazione di interfacce utente
5. Ingegneria del software:
    - criteri di qualità;
    - misurazione;
    - produzione;
    - prototipazione;
    - verifica;
    - certificazione;
    - manutenzione.

## Testi/Bibliografia

- Lucidi del corso.

Letture consigliate:

- J. Arlow, I Neustadt. UML e Unified Process. McGraw-Hill, 2003.
- S. Bennett, J. Skelton, K. Lunn. Introduzione a UML. McGraw-Hill, 2002.
- A. Binato, A. Fuggetta, L. Sfardini. Ingegneria del Software. Pearson, 2006.
- G. Booch, J. Rumbaugh, I. Jacobson. The UML user guide. Addison Wesley, 1999.
- M. Candolfini, M. Cassiani, M. Musu, C. Zavalloni. CRM: elementi di progettazione e prototipazione di un CRM con UML. Gruppo Editoriale INFOMEDIA, 2003.
- J. Conallen. Applicazioni web con UML. Pearson, 2003.
- M. Fowler. UML distilled. Pearson, 2004.
- C. Ghezzi, M. Jazayeri, D. Mandrioli. Ingegneria del Software. Pearson, 2004.
- M. Golfarelli, D. Maio, S. Rizzi. Ingegneria dei Sistemi Informativi: Lezioni ed esercizi di Modellazione dei Requisiti. Esculapio, 2000.
- L. Maciaszek. Sviluppo di sistemi informativi con UML. Addison-Wesley, 2002.
- R. Pressman. Principi di Ingegneria del Software. McGraw-Hill, 2008.
- W. Zuser, S. Biffl, T. Grechenig, M. Kohle. Ingegneria del software con UML e Unified Process. McGraw-Hill, 2004.

## Metodi didattici

- Lezioni ed esercitazioni in aula
- Esercitazioni di gruppo su lavagne collaborative virtuali
- Autovalutazioni

## Modalità di verifica e valutazione dell'apprendimento

Gli esami verranno effettuati in presenza. La prova consisterà in uno scritto della durata di 60 minuti, durante la quale è espressamente vietato consultare libri e appunti. Il testo dell'esame si compone di una parte progettuale (su carta, 40 minuti, 14/31 punti), che richiede di risolvere uno o più esercizi di analisi e modellazione di specifiche con UML, e di una parte teorica (su EOL, 20 minuti, 17/31 punti) che include alcuni quiz sui contenuti dell'intero corso. Per superare la prova occorre conseguire un punteggio sufficiente sia nella parte progettuale sia in quella teorica. Ulteriori dettagli verranno comunicati a lezione e nelle "note" abbinate agli appelli pubblicati su AlmaEsami.

Il punteggio viene assegnato in trentesimi. Per sostenere la prova d'esame è necessaria l'iscrizione tramite AlmaEsami, nel rispetto delle scadenze previste. Coloro che non riuscissero a iscriversi entro la data prevista sono tenuti a comunicare tempestivamente (e comunque prima della chiusura ufficiale delle liste di iscrizione) il problema alla segreteria didattica. Sarà facoltà del docente ammetterli a sostenere la prova. Una volta pubblicato il risultato della prova, ciascuno studente ha una settimana di tempo per comunicare via email al docente se intende rifiutare il voto conseguito. Sono ammessi massimo due rifiuti.

## Strumenti a supporto della didattica

- Materiale didattico scaricabile da Internet
- Piattaforma Teams per la didattica a distanza
- Piattaforma LucidChart per le esercitazioni

## Orario di ricevimento

Consulta il sito web di
                    
                        Stefano Rizzi

### SDGs

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.