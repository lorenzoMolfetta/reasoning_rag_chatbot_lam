# 58414 - ALGEBRA E GEOMETRIA

## Anno Accademico
                2024/2025

- Docente:
Luca Moci
- Crediti formativi:
                        6
- SSD:
                        MAT/02
- Lingua di insegnamento:
                        Italiano

- Moduli:
Luca Moci
                            (Modulo 1)
                        
                        
                            Fabrizio Caselli
                            (Modulo 2)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 17/02/2025 al 09/06/2025
- Orario delle lezioni (Modulo 2)

dal 17/03/2025 al 30/04/2025

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente possiede gli elementi essenziali dell'algebra lineare e della geometria elementare.

## Contenuti

Il diario delle lezioni e i fogli di esercizi saranno rese disponibili alla pagina Virtuale del corso, che gli studenti sono invitati a consultare regolarmente

Sulla stessa pagina è disponibile un forum su cui gli studenti possono porre domande sui contenuti del corso o sulla sua organizzazione (lezioni, esami, etc).SI PREGA DI UTILIZZARE TALE FORUM INVECE DI MANDARE MESSAGGI EMAIL!

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

PROGRAMMA DEL CORSO

ll corso si articola in 20 lezioni da 3 ore, suddivise nelle 8 unità didattiche qui descritte.

Tutti gli enunciati sono completi di dimostrazione, salvo dove espressamente indicato.

1. Operazioni tra insiemi: unione, intersezione, prodotto cartesiano. Relazioni di equivalenza. Applicazioni; applicazioni iniettive, suriettive, biunivoche; composizione di applicazioni, applicazione inversa. Numeri naturali, interi, razionali, reali, complessi. Campi. La congruenza modulo n e l'insieme delle sue classi di equivalenza Zn; esempi. Zn è un campo se e solo se n è primo (senza dimostrazione). Spazi vettoriali; sottospazi vettoriali. Esempi di spazi vettoriali: n-ple di elementi di un campo, polinomi a coefficienti in un campo, funzioni a valori in un campo. Esempi di sottospazi vettoriali; controesempi (curve, reticoli, coni, unione di sottospazi). L'intersezione di sottospazi e' un sottospazio. Combinazioni lineari, sottospazio generato da un insieme di vettori. Insiemi generatori e insiemi linearmente indipendenti. Basi. Un insieme di vettori e' una base se e solo se ogni vettore si scrive in modo unico come combinazione lineare dei suoi elementi. Coordinate di un vettore in una base data. Completare a una base, estrarre una base.

2. Tutte le basi di uno spazio vettoriale hanno la stessa cardinalità (senza dimostrazione). Dimensione. Basi canoniche per K^n (n-ple di elementi di un campo) e K[x] (polinomi a coefficienti in un campo). Due modi di descrivere un sottospazio vettoriale: forma parametrica e forma cartesiana; legami con la dimensione. Somma di sottospazi; formula di Grassman (cenni di dimostrazione). Somma diretta; due sottospazi formano somma diretta se e solo se la decomposizione di ogni vettore e' unica.





3. Applicazioni lineari; esempi e controesempi. Lo spazio vettoriale delle applicazioni lineari tra due spazi vettoriali dati. La composizione di applicazioni lineari è lineare, l'inversa di un'applicazione lineare è lineare. Nucleo e immagine di una applicazione lineare; il nucleo e l'immagine sono sottospazi vettoriali. Legame con l'iniettività e la suriettività; isomorfismi. Essere isomorfi e' una relazione di equivalenza. Teorema del rango. Esiste una e una sola applicazione lineare che prende valori dati su una base data. Matrice di un'applicazione lineare in basi date; isomorfismi tra lo spazio vettoriale delle applicazioni lineari tra due spazi vettoriali dati e lo spazio vettoriale delle matrici m x n. La matrice della composizione di due applicazioni è il "prodotto riga per colonna" delle due matrici corrispondenti (cenni di dimostrazione). Una applicazione lineare è un isomorfismo se e solo se manda basi in basi. Tutti gli spazi vettoriali di dimensione n su un campo dato sono isomorfi tra loro.



4. Matrice identità, matrici invertibili. Una matrice quadrata è invertibile se e solo se i suoi vettori colonna sono linearmente indipendenti; rango di una matrice; il rango e' la dimensione dell'immagine. Cambiamenti di base; esempi. Similitudine; due matrici sono simili se e solo se rappresentano la stessa applicazione lineare (cenni di dimostrazione). Determinante di una matrice quadrata: definizione ricorsiva tramite lo sviluppo di Laplace; proprietà del determinante (senza dimostrazione). Formula per la matrice inversa di una matrice data (senza dimostrazione). Matrici quadrate che rappresentano la stessa applicazione lineare in basi diverse hanno lo stesso determinante; determinante di una applicazione lineare. Prodotto vettoriale.





5. Risoluzione di sistemi lineari: metodo di Cramer. Metodo di eliminazione di Gauss. Definizioni equivalenti di rango: per colonne, per righe, per pivot (cenni di dimostrazione).Teorema di Rouché-Capelli. L'insieme delle soluzioni di un sistema lineare omogeneo è un sottospazio vettoriale. Sottospazi affini, loro rappresentazioni parametrica e cartesiana. L'insieme delle soluzioni di un sistema lineare, se non è vuoto, è un sottospazio affine di dimensione n-rk A. Applicazioni alla geometria: rette e piani passanti per punti dati; intersezioni di rette e di piani; parallelismo. Enumerazione di sottospazi e di applicazioni su campi finiti. Esempi ed esercizi.





6. Matrici diagonali e loro proprieta'. Autovalori e autovettori di una applicazione lineare. Basi di autovettori. Polinomio caratteristico; gli autovalori di f sono tutti e soli gli scalari che annullano il suo polinomio caratteristico. Esempi di applicazioni lineari che non hanno autovalori nel campo razionale o nel campo reale. Autospazi e loro proprieta'. Basi di autovettori. Molteplicita' algebrica e geometrica. La molteplicità geometrica di ogni autovalore è maggiore o uguale a 1 e minore uguale della molteplicità algebrica. Una applicazione e' diagonalizzabile su un campo dato se e solo se tutti gli autovalori appartengono al campo e la molteplicita' algebrica di ciascun autovalore e' uguale alla sua molteplicita' geometrica. Applicazioni nilpotenti; una applicazione lineare nilpotente non nulla non e' diagonalizzabile. Esempio: la derivazione di polinomi. Cenni alla forma canonica di Jordan (senza dimostrazione).





7. Forme bilineari. Matrice di una forma bilineare in una base data; isomorfismi tra forme bilineari e matrici quadrate. Congruenza tra matrici; due matrici sono congruenti se e solo se rappresentano la stessa forma bilineare (cenni di dimostrazione). Forme bilineari simmetriche e antisimmetriche, matrici simmetriche e antisimmetriche. Trasposta di una matrice e sue proprieta'. Diagonalizzazione di forme bilineari. Per ogni forma bilineare simmetrica esiste una base diagonalizzante, ovvero ogni matrice simmetrica è congruente ad una matrice diagonale (cenni di dimostrazione). Teorema di Sylvester: forma canonica di una forma bilineare reale (con dimostrazione), segnatura; la segnatura non dipende dalla base scelta (senza dimostrazione). Forma canonica di una forma bilineare complessa; rango. Forma quadratica associata ad una forma bilineare. Corrispondenza tra forme quadratiche e forme bilineari simmetriche. Forme quadratiche reali definite positive e negative, semidefinite positive e negative, indefinite; loro segnatura. Prodotti scalari. Esempi notevoli di prodotti scalari: prodotto scalare standard di n-ple di elementi di un campo, prodotto scalare standard di funzioni (a valori un campo) su un insieme finito, integrale del prodotto di funzioni continue su intervallo chiuso e limitato. Insiemi ortogonali e ortonormali di vettori. Esempi. Ogni prodotto scalare ammette una base ortonormale.





8. Un insieme ortogonale di vettori e' linearmente indipendente. Il prodotto scalare di due vettori è uguale al prodotto scalare standard delle loro coordinate rispetto ad una base ortonormale. Matrici ortogonali. Teorema spettrale (senza dimostrazione). Disuguaglianza di Cauchy-Schwatz. Angolo convesso tra due vettori. Norma di un vettore e sue proprieta'. Distanza euclidea e sue proprieta'. Sottospazio vettoriale ortogonale a un sottospazio dato. Sottospazio affine ortogonale ad un sottospazio affine dato e passante per un punto dato. Isometrie di uno spazio vettoriale (rispetto ad un prodotto scalare dato). Una applicazione lineare e' una isometria se e solo se conserva la norma di ogni vettore. Ogni isometria conserva gli angoli. Ogni isometria e' un isomorfismo. Una base e' ortonormale se e solo se la matrice del cambiamento di base, rispetto ad una base ortonormale data, e' ortogonale. Un'applicazione lineare e' una isometria se e solo se manda basi ortonormali in basi ortonormali. Un'applicazione lineare e' una isometria se e solo la sua matrice rispetto ad una qualunque base ortonormale e' ortogonale. Determinante e autovalori reali di una isometria. Esempi ed esercizi. Classificazione delle isometrie in dimensione 2: rotazioni e simmetrie

## Testi/Bibliografia

Le lezioni vengono svolte alla LIM (lavagna interattiva multimediale) e, al termine di ciascuna lezione, il contenuto delle lavagne viene postato sulla pagina Virtuale del corso:

Gli studenti che seguono regolarmente le lezioni possono preparare l'esame utilizzando esclusivamente o prevalentemente tali appunti. Tuttavia, qualora ci fosse necessità di integrarli con un libro di testo, si consiglia il seguente, disponibile gratuitamente online:

- Marco Manetti, Algebra Lineare per matematici, scaricabile gratuitamente su

https://www1.mat.uniroma1.it/people/manetti/dispense/algebralineare.pdf

I fogli di esercizi disponibili sulla pagina Virtuale del corso sono sufficienti per prepararsi all'esame; tuttavia, qualora fosse necessario esercitarsi maggiormente, si suggerisce il seguente testo di esercizi risolti:

Anichini-Conti-Paoletti, Algebra e Lineare e Geometria analitica ESERCIZI E PROBLEMI, seconda ed, Pearson.

## Metodi didattici

Il corso, che si svolge esclusivamente in presenza, consiste di 60 ore di lezione, durante le quali gli argomenti verranno presentati anche attraverso definizioni, teoremi, dimostrazioni, esempi, controesempi, applicazioni ed esercizi.

Verranno proposti agli studenti 8 fogli di esercizi da risolvere autonomamente, al fine di assimilare e rielaborare i contenuti appresi a lezione.

In aggiunta alle 60 ore di lezione, verranno svolte alcune ore di tutorato dedicate alla correzione di tali esercizi e al chiarimento dei dubbi.

Si raccomanda caldamente di:

- seguire regolarmente le lezioni e i tutorati, partecipando in modo attivo anche con domande;

- dopo ogni lezione, riguardare gli appunti e soffermarsi sui concetti che non siano stati compresi appieno;

-svolgere e consegnare regolarmente gli esercizi assegnati; in seguito confrontare con attenzione le proprie soluzioni con quelle illustrate dal docente e dai tutor.

-usufruire del ricevimento (con il docente o con i tutor) per chiarire per tempo eventuali dubbi, senza aspettare le settimane immediatamente precedenti all'esame.

## Modalità di verifica e valutazione dell'apprendimento

L'esame consiste in una prova scritta ed una orale, entrambe obbligatorie, che si svolgono in presenza.

La prova scritta consiste in domande a risposta multipla. Non è consentito usare libri né appunti né calcolatrici.

Agli studenti che, durante lo svolgimento del corso, abbiano svolto e consegnato regolarmente gli esercizi assegnati, potrà essere assegnato un punteggio bonus fino a 4 punti, che sarà sommato a quello dello scritto del primo o del secondo appello o del terzo appello, mentre in alcun caso potrà essere usata per gli appelli successivi. Tale possibilità, rivolta anzitutto agli studenti del primo anno, è tuttavia aperta anche agli studenti iscritti ad anni successivi al primo.

Coloro che alla prova scritta ottengono un punteggio di almeno 18/30 (incluso l'eventuale bonus) sono ammessi a sostenere la prova orale. Scritto e orale dovranno essere sostenuti nello stesso appello, fatti salvi casi eccezionali che dovranno essere debitamente documentati e autorizzati.

Durante la prova orale lo studente dovrà dare prova di avere compreso i concetti fondamentali del corso, e saperli applicare ad esempi e problemi; dovrà conoscere con precisione le definizioni, gli enunciati dei teoremi e, possibilmente, la loro dimostrazione.

Le date degli esami verranno pubblicate con adeguato anticipo su almaesami.

## Strumenti a supporto della didattica

- Lezioni seguibili in presenza. Le lezioni non verranno registrate né trasmesse online, ma gli appunti saranno messi a disposizione su Virtuale.

- Incontri con i tutor.

- Fogli di esercizi assegnati e corretti periodicamente.

- Libri di testo e libri di esercizi consigliati

- Pagina del corso su Virtuale, con il programma svolto, i fogli di esercizi, i forum, gli annunci, i compiti di esame degli anni precedenti, etc.

## Orario di ricevimento

Consulta il sito web di
                    
                        Luca Moci

Consulta il sito web di
                        
                            Fabrizio Caselli