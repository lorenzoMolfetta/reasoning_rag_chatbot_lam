# 70218 - RETI DI TELECOMUNICAZIONE

## Anno Accademico
                2024/2025

- Docente:
Franco Callegati
- Crediti formativi:
                        6
- SSD:
                        ING-INF/03
- Lingua di insegnamento:
                        Italiano

- Moduli:
Franco Callegati
                            (Modulo 1)
                        
                        
                            Andrea Piroddi
                            (Modulo 2)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 18/09/2024 al 18/12/2024
- Orario delle lezioni (Modulo 2)

dal 07/10/2024 al 09/12/2024

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente acquisisce le nozioni essenziali sulle architetture delle moderne reti di telecomunicazioni, con particolare riferimento ad Internet, e sulle problematiche di progettazione e implementazione dei relativi protocolli di comunicazione.

## Contenuti

L'insegnamento completa la presentazione delle tecnologie di rete, ripartendo dal programma svolto nel corso di Programmazione di reti.

1. Architettura di Internet. Protocollo IP. Indirizzamento: subnetting e supernetting, CIDR. Instradamento diretto e indiretto. Analisi delle tabelle di routing.
2. Gestione delle reti IP: ICMP, DHCP, NAT, ARP.
3. Algoritmi e protocolli di routing. Architettura gerarchica di Internet, Authonomous System, protocolli di routing IGC e EGP. Funzionalita' dei protocolli RIP e OSPF.
4. Cenni alle problematiche di sicurezza nelle reti.
5. Reti in area locale (LAN). La rete Ethernet (IEEE 802.3) e le sue evoluzioni. Reti locali wireless, IEEE 802.11.

## Testi/Bibliografia

Achille Pattavina, "Internet e reti. Fondamenti." Pearson; 3° edizione (9 febbraio 2022), 576 pagine, ISBN 8891930911

## Metodi didattici

Lezioni di didattica frontale in aula.

Esercitazioni pratiche in aula:

- analisi di flussi di pacchetti tramite analizzatore di protocollo (Wireshark);
- configurazione di una rete IP
- analisi pratica di routing e forwarding

## Modalità di verifica e valutazione dell'apprendimento

Informazioni specifiche sulla prova d'esame sono disponibili Virtuale alla pagina del corso

## Strumenti a supporto della didattica

Traccia delle lezioni sotto forma di diapositive disponibili su Virtuale

## Orario di ricevimento

Consulta il sito web di
                    
                        Franco Callegati

Consulta il sito web di
                        
                            Andrea Piroddi