# B2561 - METODI NUMERICI PER L'INTELLIGENZA ARTIFICIALE

## Anno Accademico
                2024/2025

- Docente:
Damiana Lazzaro
- Crediti formativi:
                        6
- SSD:
                        MAT/08
- Lingua di insegnamento:
                        Italiano

- Moduli:
Damiana Lazzaro
                            (Modulo 1)
                        
                        
                            Lorenzo Pellegrini
                            (Modulo 2)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 17/02/2025 al 05/06/2025
- Orario delle lezioni (Modulo 2)

dal 17/02/2025 al 03/06/2025

## Conoscenze e abilità da conseguire

Lo scopo di questo corso è affrontare il background matematico e numerico alla base dell’Intelligenza Artificiale e del Machine Learning, con particolare attenzione alle applicazioni in Scienza e Ingegneria e sostenere l'analisi teorica con l’utilizzo di attività laboratoriali.

## Contenuti

1. Il Calcolo Numerico - Obiettivi e problemi nella risoluzione di problemi pratici al calcolatore.

2. Introduzione all'Intelligenza Artificiale - Cenni ad applicazioni di Intelligenza Artificiale (IA), Machine Learning (ML) e Deep Learning (DL)- Impatto dell’AI nell’Economia- Breve storia dell’evoluzione dell’AI -Definizioni e paradigma generale del ML e DL.

3. Introduzione alle Reti Neurali: Task del ML (classificazione, regressione e clustering) - Apprendimento (supervisionato, non supervisionato, self-supervised) -Definizione di Artificial Neuron e Multi-Layer Perceptron (MLP) - Definizione di Convolutional Neural Network (CNN) - Funzione obiettivo (Loss Function). Forward Propagation e Backward Propagation.

4. Numeri Finiti - Rappresentazione dei numeri reali. I numeri finiti. Errori di rappresentazione. Aritmetica floating point. Analisi dell’errore nelle operazioni aritmetiche elementari. Propagazione degli errori: condizionamento di un problema e stabilità dell'algoritmo risolutivo.

5. Richiami di Algebra Lineare - Richiami su vettori, matrici e spazi vettoriali. Norme di vettori e norme di matrici.

6. Zeri di Funzioni - Formulazione del problema. Tecniche di Risoluzione. Metodi iterativi, convergenza e ordine dei metodi. Metodi a convergenza locale e a convergenza globale. Metodo di bisezione e altri metodi del primo ordine. Un metodo del secondo ordine: il metodo di Newton. Metodi quasi-Newton: il metodo delle secanti. Soluzione di sistemi di equazioni non lineari: metodo di Newthon-Raphson e sue varianti. Metodo di Newton-Raphson per il calcolo dei punti di minimo di una funzione multivariata.

7. Soluzione numerica di Sistemi Lineari: Metodi diretti - Indice di condizionamento di una matrice e condizionamento del problema. Algoritmo di eliminazione Gaussiana e fattorizzazione LU di una matrice. Stabilità della fattorizzazione LU. Strategie pivotali. Fattorizzazione di Cholesky per matrici simmetriche e definite positive. Fattorizzazione QR e fattorizzazione SVD di matrici rettangolari. Proprietà.

8. Soluzione numerica di Sistemi Lineari: Metodi iterativi - Metodi iterativi basati sullo splitting della matrice. Condizione necessaria e sufficiente per la convergenza. Metodo di Jacobi, Gauss-Seidel- Metodi di rilassamento (Gauss-Seidel Sor) - Condizioni sufficienti per la convergenza. Metodi di discesa per la soluzione di un sistema lineare con matrice simmetrica e definita positiva. Condizione per l'ammissibilità della direzione di discesa. Metodo del gradiente e Metodo del gradiente coniugato. Influenza del malcondizionamento della matrice sulla elocità di convergenza dei metodi di discesa.

9. Approssimazione ai minimi quadrati - Metodo delle equazioni normali, metodo QRLS (risoluzione del problema ai minimi quadrati utilizzando la fattorizzazione QR), metodo basato sulla fattorizzazione SVD della matrice.

10. Interpolazione - Interpolazione polinomiale. Esistenza ed unicità del polinomio interpolatore. Forma di Lagrange e forma di Newton. Espressione dell'errore nell'interpolazione polinomiale. Problemi di convergenza. Condizionamento del problema di interpolazione polinomiale.

11. Integrazione Numerica. Formule di Newton Cotes semplici (Trapezi e Simpson) e composite.

12. Ottimizzazione della loss function per il training di una rete neurale. Non convessità della loss-function - Calcolo delle derivate parziali della funzione loss rispetto a tutti i pesi della rete e conseguente aggiornamento mediante algoritmo di backpropagation. Metodo di discesa del gradiente, metodo stocastico del gradiente, metodo del gradiente minibatch. Iperparametri di una rete neurale. Learning rate scheduling: step decay, decadimento esponenziale, decadimento dipendente dal tempo. Learning rate adattivo: Adagrad, RMSProp, Adadelta, Adam.

## Testi/Bibliografia

Fondamentale sarà l’utilizzo degli appunti presi a lezione e del materiale informatico reso disponibile all'indirizzo https://virtuale.unibo.it/

Per ulteriori approfondimenti si consigliano:

[1] R. Johansson: Numerical Python - Scientific Computing and Data Science Applications with Numpy, SciPy and Matplotlib (2nd edition), Apress, 2019

[2] J. Kiusalaas: Numerical Methods in Engineering with Python 3, Cambridge University Press, 2013

[3] A. Quarteroni, R. Sacco, F. Saleri, P. Gervasio: Matematica Numerica (4a edizione), Springer Verlag, 2014

[4] R. Bevilacqua, D. Bini, M. Capovani, O. Menchi: Metodi Numerici, Zanichelli, Bologna, 1992

[5] D. Bini, M. Capovani, O. Menchi: Metodi numerici per l'algebra lineare, Zanichelli, Bologna, 1996

## Metodi didattici

Il corso è strutturato in lezioni frontali ed esercitazioni in laboratorio. Più precisamente, alle lezioni frontali in aula in cui vengono presentati i metodi numerici di base per risolvere problemi classici della matematica mediante l'uso di un calcolatore, fanno seguito esercitazioni in laboratorio che mirano all'implementazione di tali metodi in Python e allo sviluppo di un'adeguata sensibilità e consapevolezza del loro utilizzo.

## Modalità di verifica e valutazione dell'apprendimento

La prova d'esame mira a verificare il raggiungimento dei seguenti obiettivi didattici:

- conoscenza degli elementi fondamentali del calcolo numerico, illustrati durante le lezioni frontali;

- capacità di impiegare i metodi numerici di base per risolvere problemi reali mediante calcolatore.

L'esame di fine corso (la cui valutazione è in trentesimi) si svolgerà in un'unica prova che comprende, sia la realizzazione al calcolatore di codici Python per la risoluzione di problemi numerici, che la risposta scritta a domande teoriche sugli argomenti trattati nelle lezioni frontali.

## Strumenti a supporto della didattica

Il corso prevede un'attività di laboratorio in cui si utilizzerà il linguaggio di programmazione Python. Il relativo materiale didattico verrà messo a disposizione dello studente in formato elettronico e sarà reperibile all'indirizzo https://virtuale.unibo.it/

## Orario di ricevimento

Consulta il sito web di
                    
                        Damiana Lazzaro

Consulta il sito web di
                        
                            Lorenzo Pellegrini