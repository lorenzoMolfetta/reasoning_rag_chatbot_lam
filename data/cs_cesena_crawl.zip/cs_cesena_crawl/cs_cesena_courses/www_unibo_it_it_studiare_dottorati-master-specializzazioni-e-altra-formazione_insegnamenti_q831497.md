# 72778 - HIGH-PERFORMANCE COMPUTING

## Anno Accademico
                2024/2025

- Docente:
Moreno Marzolla
- Crediti formativi:
                        6
- SSD:
                        INF/01
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 18/09/2024 al 11/12/2024

## Conoscenze e abilità da conseguire

Al termine del corso lo studente: conosce i fondamenti della programmazione parallela, e le principali architetture dei sistemi di calcolo ad alte prestazioni; è in grado di progettare algoritmi paralleli su architetture a memoria condivisa e distribuita; è in grado di implementare algoritmi paralleli utilizzando i linguaggi, gli strumenti e le tecnologie appropriate; è in grado di misurare le prestazioni e l'efficienza di programmi paralleli.

## Contenuti

Programma

- Algoritmi paralleli e modelli di calcolo
- Introduzione alle architetture per il calcolo parallelo: tassonomia di Flynn; sistemi a memoria condivisa e distribuita; GPGPU
- Pattern per la programmazione parallela (embarassingly parallel; stencil; work farm; scan; reduce)
- Programmazione parallela su architetture a memoria condivisa con OpenMP
- Programmazione parallela su architetture a memoria distribuita con MPI
- Programmazione GPGPU
- Cenni sulla programmazione SIMD usando gli "intrinsic" del compilatore o l'auto-vettorizzazione (compilatore GCC)
- Valutazione delle prestazioni di programmi paralleli: misurazione e comprensione di speedup ed efficienza.

Prerequisiti

Questo corso richiede una buona conoscenza della programmazione in linguaggio C in ambiente Unix/Linux, e delle architetture dei calcolatori (a livello di quanto presentato nel corso di Architettura dei Calcolatori).

## Testi/Bibliografia

Argomenti selezionati dai seguenti volumi:

- Peter Pacheco and Matthew Malensek, An Introduction to Parallel Programming, Morgan Kauìffman, 2nd edition, 2021, ISBN 9780128046050; va bene anche la prima edizione: 

    Peter Pacheco, An Introduction to Parallel Programming, Morgan Kaufmann, 2011, ISBN 978-0123742605
- Jason Sanders, Edward Kandrot, CUDA by Example: An Introduction to General-Purpose GPU Programming, Addison-Wesley, 2010, ISBN 978-0131387683
- Georg Hager, Gerhard Wellein, Introduction to High Performance Computing for Scientists and Engineers, CRC Press; 1 edition (July 2, 2010), ISBN 978-1439811924

Ulteriore materiale (inclusi i lucidi delle lezioni e il materiale di laboratorio) è reso disponibile sul sito del corso.

## Metodi didattici

Durante le lezioni in aula vengono introdotti i concetti base della programmazione parallela, e vengono via via descritti i costrutti di programmazione parallela che sono poi oggetto di esercitazioni parzialmente guidate in laboratorio con la supervisione del docente. Vengono rese disponibili le soluzioni degli esercizi proposti in laboratorio allo scopo di supportare le attività di studio individuale.

In considerazione della tipologia di attività e dei metodi didattici adottati, la frequenza di questa attività formativa richiede la preventiva partecipazione di tutti gli studenti ai moduli 1 e 2 di formazione sulla sicurezza nei luoghi di studio, https://elearning-sicurezza.unibo.it/ in modalità e-learning

## Modalità di verifica e valutazione dell'apprendimento

Le conoscenze acquisite durante il corso verranno valutate mediante una prova scritta e un progetto di programmazione. Le due prove sono indipendenti e possono essere sostenute in qualsiasi ordine.

La prova scritta si compone di alcune domande (in genere, quattro o cinque) a quiz e/o a risposta aperta, riguardanti gli aspetti metodologici visti a lezione. La prova scritta viene valutata in trentesimi; il punteggio massimo assegnato a ciascuna risposta corretta è indicato a fianco della domanda.

Il progetto di programmazione consiste nella realizzazione di una applicazione parallela su specifiche indicate dal docente, usando gli strumenti visti a lezione e in laboratorio. Il programma parallelo deve essere accompagnato da una relazione scritta. Nella valutazione del progetto si terrà conto della correttezza dell'implementazione, della chiarezza ed efficienza del codice, nonché della qualità della relazione. Il progetto viene valutato in trentesimi.

L'esame si intende superato se si riporta una valutazione maggiore o uguale a 18/30 su ognuna delle due prove. Il voto finale si ottiene come media pesata del voto della prova scritta (peso 4) e del progetto (peso 6). La lode viene assegnata a discrezione del docente per prove d'esame di qualità particolarmente elevata.

## Strumenti a supporto della didattica

Lezioni: proiezione di diapositive e dimostrazioni pratiche di programmazione parallela al calcolatore, integrate con ulteriori spiegazioni alla lavagna. Il materiale viene reso disponibile prima dell'inizio della lezione stessa.

Attività di laboratorio: le esercitazioni pratiche verranno svolte in ambiente Linux usando gli strumenti di sviluppo disponibili. Agli studenti verrà fornito accesso ad un server, accessibile anche da remoto. Tutti gli strumenti utilizzati sono liberamente disponibili, allo scopo di favorire l'attività di studio individuale su proprie risorse hardware, se disponibili.

## Link ad altre eventuali informazioni

https://www.moreno.marzolla.name/teaching/HPC/

## Orario di ricevimento

Consulta il sito web di
                    
                        Moreno Marzolla