# 00405 - FISICA

## Anno Accademico
                2024/2025

- Docente:
Luigi Guiducci
- Crediti formativi:
                        6
- SSD:
                        FIS/01
- Lingua di insegnamento:
                        Italiano

- Modalità didattica:
Convenzionale - Lezioni in presenza
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni

dal 19/02/2025 al 06/06/2025

## Conoscenze e abilità da conseguire

Al termine del corso, lo studente conosce le basi della dinamica classica, il significato di lavoro ed energia e i fondamenti dell’elettromagnetismo. Lo studente è in grado di risolvere semplici problemi e di applicare i concetti appresi a dispositivi e sensori usati nella tecnologia dell’informazione.

## Contenuti

-) Sistema Internazionale di unità di misura. Unità di tempo, lunghezza, massa e corrente elettrica.

-) Cinematica: concetto e definizione di velocità e accelerazione. Significato geometrico. Legge oraria dei moti rettilineo uniforme, uniformemente accelerato e circolare uniforme.

-) Dinamica: leggi del moto di Newton. Forze e quantità di moto. Esempi di forze: gravitazionale, elastica, attrito. Sensori di forza e accelerometri.

-) Lavoro ed energia: Lavoro e potenza di una forza. Lavoro e energia cinetica. Forze conservative e energia potenziale.

-) Elettrostatica: Legge di Coulomb. Campo elettrico. Energia potenziale e potenziale elettrico. Flusso del campo elettrico e teorema di Gauss. Il condensatore. Sensori capacitivi.

-) Correnti elettriche: Legge di Ohm. Mobilità e resistività: conduttori e isolanti. Effetto Joule. Resistenze in serie e parallelo. Leggi di Kirchhoff. Misure di corrente e tensione. Condensatori in serie e parallelo. Circuiti RC. Sensori resistivi.

-) Magnetismo: Correnti elettriche e campo magnetico. Forza di Lorentz. Sorgenti del campo magnetico. Induzione elettromagnetica. Applicazioni dell'induzione elettromagnetica.

Programma dettagliato

Sistema internazionale di unità di misura: lunghezza, tempo e massa. Cinematica del punto materiale: velocità e accelerazione in 1 dimensione. Moti rettilineo uniforme e rettilineo uniformemente accelerato.

Cinematica in 2 e 3 dimensioni. Velocità e accelerazione. Moto su una circonferenza. Moto circolare uniforme: periodo, frequenza e velocità angolare.

Moto armonico. Moto balistico in due dimensioni. Traiettoria parabolica: gittata. Velocità relativa per sistemi in moto rettilineo uniforme.

Principi della dinamica. Primo principio: conservazione della quantità di moto. Significato di sistema di riferimento inerziale. Secondo principio: forza e accelerazione. Forze fondamentali della natura. Terzo principio: azione e reazione.

Applicazioni dei principi della dinamica: ascensore in discesa e risalita, funi e carrucole, moto dei satelliti, piano inclinato, forza di attrito.

Moto vincolato su una circonferenza nel piano orizzontale: limite di aderenza. Il pendolo: piccole oscillazioni e periodo. La forza elastica.

Definizione di energia cinetica e lavoro. Potenza. Teorema del lavoro e dell'energia cinetica. Lavoro di una forza costante, della forza elastica, e della forza di gravità.

Lavoro indipendente dal percorso: forze conservative e energia potenziale. Forza costante, di gravità, elastica. Relazione fra forza e energia potenziale. Conservazione dell'energia meccanica. Moto a energia costante in potenziale arbitrario: analisi grafica.

Forze non conservative. Variazioni di energia meccanica e produzione di calore (cenni). La definizione di caloria. Forze dissipative: attrito e resistenza nel moto in un fluido.

Carica elettrica: legge di Coulomb. Significato di campo elettrico: campo di una carica puntiforme, di un dipolo e di un filo uniformemente carico. Flusso del campo elettrico e teorema di Gauss (prima equazione di Maxwell).

Campo di una lastra carica. Il condensatore. Definizione di capacità. Energia potenziale e potenziale elettrico. Energia immagazzinata in un condensatore. Condensatori e dielettrici.

Moto di cariche in campi elettrici. Conduttori e isolanti. Modello microscopico di conducibilità. Legge di Ohm. Caratteristica V-I di un campione; materiali semiconduttori e giunzione p-n.

Resistenze e capacità in serie e in parallelo. Circuiti in corrente continua. Leggi di Kirchoff.

Effetto Joule. Energia in un condensatore. Bilancio energetico. Transitori RC. Sensori capacitivi e resistivi.

Campo magnetico e cariche in movimento: Forza di Lorentz. Definizione di prodotto vettoriale. Forza magnetica su un filo percorso da corrente.

Sorgenti del campo magnetico e sue caratteristiche. Assenza di monopoli magnetici. Teorema della circuitazione di Ampère. Campo magnetico di un filo e di un solenoide. Forza tra fili percorsi da corrente. Permeabilità magnetica relativa e ferromagnetismo (cenni).

Induzione elettromagnetica: legge di Faraday. Il verso della corrente indotta: legge di Lenz. Generatori di corrente alternata. Campi elettrici non conservativi. Legge di Ampere-Maxwell. Equazioni di Maxwell.

Applicazioni dell'induzione elettromagnetica: trasformatore, motore a induzione, lettura di tag RFID, Inductive Power Transfer, correnti parassite.

Corrente di spostamento. Equazioni di Maxwell.

## Testi/Bibliografia

1) Walker, "FONDAMENTI DI FISICA", Pearson

2) Giancoli, "FISICA", Casa Editrice Ambrosiana. Disponibile anche in due volumi, leggermente più approfonditi, "FISICA 1" e "FISICA 2"

3) Halliday, Resnick, Walker, "FONDAMENTI DI FISICA", Casa Editrice Ambrosiana. Disponibile anche in due volumi, "Meccanica-Onde-Termodinamica" e "Elettromagnetismo-Ottica"

## Metodi didattici

Lezioni frontali con uso di lavagna, diapositive proiettate, semplici dimostrazioni dal vivo di alcuni fenomeni oggetto di studio. Ogni lezione comprende momenti dedicati all'illustrazione di esempi applicativi e allo svolgimento di esercizi. Saranno svolte inoltre sessioni  interamente dedicate alle esercitazioni.

## Modalità di verifica e valutazione dell'apprendimento

All'esame scritto saranno proposti 3-4 esercizi articolati in 3 o 4 domande ciascuno, volti a coprire i vari argomenti trattati nel corso, che saranno svolti su carta e corretti e valutati manualmente dal docente. Inoltre, 6-8 quesiti a scelta multipla e la risposta ad una domanda aperta a scelta tra tre completano lo scritto per quanto riguarda la parte di teoria, dal momento che non è obbligatorio sostenere successivamente la prova orale.

A richiesta dello studente è possibile integrare l'esame scritto, purché sufficiente, con un colloquio orale in cui verranno poste domande di teoria.

## Strumenti a supporto della didattica

Saranno disponibili su virtuale.unibo i seguenti materiali didattici:

-) Appunti usati dal docente per lo svolgimento delle lezioni e dispense per gli studenti

-) Esercizi con soluzione

## Orario di ricevimento

Consulta il sito web di
                    
                        Luigi Guiducci

### SDGs

<!-- image -->

<!-- image -->

L'insegnamento contribuisce al perseguimento degli Obiettivi
            di Sviluppo Sostenibile dell'Agenda 2030 dell'ONU.