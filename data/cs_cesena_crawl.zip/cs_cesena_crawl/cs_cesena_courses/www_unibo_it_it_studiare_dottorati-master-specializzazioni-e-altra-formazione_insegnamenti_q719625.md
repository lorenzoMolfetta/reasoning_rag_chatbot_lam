# 00013 - ANALISI MATEMATICA

## Anno Accademico
                2024/2025

- Docente:
Cristiano Frattagli
- Crediti formativi:
                        12
- SSD:
                        MAT/05
- Lingua di insegnamento:
                        Italiano

- Moduli:
Cristiano Frattagli
                            (Modulo 1)
                        
                        
                            Andrea Bonfiglioli
                            (Modulo 2)
                        
                        
                            Andrea Bonfiglioli
                            (Modulo 3)
- Modalità didattica:
                        
                        
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 1)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 2)
                                
                            
                            
                                
                                    Convenzionale - Lezioni in presenza (Modulo 3)
- Campus:
                            Cesena
- Corso:
                            Laurea in
                            Ingegneria e scienze informatiche (cod. 8615)

- Lezioni online
- Risorse didattiche su Virtuale

- Orario delle lezioni (Modulo 1)

dal 18/09/2024 al 18/12/2024
- Orario delle lezioni (Modulo 2)

dal 23/09/2024 al 11/11/2024
- Orario delle lezioni (Modulo 3)

dal 18/11/2024 al 16/12/2024

## Conoscenze e abilità da conseguire

Lo studente deve sviluppare tre tipi di abilità/conoscenze:
1) eseguire calcoli su funzioni di una o più variabili (limiti, derivate, integrali) e saper risolvere alcuni tipi di problemi
che utilizzano gli strumenti dell’analisi matematica (calcolo della lunghezza di una curva, di un volume o risoluzione di alcune classi di equazioni differenziali ordinarie);
2) capire e saper usare le definizioni di base dell’analisi matematica;
3) conoscere le funzioni elementari.

## Contenuti

Introduzione. Cenni di teoria degli insiemi. Prodotto cartesiano. Relazioni.

Definizione di funzione. Funzioni iniettive, suriettive, biunivoche.

Composizione tra funzioni. Funzioni invertibili.

Insiemi ordinati. Maggioranti e minoranti. Massimi e minimi.

Estremo superiore e inferiore.

Completezza. Numeri reali.

Numeri naturali. Numeri interi. Numeri razionali.

Proprieta' di densita'. Cenni sulla cardinalita'. Principio di induzione.

Numeri complessi. Definizione e operazioni sui numeri complessi. Forma algebrica di un numero complesso, modulo e argomento di un numero complesso, forma esponenziale di un numero complesso. Radici di un numero complesso ed equazioni algebriche in C.

Successioni reali. Successioni in R; limiti di successioni; teoremi di permanenza del segno e del confronto; operazioni sui limiti. Successioni monotone e loro limiti; limitatezza ed estremi di sottoinsiemi di R. Il numero e; alcuni limiti notevoli di successioni.

Funzioni reali di variabile reale, limiti e continuità. Funzioni elementari di variabile reale: potenza, esponenziale, logaritmo, funzioni trigonometriche e loro inverse, funzioni iperboliche e loro inverse. Limiti di funzioni reali di variabile reale; estensione dei risultati stabiliti per le successioni; limite di funzione composta. Limite destro e sinistro; funzioni monotone e loro limiti. Alcuni limiti notevoli. Continuità di funzioni reali di variabile reale, operazioni sulle funzioni continue. I teoremi degli zeri, dei valori intermedi e di Weierstrass.

Calcolo differenziale per funzioni di una variabile reale. Derivata di una funzione; regole di derivazione; derivata delle funzioni elementari. Teoremi di Rolle e di Lagrange, loro conseguenze; crescenza e decrescenza. Il teorema di de l'Hôpital. Derivate di ordine superiore; formula di Taylor. Massimi e minimi relativi; funzioni convesse, flessi. Asintoti; studio di funzione.

Calcolo integrale per funzioni di una variabile. Integrale di funzioni continue; proprietà dell'integrale; teorema della media integrale, teoremi fondamentali del calcolo integrale; primitiva di una funzione. Integrazione per parti; integrazione per sostituzione; integrazione di funzioni razionali.

Equazioni differenziali. Equazioni differenziali lineari del primo ordine: integrale generale per equazioni omogenee e non omogenee, il problema di Cauchy. Equazioni differenziali lineari del secondo ordine a coefficienti costanti. Equazioni differenziali a variabili separabili.

Elementi di algebra lineare. Vettori in R^n, operazioni tra vettori. Rette nel piano, rette e piani nello spazio, equazione cartesiana ed equazione parametrica, condizioni di parallelismo e ortogonalità. Matrici e operazioni tra die esse. Forme quadratiche e loro segnatura.

Calcolo differenziale per funzioni di più variabili reali. Funzioni di due variabili, esempi, loro grafico e insiemi di livello.Deﬁnizione di limite per funzioni di due variabili. Deﬁnizione di funzione continua (per funzioni di due variabili). Teorema di Weierstrass. Deﬁnizione di derivata parziale. Deﬁnizione di diﬀerenziabilità e piano tangente al graﬁco di una funzione in un punto. Relazioni varie tra le nozioni di diﬀerenziabilità, continuità e derivabilità. Teorema del diﬀerenziale totale. Deﬁnizione di derivata direzionale. Signiﬁcato geometrico del gradiente. Teorema per il calcolo del gradiente di somme, prodotti, rapporti e composizione di funzioni. Derivate di ordine 2, Teorema di Schwarz, matrice Hessiana, Formula di Taylor al 2nd ordine con resto di Peano. Diﬀerenziale secondo. Deﬁnizione di punto critico. Deﬁnizioni di punto di massimo/minimo (locale e assoluto). Teorema di Fermat. Teorema sulla classiﬁcazione dei punti critici.

## Testi/Bibliografia

M.Bramanti, C.Pagani, S.Salsa, Matematica. Calcolo infinitesimale e algebra lineare,

Zanichelli Editore

M. Bertsch, R. Dal Passo, L. Giacomelli - Analisi Matematica, ed. McGraw Hill. (seconda edizione)

G.C. Barozzi, G. Dore, E. Obrecht: Elementi di Analisi Matematica, vol. 1, ed. Zanichelli.

Marcellini-Sbordone: Elementi di analisi matematica uno (versione semplificata per i nuovi corsi di laurea), Liguori Editore, Napoli 2002.

## Metodi didattici

Il corso prevede lo svolgimento di lezioni di carattere teorico, affiancate da esercitazioni che hanno lo scopo di aiutare lo studente ad acquisire familiarità e padronanza con gli strumenti e metodi matematici introdotti durante le lezioni. Il docente proporrà inoltre esercizi da svolgere a casa, simili a quelli svolti durante le ore di esercitazione, in modo che lo studente possa verificare il proprio livello di apprendimento della materia.

## Modalità di verifica e valutazione dell'apprendimento

L'esame consiste di una prova scritta, della durata di 3 ore. La prova scritta sarà suddivisa in una parte con esercizi (aperti) e una parte con domande di teoria sui vari argomenti trattati nel corso. Il voto massimo ottenibile con la sola prova scritta è 24. Chi ha intenzione di migliorare il voto dello scritto potrà sostenere una prova orale (che quindi è facoltativa). In entrambe le prove non è consentito l'uso di calcolatrici, testi e appunti.

## Strumenti a supporto della didattica

Note del corso ed esercizi disponibili presso la pagina web del docente e la pagina Virtuale, testi consigliati.

## Orario di ricevimento

Consulta il sito web di
                    
                        Cristiano Frattagli

Consulta il sito web di
                        
                            Andrea Bonfiglioli

Consulta il sito web di
                        
                            Andrea Bonfiglioli