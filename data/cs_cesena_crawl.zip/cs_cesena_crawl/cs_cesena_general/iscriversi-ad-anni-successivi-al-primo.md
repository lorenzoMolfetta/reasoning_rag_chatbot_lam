# Iscriversi ad anni successivi al primo

Le due cose da ricordare per proseguire gli studi dopo il primo anno.

## Paga le tasse per il nuovo anno accademico

Finché non consegui il titolo accademico, devi iscriverti ogni anno al corso di studio.
Per farlo paga la prima rata o monorata delle tasse. Verifica indicativamente dal 25 luglio gli importi, le agevolazioni e le scadenze per non incorrere nella mora o non avere interruzioni nella tua carriera studentesca.

Verifica inoltre se possiedi i requisiti di merito o di reddito per usufruire delle borse di studio.

## Se hai la cittadinanza non-UE rinnova il permesso di soggiorno

Se hai un permesso di soggiorno "studente", ricordati che devi rinnovarlo ogni anno per tutta la durata del corso.
Fai domanda di rinnovo almeno 60 giorni prima della scadenza e consegna la copia della domanda alla Segreteria Studenti.
Vai alla procedura di rinnovo

- Sosteniamo il diritto alla conoscenza