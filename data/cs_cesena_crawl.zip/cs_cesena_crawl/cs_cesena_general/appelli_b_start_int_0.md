# Appelli d'esame

Per avere informazioni per sostenere esami  consulta: ESAMI

Per ciascun insegnamento vengono fissati almeno sei appelli nel corso dell'anno.

Consulta il calendario didattico del Corso di Studio

Per verificare gli esami che puoi sostenere in base al tuo piano di studi e per iscriverti agli appelli, accedi ad AlmaEsami o scarica la app MyUnibo.

### 58414
                                            ALGEBRA E GEOMETRIA
                                            MOCI LUCA

| Data e ora:       | 16 giugno 2025 ore 09:00                                                                                                                                                                                                                                                                                      |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 08 maggio 2025                                                         al 13 giugno 2025                                                                                                                                                                                                           |
| Tipo prova:       | Scritto e orale                                                                                                                                                                                                                                                                                               |
| Luogo:            | Aula Magna 3.4                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | gli orali si svolgeranno in aula 2.3. In caso di necessità, gli orali proseguiranno il 19 giugno                                                                                                                                                                                                              |

| Data e ora:       | 23 giugno 2025 ore 09:00                                                                                                                                                                                                                                                                                      |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 03 giugno 2025                                                         al 21 giugno 2025                                                                                                                                                                                                           |
| Tipo prova:       | Scritto e orale                                                                                                                                                                                                                                                                                               |
| Luogo:            | Aula Magna 3.4                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | gli orali si svolgeranno in aula 2.3                                                                                                                                                                                                                                                                          |

| Data e ora:       | 08 luglio 2025 ore 09:00                                                                                                                                                                                                                                                                                      |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 23 giugno 2025                                                         al 06 luglio 2025                                                                                                                                                                                                           |
| Tipo prova:       | Scritto e orale                                                                                                                                                                                                                                                                                               |
| Luogo:            | Aula Magna 3.4                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | gli orali si svolgeranno in aula 2.3                                                                                                                                                                                                                                                                          |

| Data e ora:       | 02 settembre 2025 ore 09:00                                                                                                                                                                                                                                                                      |
|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 18 agosto 2025                                                         al 31 agosto 2025                                                                                                                                                                                              |
| Tipo prova:       | Scritto e orale                                                                                                                                                                                                                                                                                  |
| Luogo:            | Aula 2.3                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 08 settembre 2025 ore 09:00                                                                                                                                                                                                                                                                      |
|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 24 agosto 2025                                                         al 06 settembre 2025                                                                                                                                                                                           |
| Tipo prova:       | Scritto e orale                                                                                                                                                                                                                                                                                  |
| Luogo:            | Aula 2.3                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

### 11929
                                            ALGORITMI E STRUTTURE DATI
                                            MANIEZZO VITTORIO

| Data e ora:       | 12 giugno 2025 ore 09:30                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 12 maggio 2025                                                         al 11 giugno 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 2.4                                                                                            |

| Data e ora:       | 02 luglio 2025 ore 09:30                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 17 giugno 2025                                                         al 30 giugno 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 2.4                                                                                            |

| Data e ora:       | 29 luglio 2025 ore 09:30                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 14 luglio 2025                                                         al 27 luglio 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 2.8                                                                                            |

| Data e ora:       | 03 settembre 2025 ore 09:30                                                                            |
|-------------------|--------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 19 agosto 2025                                                         al 01 settembre 2025 |
| Tipo prova:       | Scritto                                                                                                |
| Luogo:            | Aula 2.8                                                                                               |

### 11929
                                            ALGORITMI E STRUTTURE DATI
                                            MARGARA LUCIANO

| Data e ora:       | 17 giugno 2025 ore 10:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 02 giugno 2025                                                         al 13 giugno 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 2.12                                                                                           |

| Data e ora:       | 15 luglio 2025 ore 10:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 30 giugno 2025                                                         al 11 luglio 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 2.12                                                                                           |

| Data e ora:       | 03 settembre 2025 ore 14:00                                                                         |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 19 agosto 2025                                                         al 29 agosto 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | aula 2.3                                                                                            |

| Data e ora:       | 16 settembre 2025 ore 14:00                                                                               |
|-------------------|-----------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 01 settembre 2025                                                         al 12 settembre 2025 |
| Tipo prova:       | Scritto                                                                                                   |
| Luogo:            | aula 2.3                                                                                                  |

### 70224
                                            ALGORITMI NUMERICI
                                            LAZZARO DAMIANA

| Data e ora:       | 12 giugno 2025 ore 09:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 05 giugno 2025                                                         al 11 giugno 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 12 giugno 2025 ore 12:30                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 05 giugno 2025                                                         al 11 giugno 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 12 giugno 2025 ore 15:30                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 05 giugno 2025                                                         al 11 giugno 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 04 luglio 2025 ore 09:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 19 giugno 2025                                                         al 02 luglio 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 04 luglio 2025 ore 12:30                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 19 giugno 2025                                                         al 02 luglio 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 04 luglio 2025 ore 15:30                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 19 giugno 2025                                                         al 02 luglio 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 18 luglio 2025 ore 09:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 03 luglio 2025                                                         al 16 luglio 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 18 luglio 2025 ore 12:30                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 03 luglio 2025                                                         al 16 luglio 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 18 luglio 2025 ore 15:30                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 03 luglio 2025                                                         al 16 luglio 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 11 settembre 2025 ore 09:00                                                                                                                                                                                                                                                                                                |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 27 agosto 2025                                                         al 09 settembre 2025                                                                                                                                                                                                                     |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 11 settembre 2025 ore 12:30                                                                                                                                                                                                                                                                                                |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 27 agosto 2025                                                         al 09 settembre 2025                                                                                                                                                                                                                     |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 11 settembre 2025 ore 15:30                                                                                                                                                                                                                                                                                                |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 27 agosto 2025                                                         al 09 settembre 2025                                                                                                                                                                                                                     |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

### 00013
                                            ANALISI MATEMATICA
                                            FRATTAGLI CRISTIANO

| Data e ora:       | 07 luglio 2025 ore 14:00                                                                                                                                                                                                                                                                         |
|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 maggio 2025                                                         al 04 luglio 2025                                                                                                                                                                                              |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                          |
| Luogo:            | Aula 2.9                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |
| Note:             | Aula 2.9                                                                                                                                                                                                                                                                                         |

| Data e ora:       | 10 luglio 2025 ore 14:00                                                                                                                                                                                                                                                                          |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 maggio 2025                                                         al 08 luglio 2025                                                                                                                                                                                               |
| Tipo prova:       | Orale                                                                                                                                                                                                                                                                                             |
| Luogo:            | Aula 2.12                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 24 luglio 2025 ore 14:00                                                                                                                                                                                                                                                                          |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 maggio 2025                                                         al 22 luglio 2025                                                                                                                                                                                               |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                           |
| Luogo:            | Aula 2.12                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |
| Note:             | Aula 2.12                                                                                                                                                                                                                                                                                         |

| Data e ora:       | 28 luglio 2025 ore 14:00                                                                                                                                                                                                                                                                         |
|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 maggio 2025                                                         al 26 luglio 2025                                                                                                                                                                                              |
| Tipo prova:       | Orale                                                                                                                                                                                                                                                                                            |
| Luogo:            | Aula 2.9                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 05 settembre 2025 ore 14:00                                                                                                                                                                                                                                                                      |
|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 maggio 2025                                                         al 03 settembre 2025                                                                                                                                                                                           |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                          |
| Luogo:            | Aula 2.9                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 09 settembre 2025 ore 14:00                                                                                                                                                                                                                                                                       |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 maggio 2025                                                         al 07 settembre 2025                                                                                                                                                                                            |
| Tipo prova:       | Orale                                                                                                                                                                                                                                                                                             |
| Luogo:            | Aula 2.12                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

### 69731
                                            ARCHITETTURE DEGLI ELABORATORI
                                            CAPPELLI RAFFAELE

| Data e ora:       | 13 giugno 2025 ore 09:30                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 maggio 2025                                                         al 06 giugno 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 3.7                                                                                            |

| Data e ora:       | 03 luglio 2025 ore 09:30                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 maggio 2025                                                         al 26 giugno 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 2.12                                                                                           |

| Data e ora:       | 21 luglio 2025 ore 09:30                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 maggio 2025                                                         al 14 luglio 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 3.7                                                                                            |

| Data e ora:       | 10 settembre 2025 ore 09:30                                                                            |
|-------------------|--------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 22 maggio 2025                                                         al 03 settembre 2025 |
| Tipo prova:       | Scritto                                                                                                |
| Luogo:            | Aula 2.12                                                                                              |

### 69731
                                            ARCHITETTURE DEGLI ELABORATORI
                                            MALTONI DAVIDE

| Data e ora:       | 13 giugno 2025 ore 09:30                                                                               |
|-------------------|--------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 19 marzo 2025                                                         al 06 giugno 2025     |
| Tipo prova:       | Scritto                                                                                                |
| Luogo:            | Aula 2.1                                                                                               |
| Note:             | Necessario aver consegnato (con successo) elaborati sul sito entro la data indicata dal prof. Ferrara. |

| Data e ora:       | 03 luglio 2025 ore 09:30                                                                               |
|-------------------|--------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 19 marzo 2025                                                         al 26 giugno 2025     |
| Tipo prova:       | Scritto                                                                                                |
| Luogo:            | Aula 2.9                                                                                               |
| Note:             | Necessario aver consegnato (con successo) elaborati sul sito entro la data indicata dal prof. Ferrara. |

| Data e ora:       | 21 luglio 2025 ore 09:30                                                                               |
|-------------------|--------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 19 marzo 2025                                                         al 14 luglio 2025     |
| Tipo prova:       | Scritto                                                                                                |
| Luogo:            | Aula 2.1                                                                                               |
| Note:             | Necessario aver consegnato (con successo) elaborati sul sito entro la data indicata dal prof. Ferrara. |

| Data e ora:       | 10 settembre 2025 ore 09:30                                                                            |
|-------------------|--------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 23 maggio 2025                                                         al 03 settembre 2025 |
| Tipo prova:       | Scritto                                                                                                |
| Luogo:            | Aula 2.12                                                                                              |
| Note:             | Necessario aver consegnato (con successo) elaborati sul sito entro la data indicata dal prof. Ferrara. |

### 10906
                                            BASI DI DATI
                                            FRANCO ANNALISA

| Data e ora:       | 17 giugno 2025 ore 09:30                                                                                                                                                                                                                                                                                                           |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 13 marzo 2025                                                         al 16 giugno 2025                                                                                                                                                                                                                                 |
| Tipo prova:       | Altro                                                                                                                                                                                                                                                                                                                              |
| Luogo:            | Laboratorio informatico 4.2 (CAD)                                                         Piano secondo (livello 4)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 18 giugno 2025 ore 10:00                                                                                                                                                                                                                                                                          |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 13 marzo 2025                                                         al 16 giugno 2025                                                                                                                                                                                                |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                           |
| Luogo:            | Aula 2.12                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 16 luglio 2025 ore 09:30                                                                                                                                                                                                                                                                                                           |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 13 marzo 2025                                                         al 15 luglio 2025                                                                                                                                                                                                                                 |
| Tipo prova:       | Altro                                                                                                                                                                                                                                                                                                                              |
| Luogo:            | Laboratorio informatico 4.2 (CAD)                                                         Piano secondo (livello 4)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 17 luglio 2025 ore 10:00                                                                                                                                                                                                                                                                          |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 13 marzo 2025                                                         al 15 luglio 2025                                                                                                                                                                                                |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                           |
| Luogo:            | Aula 2.12                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 25 agosto 2025 ore 09:30                                                                                                                                                                                                                                                                                                           |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 13 marzo 2025                                                         al 23 agosto 2025                                                                                                                                                                                                                                 |
| Tipo prova:       | Altro                                                                                                                                                                                                                                                                                                                              |
| Luogo:            | Laboratorio informatico 4.2 (CAD)                                                         Piano secondo (livello 4)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 26 agosto 2025 ore 10:00                                                                                                                                                                                                                                                                          |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 13 marzo 2025                                                         al 24 agosto 2025                                                                                                                                                                                                |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                           |
| Luogo:            | Aula 2.12                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 09 settembre 2025 ore 09:30                                                                                                                                                                                                                                                                                                |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 30 maggio 2025                                                         al 07 settembre 2025                                                                                                                                                                                                                     |
| Tipo prova:       | Altro                                                                                                                                                                                                                                                                                                                      |
| Luogo:            | Laboratorio informatico 3.3                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 16 settembre 2025 ore 10:00                                                                                                                                                                                                                                                                       |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 26 maggio 2025                                                         al 14 settembre 2025                                                                                                                                                                                            |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                           |
| Luogo:            | Aula 2.12                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

### 84339
                                            BASI DI DATI AVANZATE
                                            GOLFARELLI MATTEO

| Data e ora:       | 11 giugno 2025 ore 09:00                                                                                                                                                                                                                                                                                                           |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 27 maggio 2025                                                         al 09 giugno 2025                                                                                                                                                                                                                                |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                            |
| Luogo:            | Laboratorio informatico 4.2 (CAD)                                                         Piano secondo (livello 4)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 25 giugno 2025 ore 09:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 10 giugno 2025                                                         al 23 giugno 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 3.3                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 09 luglio 2025 ore 09:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 24 giugno 2025                                                         al 07 luglio 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 3.3                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 11 settembre 2025 ore 09:00                                                                                                                                                                                                                                                                                                |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 27 agosto 2025                                                         al 09 settembre 2025                                                                                                                                                                                                                     |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 3.3                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

### 70090
                                            COMPUTER GRAPHICS
                                            LAZZARO DAMIANA

| Data e ora:       | 11 giugno 2025 ore 09:00                                                                                                                                                                                                                                                                          |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 27 maggio 2025                                                         al 09 giugno 2025                                                                                                                                                                                               |
| Tipo prova:       | Scritto e orale                                                                                                                                                                                                                                                                                   |
| Luogo:            | Aula 2.11                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 15 luglio 2025 ore 09:00                                                                                                                                                                                                                                                                         |
|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 30 giugno 2025                                                         al 13 luglio 2025                                                                                                                                                                                              |
| Tipo prova:       | Scritto e orale                                                                                                                                                                                                                                                                                  |
| Luogo:            | Aula 2.8                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 12 settembre 2025 ore 09:00                                                                                                                                                                                                                                                                      |
|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 28 agosto 2025                                                         al 10 settembre 2025                                                                                                                                                                                           |
| Tipo prova:       | Scritto e orale                                                                                                                                                                                                                                                                                  |
| Luogo:            | Aula 2.8                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

### 10907
                                            ELETTRONICA DEI SISTEMI DIGITALI
                                            LEVI GIUSEPPE

| Data e ora:       | 11 giugno 2025 ore 09:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 26 maggio 2025                                                         al 09 giugno 2025 |
| Tipo prova:       | Orale                                                                                               |
| Luogo:            | Cesena e TEAMS                                                                                      |

| Data e ora:       | 20 giugno 2025 ore 10:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 05 giugno 2025                                                         al 18 giugno 2025 |
| Tipo prova:       | Orale                                                                                               |
| Luogo:            | Cesena e TEAMS                                                                                      |

### 86732
                                            ELETTRONICA PER L'INFORMATICA
                                            LEVI GIUSEPPE

| Data e ora:       | 11 giugno 2025 ore 09:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 26 maggio 2025                                                         al 09 giugno 2025 |
| Tipo prova:       | Orale                                                                                               |
| Luogo:            | Cesena e TEAMS                                                                                      |

| Data e ora:       | 20 giugno 2025 ore 10:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 05 giugno 2025                                                         al 18 giugno 2025 |
| Tipo prova:       | Orale                                                                                               |
| Luogo:            | Cesena e TEAMS                                                                                      |

### 00405
                                            FISICA
                                            GUIDUCCI LUIGI

| Data e ora:       | 23 giugno 2025 ore 14:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 12 maggio 2025                                                         al 18 giugno 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Vedi note                                                                                           |
| Note:             | Aula Magna + Aula 2.12. Seguirà comunicazione agli studenti iscritti sull'aula assegnata.           |

| Data e ora:       | 27 giugno 2025 ore 09:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 24 giugno 2025                                                         al 26 giugno 2025 |
| Tipo prova:       | Altro - Iscrizione per verbalizzare                                                                 |
| Luogo:            | Vedi note                                                                                           |
| Note:             | Iscrizione a questa prova per confermare il voto dello scritto - non occorrerà fare altro.          |

| Data e ora:       | 27 giugno 2025 ore 09:00                                                                                                                                                                                                                                                                          |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 24 giugno 2025                                                         al 26 giugno 2025                                                                                                                                                                                               |
| Tipo prova:       | Orale                                                                                                                                                                                                                                                                                             |
| Luogo:            | Aula 2.10                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 07 luglio 2025 ore 09:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 02 giugno 2025                                                         al 03 luglio 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Vedi note                                                                                           |
| Note:             | Aula Magna + Aula 2.12. Seguirà comunicazione agli studenti iscritti sull'aula assegnata.           |

| Data e ora:       | 11 luglio 2025 ore 09:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 08 luglio 2025                                                         al 10 luglio 2025 |
| Tipo prova:       | Altro - Iscrizione per verbalizzare                                                                 |
| Luogo:            | Vedi note                                                                                           |
| Note:             | Iscrizione a questa prova per confermare il voto dello scritto - non occorrerà fare altro.          |

| Data e ora:       | 11 luglio 2025 ore 09:00                                                                                                                                                                                                                                                                          |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 08 luglio 2025                                                         al 10 luglio 2025                                                                                                                                                                                               |
| Tipo prova:       | Orale                                                                                                                                                                                                                                                                                             |
| Luogo:            | Aula 2.10                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 21 luglio 2025 ore 09:00                                                                                                                                                                                                                                                                                      |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 06 luglio 2025                                                         al 19 luglio 2025                                                                                                                                                                                                           |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                       |
| Luogo:            | Aula Magna 3.4                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | Aula Magna + Aula 2.12. Seguirà comunicazione agli studenti iscritti sull'aula assegnata.                                                                                                                                                                                                                     |

| Data e ora:       | 25 luglio 2025 ore 09:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 10 luglio 2025                                                         al 24 luglio 2025 |
| Tipo prova:       | Altro - Iscrizione per verbalizzare                                                                 |
| Luogo:            | Vedi note                                                                                           |
| Note:             | Iscrizione a questa prova per confermare il voto dello scritto - non occorrerà fare altro.          |

| Data e ora:       | 25 luglio 2025 ore 09:00                                                                                                                                                                                                                                                                          |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 22 luglio 2025                                                         al 24 luglio 2025                                                                                                                                                                                               |
| Tipo prova:       | Orale                                                                                                                                                                                                                                                                                             |
| Luogo:            | Aula 2.10                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |

### 35504
                                            FONDAMENTI DI ELABORAZIONE DI IMMAGINI
                                            CAPPELLI RAFFAELE

| Data e ora:       | 17 giugno 2025 ore 09:30                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 20 maggio 2025                                                         al 13 giugno 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 3.7                                                                                            |

| Data e ora:       | 01 luglio 2025 ore 09:30                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 20 maggio 2025                                                         al 27 giugno 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 3.7                                                                                            |

| Data e ora:       | 22 luglio 2025 ore 09:30                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 25 giugno 2025                                                         al 18 luglio 2025 |
| Tipo prova:       | Scritto                                                                                             |
| Luogo:            | Aula 2.12                                                                                           |

| Data e ora:       | 15 settembre 2025 ore 09:30                                                                            |
|-------------------|--------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 22 maggio 2025                                                         al 11 settembre 2025 |
| Tipo prova:       | Scritto                                                                                                |
| Luogo:            | Aula 3.7                                                                                               |

### 72778
                                            HIGH-PERFORMANCE COMPUTING
                                            MARZOLLA MORENO

| Data e ora:       | 19 giugno 2025 ore 10:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 marzo 2025                                                         al 16 giugno 2025                                                                                                                                                                                                                         |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 3.3                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | L'esame si svolgerà in presenza tramite la piattaforma EOL (Esami Online).                                                                                                                                                                                                                                                 |

| Data e ora:       | 02 luglio 2025 ore 10:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 marzo 2025                                                         al 28 giugno 2025                                                                                                                                                                                                                         |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 3.1                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | L'esame si svolgerà in presenza tramite la piattaforma EOL (Esami Online).                                                                                                                                                                                                                                                 |

| Data e ora:       | 16 luglio 2025 ore 10:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 15 marzo 2025                                                         al 12 luglio 2025                                                                                                                                                                                                                         |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 3.1                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | L'esame si svolgerà in presenza tramite la piattaforma EOL (Esami Online).                                                                                                                                                                                                                                                 |

### 70227
                                            INFORMATICA E DIRITTO
                                            DALL'ACQUA LUISA

| Data e ora:       | 19 giugno 2025 ore 10:30                                                                                                                                                                                                                                                                                 |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 04 giugno 2025                                                         al 17 giugno 2025                                                                                                                                                                                                      |
| Tipo prova:       | Altro - Verbalizzazione                                                                                                                                                                                                                                                                                  |
| Luogo:            | Aula 3.10                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 03 luglio 2025 ore 10:30                                                                                                                                                                                                                                                                                 |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 18 giugno 2025                                                         al 01 luglio 2025                                                                                                                                                                                                      |
| Tipo prova:       | Altro - Verbalizzazione                                                                                                                                                                                                                                                                                  |
| Luogo:            | Aula 3.10                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

### 66858
                                            INGEGNERIA  DEL SOFTWARE
                                            RIZZI STEFANO

| Data e ora:       | 18 giugno 2025 ore 11:00                                                                                                                                                                                                                                                                                                           |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 04 marzo 2025                                                         al 15 giugno 2025                                                                                                                                                                                                                                 |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                            |
| Luogo:            | Laboratorio informatico 4.2 (CAD)                                                         Piano secondo (livello 4)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | La prova a quiz si terrà (in presenza) utilizzando EOL, e avrà una durata di 20 minuti. Al termine si terrà la prova scritta, durata 40 minuti. Per superare la prova occorre conseguire un punteggio sufficiente sia nella parte a quiz sia in quella scritta.                                                                    |

| Data e ora:       | 07 luglio 2025 ore 11:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 04 marzo 2025                                                         al 04 luglio 2025                                                                                                                                                                                                                         |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |
| Note:             | La prova a quiz si terrà (in presenza) utilizzando EOL, e avrà una durata di 20 minuti. Al termine si terrà la prova scritta, durata 40 minuti. Per superare la prova occorre conseguire un punteggio sufficiente sia nella parte a quiz sia in quella scritta.                                                            |

| Data e ora:       | 10 settembre 2025 ore 14:00                                                                                                                                                                                                                                                                                                        |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 29 aprile 2025                                                         al 07 settembre 2025                                                                                                                                                                                                                             |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                            |
| Luogo:            | Laboratorio informatico 4.2 (CAD)                                                         Piano secondo (livello 4)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | La prova a quiz si terrà (in presenza) utilizzando EOL, e avrà una durata di 20 minuti. Al termine si terrà la prova scritta, durata 40 minuti. Per superare la prova occorre conseguire un punteggio sufficiente sia nella parte a quiz sia in quella scritta.                                                                    |

### 09032
                                            INGEGNERIA DEL SOFTWARE
                                            RIZZI STEFANO

| Data e ora:       | 18 giugno 2025 ore 11:00                                                                                                                                                                                                                                                                                                           |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 04 marzo 2025                                                         al 15 giugno 2025                                                                                                                                                                                                                                 |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                            |
| Luogo:            | Laboratorio informatico 4.2 (CAD)                                                         Piano secondo (livello 4)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | La prova a quiz si terrà (in presenza) utilizzando EOL, e avrà una durata di 20 minuti. Al termine si terrà la prova scritta, durata 40 minuti. Per superare la prova occorre conseguire un punteggio sufficiente sia nella parte a quiz sia in quella scritta.                                                                    |

| Data e ora:       | 07 luglio 2025 ore 11:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 04 marzo 2025                                                         al 04 luglio 2025                                                                                                                                                                                                                         |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 2.2 (Vela)                                                         Piano terra (livello 2)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via Machiavelli                                                         Via dell’Università, 50, Cesena |
| Note:             | La prova a quiz si terrà (in presenza) utilizzando EOL, e avrà una durata di 20 minuti. Al termine si terrà la prova scritta, durata 40 minuti. Per superare la prova occorre conseguire un punteggio sufficiente sia nella parte a quiz sia in quella scritta.                                                            |

| Data e ora:       | 10 settembre 2025 ore 14:00                                                                                                                                                                                                                                                                                                        |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 29 aprile 2025                                                         al 07 settembre 2025                                                                                                                                                                                                                             |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                            |
| Luogo:            | Laboratorio informatico 4.2 (CAD)                                                         Piano secondo (livello 4)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |
| Note:             | La prova a quiz si terrà (in presenza) utilizzando EOL, e avrà una durata di 20 minuti. Al termine si terrà la prova scritta, durata 40 minuti. Per superare la prova occorre conseguire un punteggio sufficiente sia nella parte a quiz sia in quella scritta.                                                                    |

### 25815
                                            LABORATORIO DI BASI DI DATI
                                            GOLFARELLI MATTEO

| Data e ora:       | 11 giugno 2025 ore 09:00                                                                                                                                                                                                                                                                                                           |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 27 maggio 2025                                                         al 09 giugno 2025                                                                                                                                                                                                                                |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                            |
| Luogo:            | Laboratorio informatico 4.2 (CAD)                                                         Piano secondo (livello 4)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 25 giugno 2025 ore 09:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 10 giugno 2025                                                         al 23 giugno 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 3.3                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 09 luglio 2025 ore 09:00                                                                                                                                                                                                                                                                                                   |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 24 giugno 2025                                                         al 07 luglio 2025                                                                                                                                                                                                                        |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 3.3                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

| Data e ora:       | 11 settembre 2025 ore 09:00                                                                                                                                                                                                                                                                                                |
|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 27 agosto 2025                                                         al 09 settembre 2025                                                                                                                                                                                                                     |
| Tipo prova:       | Scritto                                                                                                                                                                                                                                                                                                                    |
| Luogo:            | Laboratorio informatico 3.3                                                         Piano primo (livello 3)                                                         Ex-Zuccherificio – Edificio 1, Ingresso Via dell’Università 50                                                         Via dell’Università, 50, Cesena |

### 72773
                                            LINGUAGGI VISUALI PER IL CONTROLLO DEI SISTEMI
                                            LEVI GIUSEPPE

| Data e ora:       | 11 giugno 2025 ore 09:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 26 maggio 2025                                                         al 09 giugno 2025 |
| Tipo prova:       | Orale                                                                                               |
| Luogo:            | Cesena e TEAMS                                                                                      |

| Data e ora:       | 20 giugno 2025 ore 10:00                                                                            |
|-------------------|-----------------------------------------------------------------------------------------------------|
| Lista iscrizioni: | aperta dal 05 giugno 2025                                                         al 18 giugno 2025 |
| Tipo prova:       | Orale                                                                                               |
| Luogo:            | Cesena e TEAMS                                                                                      |

- 1
- 2
- Successivi 15 elementi

- Sosteniamo il diritto alla conoscenza