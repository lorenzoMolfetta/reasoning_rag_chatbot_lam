# Conciliare studio e lavoro

L'Università di Bologna ti accompagna nel percorso universitario per aiutarti a conciliare le attività di studio con il tuo lavoro.

## Chi può beneficiarne

Le misure previste sono dedicate a chi ottiene il riconoscimento dello status “studente lavoratore” che puoi richiedere, al momento della pubblicazione dell'avviso, se possiedi i seguenti requisiti:

    1. studi in un corso di Laurea, Laurea magistrale a ciclo unico o Laurea magistrale e hai effettuato l’iscrizione all’a.a. 2024/25
    2. hai svolto un’attività lavorativa:
- per almeno 3 mesi, con un impegno di almeno 4 ore la settimana, nei dodici mesi antecedenti alla scadenza dell'avviso
oppure
- per non meno di trenta giornate lavorative nei dodici mesi antecedenti alla scadenza dell'avviso.

## Come fare domanda

Consulta l'avviso per conoscere come fare domanda

Per l’a.a. 2025/26 potrai presentare domanda dal 17 novembre 2025 al 16 gennaio 2026.

La domanda dovrà essere presentata esclusivamente accedendo all’applicativo Studenti Online.
Entro 60 giorni dalla data di chiusura dell’avviso troverai su Studenti Online l’esito della richiesta

Una volta ottenuto il riconoscimento, questo sarà valido per l’intero anno accademico e potrai ripresentare la domanda per tutti gli anni in cui rinnoverai l’iscrizione.

Lo status conseguito sarà visibile ai docenti sul servizio online AlmaEsami.

Servizio Conciliazione studio e lavoro: conciliazione.studiolavoro@unibo.it

## Su cosa potrai contare

Se conseguirai lo status di studentessa o studente che lavora, le misure disponibili da subito – alle quali, nei prossimi mesi, si aggiungeranno altre ora in fase di progettazione – sono le seguenti:

- colloqui dedicati con il docente in modalità telematica;
- servizi di tutorato dedicati per attività di supporto peer to peer.
- flessibilità nelle date degli esami, variabili sulla base delle caratteristiche organizzative del Corso di Studio. Dovrai contattare il docente titolare dell’insegnamento almeno 14 giorni prima della data dell'esame, fornendo tutte le informazioni necessarie. Verranno indicate delle possibilità alternative e ti saranno suggerite le soluzioni compatibili con quanto i singoli Corsi di Studio possono offrirti.

- Sosteniamo il diritto alla conoscenza