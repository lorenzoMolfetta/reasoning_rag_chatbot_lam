# Richiesta riconoscimento attività lavorativa o extra-universitaria in sostituzione del tirocinio

Se hai svolto un’attività extra-universitaria coerente col tuo percorso formativo puoi chiederne il riconoscimento in sostituzione del tirocinio.

Per attività extra-universitaria è da intendersi, di norma, un’attività lavorativa o un’attività a essa assimilabile quale, per esempio, un tirocinio attivato autonomamente tramite altro ente promotore diverso dall’Università.

E’ possibile presentare richiesta di riconoscimento in qualsiasi periodo dell’anno, indipendentemente dall’esistenza di una convenzione tra l’Università e il soggetto ospitante presso cui è stata svolta l’attività extra-universitaria.

Se il tirocinio per cui si chiede il riconoscimento è a scelta, bisogna inserirlo nel piano di studio prima di presentare richiesta.

Solo se il riconoscimento riguarda il tirocinio in preparazione alla prova finale è necessario allegare anche una dichiarazione di fine attività resa dal Docente Relatore della tesi attestante l’effettivo completamento e buon esito dell’attività svolta oggetto della richiesta.

Di norma, come per il tirocinio, non è possibile presentare richiesta per attività svolte presso strutture qualora il titolare, il responsabile, il socio e il dirigente della struttura presso la quale si è svolta l'attività abbiano legami di parentela o affinità entro il 2° grado con lo studente richiedente.

Per chiedere il riconoscimento è necessario presentare alla Segreteria Studenti tramite consegna in presenza su appuntamento o invio postale con posta prioritaria:

- Domanda riconoscimento crediti per attività extra-universitarie (vedi allegato);

- Attestazione attività svolta rilasciata dal Soggetto ospitante (vedi allegato);

- Relazione, da redigersi secondo le modalità normalmente previste per la valutazione del tirocinio curriculare (per saperne di più consulta le informazioni sulla pagina Tirocini del tuo corso di studio).

La richiesta di riconoscimento è valutata dalla Commissione Tirocini.

L’esito della valutazione è comunicato dalla Segreteria Studenti entro gg.60 dalla presentazione della richiesta. In caso di esito positivo, il tirocinio è registrato direttamente in carriera senza incontrare lo studente.

### Moduli

- Attestazione attività svolta rilasciata dal Soggetto ospitante

[
          .pdf
          107Kb
          ]
- Domanda riconoscimento crediti per attività extra-universitarie.

[
          .pdf
          327Kb
          ]

### Contatti

#### Ufficio tirocini

Come ti può aiutare
                    Attivare e gestire un tirocinio curriculare o in preparazione della tesi finale, in Italia e all’estero, al di fuori dei programmi di mobilità internazionale.

E-mail
campuscesena.tirocini@unibo.it

Telefono
+39 0547 338914
Orario telefonico

                            Lunedì
                            11-12
                          

                            Martedì
                            11-12
                          

                            Mercoledì
                            11-12
                          

                            Giovedì
                            11-12

Indirizzo
Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico

Altre informazioni
Prenota per email o telefono un appuntamento online o in presenza.

#### Segreteria studenti

Come ti può aiutare
                    Iscrizioni, cambi di corso, trasferimenti da e verso altri atenei, laurea, diploma supplement e altre procedure.

Nome referente
                      Stefano Macrelli

Sportello virtuale

E-mail
segcesena@unibo.it

Indirizzo
Palazzo Urbinati - Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico

                            Mercoledì
                            9-12

Altre informazioni
Prendi un appuntamento via e-mail per la consegna dei documenti oppure inviali per posta.

- Sosteniamo il diritto alla conoscenza