# Calcolo della media di laurea per laureandi con carriera pregressa (seconda laurea, rinuncia, decadenza)

Cambia il calcolo della media di laurea per i laureandi in possesso di carriera pregressa.

A partire dalla prima sessione di laurea dell’Anno Accademico 2015/2016 (Luglio 2016) saranno introdotte novità riguardo al calcolo della media di laurea per i laureandi in possesso di carriera pregressa (seconda laurea, rinuncia, decadenza).

Conformemente alla linea dell’Ateneo, saranno esclusi dal calcolo della media i voti delle attività riconosciute da precedenti carriere già chiuse (lauree, rinunce e decadenze), fatta eccezione per le singole attività formative conseguite nell’ambito dello stesso corso di studio in cui si consegue il titolo finale (i cosiddetti ‘esami singoli’).

- Sosteniamo il diritto alla conoscenza