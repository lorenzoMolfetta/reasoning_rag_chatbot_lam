# Muoversi in città: agevolazioni e sostenibilità per la comunità Unibo

Abbonamenti TPER agevolati per studenti e personale di Ateneo e bando AlmaBike per gli studenti che amano la bicicletta. Le ultime novità dell'Alma Mater sulla mobilità sostenibile.

### Per informazioni

- Muoversi in città: agevolazioni e sostenibilità per la comunità Unibo

- Sosteniamo il diritto alla conoscenza