# Premio Tesi di Laurea “Ingenio al Femminile”

Il Consiglio Nazionale degli Ingegneri bandisce un concorso a premi riservato a donne ingegnere in tema  di "Intelligenza artificiale per le nuove sfide del 2050". Scadenza: 30 giugno.

Pubblicato il
        13 maggio 2025

### Per informazioni:

- Bando

- Sosteniamo il diritto alla conoscenza