# Borse di studio Studentesse STEM

Legacoop Romagna bandisce 3 borse di studio per studentesse STEM per sostenere la componente femminile nei percorsi di laurea in ambito scientifico, ingegneristico e matematico. Scadenza: 28 aprile.

Pubblicato il
        03 aprile 2025

### Per informazioni:

- Bando

- Sosteniamo il diritto alla conoscenza