# Grazie Marconi!

Dalle telecomunicazioni alla telemedicina

08 aprile 2025 dalle 12:00 alle 14:00

Aula Magna di Psicologia -
                  Evento in presenza

<!-- image -->

Dopo il grande successo della serata "Grazie Marconi!", l'Università di Bologna propone nuove repliche dello spettacolo per continuare a celebrare l'eredità scientifica e tecnologica di Guglielmo Marconi.

Queste nuove date sono pensate per coinvolgere sia gli studenti delle scuole superiori che la cittadinanza, offrendo un'opportunità unica per riscoprire il genio del grande inventore bolognese.

L'ingresso è libero previa iscrizione.

Iscriviti all'evento dell'8 aprile 2025 a Cesena (Aula Magna di Psicologia, Piazza Aldo Moro n. 90, ore 12.00).

- Sosteniamo il diritto alla conoscenza