# Studiare il pianeta: strumenti e metodi per la ricerca nelle Scienze della Terra

Seminario Istituto Nazionale di Geofisica e Vulcanologia (INGV)

27 marzo 2025 dalle 11:00 alle 13:00

Aula magna, Campus di Cesena, via dell'università 50 -
                  Evento in presenza

Micol Todesco - Istituto Nazionale di Geofisica e Vulcanologia (INGV)

in collaborazione con Dipartimento di Informatica – Scienza e Ingegneria e Dipartimento di Ingegneria dell'Energia Elettrica e dell'Informazione

L’Istituto Nazionale di Geofisica e Vulcanologia è l’ente preposto al monitoraggio sismico e vulcanico del territorio, ma è anche un istituto di ricerca per lo studio delle Scienze della Terra, sia essa solida che liquida. Anche se, all’apparenza, si tratta di studiare fenomeni molto specifici (e.g. le onde sismiche, la temperatura del mare, la composizione chimica della lava), la loro complessità richiede l’integrazione di discipline spesso lontane tra loro.  Per capire com'è fatta e come cambia la Terra, abbiamo bisogno di comprenderne la fisica, la chimica, e la dinamica dei fenomeni su scale di tempo che vanno dal secondo della nucleazione di un terremoto alle ere geologiche delle deformazioni tettoniche. Servono quindi strumenti e metodi in grado di misurare parametri diversi, su diverse scale spaziali e temporali; è necessario inoltre raccogliere e gestire grandi quantità di dati, interpretarli sfruttando algoritmi e procedure in grado di identificare e estrarre il segnale rilevante dal rumore di fondo.

La quantità e qualità di dati e osservazioni che oggi sono disponibili non ha precedenti nella storia che richiede un moderno utilizzo di tecniche e procedure per riuscire a migliorare la comprensione del mondo e della Terra e di come funziona.

E a questo punto siamo solo a metà dell’opera. Le scienze della Terra studiano fenomeni che hanno un impatto sulla vita e sulla sicurezza delle persone. Per questo è importante che i risultati della ricerca siano condivisi. Abbiamo quindi bisogno di comunicare a diversi livelli, a partire dalla comunicazione istituzionale guidata da procedure consolidate, per finire con la divulgazione scientifica. Serve utilizzare linguaggi appropriati, ma anche  comprendere il modo in cui le persone percepiscono e reagiscono di fronte ad informazioni che possono influire sulla loro sicurezza. La necessità di una stretta collaborazione con le scienze sociali sta diventando sempre più evidente.

### In evidenza

- Locandina

[
          .pdf
          163Kb
          ]
- EventiINGVCesena

[
          .pdf
          13875Kb
          ]

- Sosteniamo il diritto alla conoscenza