# L’università è per tutte le persone

Diritti, cultura e valore della diversità: ne parliamo durante la Giornata dell’Orientamento il 25 febbraio.

Pubblicato il
        11 febbraio 2025

L’università: un luogo inclusivo, dove le diversità sono riconosciute e per questo valorizzate e rispettate.

Questi gli eventi da segnare:

Come partecipare

Le Giornate dell’Orientamento sono online, la partecipazione è gratuita con iscrizione obbligatoria.

Iscriviti entro il 24 febbraio.

- Sosteniamo il diritto alla conoscenza