# Archivio eventi

23 mag

### StartUp Day 2025

09:15 - 20:30

DUMBO, Via Camillo Casarini 19 Bologna

Se ti appassiona l’innovazione, incontra chi ha creduto in un'idea e l'ha fatta diventare un'opportunità. Iscriviti online.

13 mag

### Per un cv efficace

12:00 - 14:00

Aula 2.5 del Campus di Cesena - via dell'Università, 50 -
                  Evento in presenza

Vieni al seminario a cura del Servizio Orientamento al lavoro e Placement

09 mag

### Job day

09:30 - 15:00

Imola - Aula Magna di Palazzo Vespignani

Il 9 maggio, a Imola, incontra enti e aziende del territorio per scoprire le opportunità di tirocinio e/o di inserimento lavorativo.

10 apr

### Jornada de Puertas Abiertas Virtual

21:30 - 23:00

Online

¿Eres un estudiante latino-americano y te interesa estudiar en Italia? El 10 de abril, descubre lo que significa estudiar y vivir en Unibo. Inscríbete y participa

08 apr

### Career Day - evento di incontro con il mondo del lavoro

Tutto il giorno

Padiglione 33 di BolognaFiere

Incontra le imprese e sperimenta il tuo approccio al mondo del lavoro. Iscriviti ora!

08 apr

### Grazie Marconi!

12:00 - 14:00

Aula Magna di Psicologia -
                  Evento in presenza

Dalle telecomunicazioni alla telemedicina

27 mar

### Studiare il pianeta: strumenti e metodi per la ricerca nelle Scienze della Terra

11:00 - 13:00

Aula magna, Campus di Cesena, via dell'università 50 -
                  Evento in presenza

Seminario Istituto Nazionale di Geofisica e Vulcanologia (INGV)

25 feb

### Incontra il corso alla Giornata dell'Orientamento online 2025

09:30 - 17:00

Ms Teams -
                  Online

Oltre 500 eventi tra le 9:30 e le 17:00 per conoscere i corsi. Iscriviti ora per accedere in anteprima al programma e scegliere quelli che ti interessano.

- Sosteniamo il diritto alla conoscenza