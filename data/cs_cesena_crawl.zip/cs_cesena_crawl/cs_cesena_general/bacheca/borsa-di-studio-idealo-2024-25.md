# Borsa di studio Idealo 2024/25

Borsa di studio completa per un valore totale di 6.000 euro per studenti e studentesse con un'idea innovativa.  Scadenza: 31 marzo

Pubblicato il
        05 febbraio 2025

### Per informazioni:

- Bando

- Sosteniamo il diritto alla conoscenza