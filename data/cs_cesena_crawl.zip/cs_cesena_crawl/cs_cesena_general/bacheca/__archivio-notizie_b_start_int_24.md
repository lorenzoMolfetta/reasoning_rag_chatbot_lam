# Archivio notizie

### Ripassa la matematica con i webinar di AlmaMathematica

Partecipa ai percorsi online gratuiti: docenti o tutor ti aiuteranno a risolve quiz a risposta multipla sugli argomenti matematici presenti nei diversi TOLC. Scopri il calendario dei webinar.

Pubblicato il
                            22 gennaio 2025

### Intelligenza artificiale generativa: policy di Ateneo e casi d'uso

Linee guida, casi concreti e indicazioni operative per usare la GenAI in modo etico e consapevole nel tuo percorso di studi.

Pubblicato il
                            09 gennaio 2025

### Incontro Outgoing bando Erasmus studio 2025-2026

Riunione via Teams martedì 14 gennaio alle ore 13:00

Pubblicato il
                            09 gennaio 2025

### Bando Erasmus+ Studio a.a. 2025/26

Il bando è online candidati entro il 6 febbraio. Fino al 17 gennaio potrai iscriverti alle prove di accertamento linguistico presso il Centro Linguistico di Ateneo.

Pubblicato il
                            08 gennaio 2025

### Ti interessa la sostenibilità globale? Partecipa a Una Europa Virtual Exchanges for Sustainability (UnaVEx)

Incontri multidisciplinari e interculturali prevedono lezioni sul tema della sostenibilità e attività di “Virtual Exchange”, svolte in gruppi internazionali. Registrazioni aperte fino al 1 febbraio

Pubblicato il
                            07 gennaio 2025

- Precedenti 12 elementi
- 1
- 2
- 3

- Sosteniamo il diritto alla conoscenza