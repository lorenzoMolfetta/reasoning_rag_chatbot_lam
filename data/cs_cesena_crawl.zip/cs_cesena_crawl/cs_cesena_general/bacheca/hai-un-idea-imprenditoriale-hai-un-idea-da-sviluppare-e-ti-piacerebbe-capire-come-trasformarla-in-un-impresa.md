# Hai un’idea imprenditoriale? Hai un’idea da sviluppare e ti piacerebbe capire come trasformarla in un’impresa?

ISIHUB Romagna ti offre un percorso formativo gratuito per supportarti nella crescita e accompagnarti in ogni fase de tuo progetto !

Pubblicato il
        19 maggio 2025

A partire da ottobre 2025 saranno attivati più percorsi dedicati ad aspiranti imprenditori e imprenditrici.

In cosa consiste?

- Tutoraggio personalizzato per individuare i tuoi bisogni e i contenuti più adatti a te
- 16 ore di formazione in gruppo
- 14 ore di consulenza individuale
- Networking con esperti e professionisti

Vieni a scoprire di più venerdì 23 maggio 2025 dalle 12:00 alle 14:00 al Campus di Cesena – Via dell’Università, 50 (primo piano).

Per studenti del III anno delle lauree triennali, ai laureandi ed agli studenti del I e II anno delle Lauree Magistrali.

### Per maggiori informazioni:

- Volantino

[
          .pdf
          1330Kb
          ]

- Sosteniamo il diritto alla conoscenza