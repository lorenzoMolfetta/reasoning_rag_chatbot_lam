# Iscriversi all’università: dai test di ammissione alle strategie di studio

Tutto quello che devi conoscere sull’università. Ne parliamo online alla Giornata dell’Orientamento il 25 febbraio.

Pubblicato il
        04 febbraio 2025

Nell'ambito della Giornata dell'Orientamento, online il 25 febbraio, troverai incontri su alcuni temi specifici.
Questi quelli da segnare:

9:30 – 10  "Laurearsi non serve a niente". Falso!

11– 11:30  Esperienza all'estero: opportunità che trasformano

11:30 –12  Come si studia all’università?

16:30 –17  Casa lontano da casa: le esperienze di chi vive fuori sede, tips&amp;tricks per trovare alloggio in tempo

Come partecipare

La Giornata è online, la partecipazione è gratuita con iscrizione obbligatoria.

Iscriviti entro il 24 febbraio.

- Sosteniamo il diritto alla conoscenza