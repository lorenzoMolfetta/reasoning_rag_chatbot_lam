# Archivio notizie

### Emergenza meteo: disposizioni per venerdì 14 marzo 2025

L’allerta meteo riguarda tutto il territorio del Multicampus. Verifica le chiusure di Ateneo.

Pubblicato il
                            13 marzo 2025

### Competenze trasversali: strumenti chiave per il percorso e il lavoro

Dall'information literacy alla divulgazione, dalle neuroscienze alla transizione ecologica, dalla comunicazione alla proprietà intellettuale fino all’occupabilità: iscriviti entro il 25 marzo.

Pubblicato il
                            04 marzo 2025

### Laboratori sul metodo di studio e OrientaLab

Partecipa agli incontri, online o in presenza nei 5 Campus, in cui si lavorerà in maniera interattiva su temi legati all’esperienza universitaria. Consulta il calendario completo e iscriviti.

Pubblicato il
                            04 marzo 2025

### Programma di tirocini Expo 2025 Osaka. Scadenza: 10 marzo

È online il bando di selezione per 24 tirocini curriculari, suddivisi in 2 cicli da 12 tirocini ciascuno, presso il Commissariato Generale per la partecipazione italiana a Expo 2025 Osaka.

Pubblicato il
                            19 febbraio 2025

### Vuoi iscriverti all’università ma lavori oppure pratichi sport agonistico: le agevolazioni per far bene tutto

Il 25 febbraio ne parleremo durante la Giornata dell’Orientamento.

Pubblicato il
                            18 febbraio 2025

### L’università è per tutte le persone

Diritti, cultura e valore della diversità: ne parliamo durante la Giornata dell’Orientamento il 25 febbraio.

Pubblicato il
                            11 febbraio 2025

### Borsa di studio Idealo 2024/25

Borsa di studio completa per un valore totale di 6.000 euro per studenti e studentesse con un'idea innovativa.  Scadenza: 31 marzo

Pubblicato il
                            05 febbraio 2025

### Iscriversi all’università: dai test di ammissione alle strategie di studio

Tutto quello che devi conoscere sull’università. Ne parliamo online alla Giornata dell’Orientamento il 25 febbraio.

Pubblicato il
                            04 febbraio 2025

### “Un Tour per l’inclusione”- Tappa di Bologna

Il 7 febbraio, partecipa all'evento presso l’impianto CUS Record: un pomeriggio di sport e inclusione, in cui potrai partecipare ai tornei di Sitting Volley e alla staffetta.

Pubblicato il
                            30 gennaio 2025

### Servizi e benefici per chi si trova in situazioni di difficoltà

Se studi all’Unibo e ti trovi in condizioni di difficoltà personale, familiare o economica, puoi partecipare entro il 4 marzo al bando 2024/25 in collaborazione con ER.GO.

Pubblicato il
                            29 gennaio 2025

### Riduzione tasse per laureandi con specifici requisiti e in debito della sola prova finale

Se sei iscritto da un numero di anni superiore alla durata normale del corso aumentata di uno e ti manca solo la prova finale puoi avere una riduzione delle tasse. Scadenza: 18 marzo.

Pubblicato il
                            28 gennaio 2025

### Qual è la condizione abitativa della popolazione studentesca? Aiutaci a capirlo compilando il questionario

Il problema dell’alloggio ostacola il diritto allo studio. L'indagine aiuterà a comprenderlo, dialogare con gli interlocutori e trovare soluzioni concrete.

Pubblicato il
                            27 gennaio 2025

- Precedenti 12 elementi
- 1
- 2
- 3
- Successivi 5 elementi

- Sosteniamo il diritto alla conoscenza