# Tutor del Corso

Il tutor del corso di studio costituisce un utile punto di riferimento per gli studenti nei rapporti con i docenti ed in generale nell'organizzazione delle attività relative al proprio percorso.

## Le funzioni

Il tutor svolge una funzione di interfaccia tra gli studenti e il corso e offre un punto di riferimento concreto per reperire informazioni, ad esempio, sulle modalità di accesso al Corso e lo svolgimento delle attività didattiche.  
Gli studenti possono rivolgersi al tutor anche per segnalare eventuali richieste relative ad aspetti logistici o organizzativi.

Il tutor svolge, inoltre, un'attività di sostegno personalizzato all'apprendimento per quegli studenti, che per ragioni lavorative o altro, abbiano maggiori difficoltà a mantenere una chiara programmazione degli studi e degli esami.

### Contatti

#### Tutor del corso

Come ti può aiutare
                    Dalla scelta del corso all’orario delle lezioni, dalla compilazione del piano di studi agli esami o alle indicazioni per la tesi. Studia come te, può consigliarti su come organizzare gli studi.

Nome referente
                      Filippo Berveglieri

E-mail
campuscesena.tutorltisi@unibo.it

Altre informazioni
Riceve su appuntamento tramite e-mail.

- Sosteniamo il diritto alla conoscenza