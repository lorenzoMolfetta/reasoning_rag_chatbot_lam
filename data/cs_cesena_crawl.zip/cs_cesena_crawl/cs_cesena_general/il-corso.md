# Il Corso

<!-- image -->

## Profilo

- Esplora il Corso
- Presentazione
- Insegnamenti: piano didattico
- Obiettivi formativi
- Cosa dicono i nostri studenti
- Prospettive
- Docenti
- Risultati di apprendimento attesi
- Ordinamento a.a. 2024/25
- Classi L-8 - Ingegneria dell'Informazione e  L-31 - Scienze e Tecnologie Informatiche

<!-- image -->

## Organizzazione e Qualità

- Coordinatore e Consiglio di Corso
- Tutor del Corso
- Rappresentanti degli studenti
- Servizi di orientamento
- Commissione di gestione AQ e altre
- Sistema di assicurazione di qualità
- Aule, laboratori e biblioteche
- Segreteria e uffici
- Qualità: il Corso in cifre
- Comitato Consultivo
- Opinioni della comunità studentesca

### Regolamenti

- Regolamento didattico
- Regolamento Studenti d'Ateneo

- Sosteniamo il diritto alla conoscenza