# Aule, laboratori e biblioteche

La sede del Corso ospita diverse strutture e spazi che ti consentono di svolgere le attività didattiche e ti supportano nel tuo percorso di studi e di ricerca professionale e culturale.

Le aule

Nella sede di Cesena sono disponibili numerose aule per lo svolgimento dell'attività didattica, distribuite nelle varie strutture. Tutte dotate di sistema WIFI gratuito d’Ateneo, possono avere differenti attrezzature e capienza.

I laboratori

Nei laboratori didattici si svolge l'attività di supporto ai corsi, quelli di base e quelli avanzati. Gli studenti possono utilizzare i laboratori didattici sia durante lo svolgimento dell'attività didattica, con la guida dei docenti e dei tutor, sia al di fuori dell'orario di lezione, per esercitazioni e approfondimenti individuali o di gruppo. L'attività nei laboratori didattici, sia guidata sia autonoma, rappresenta un elemento fondamentale nel percorso formativo degli studenti dei corsi di Ingegneria.

La biblioteca

La Sezione Centrale della Biblioteca "Leon Battista Alberti" del Campus di Cesena è la Biblioteca di riferimento. I suoi servizi sono rivolti principalmente agli utenti istituzionali (studenti, personale docente e ricercatore, personale tecnico amministrativo), ma è aperta ad ogni tipologia di utenza.

Sale studio

Le sale studio Alfa Albatros e Beta, aperte con orario continuato e fino a tarda sera, arricchiscono notevolmente le opportunità di studio e costituiscono un importante servizio a favore degli universitari cesenati.

- Sosteniamo il diritto alla conoscenza