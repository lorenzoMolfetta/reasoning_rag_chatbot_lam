# Presentazione

L'informatica a Cesena.

<!-- image -->

Il corso forma professionisti in grado di progettare, sviluppare e gestire sistemi e applicazioni in ambito informatico, fornendo una cultura scientifica e ingegneristica di base e una conoscenza approfondita delle tecniche e metodologie di progettazione e di strumenti attuali per la realizzazione di soluzioni informatiche, che permettono l’ingresso diretto nel mondo del lavoro.

Il corso offre agli studenti la possibilità di studiare l’informatica in modo completo, approfondendo sia aspetti di tipo matematico/scientifico, sia di tipo progettuale/ingegneristico, con particolare riferimento alle più avanzate metodologie di progettazione e realizzazione di sistemi software. Il corso di laurea fornisce le competenze teorico-pratiche relative alle principali aree dell’informatica: tecniche di progettazione e programmazione del software, dei sistemi operativi, dei sistemi informativi, delle reti di calcolatori, delle infrastrutture web e delle architetture computazionali e in cloud. A queste conoscenze di base si aggiungono poi conoscenze approfondite e professionalizzanti in specifici settori dell’informatica che preparano i laureati all’ingresso diretto nel mondo del lavoro.

Il raggiungimento di questi obiettivi richiede di acquisire una cultura scientifica di base nonché un metodo di analisi e di studio scientifici che permettano allo studente di costruire autonomamente nuove conoscenze al fine di adeguarsi alla continua evoluzione della disciplina e di utilizzare metodi innovativi e attrezzature complesse. Il raggiungimento di tali obiettivi formativi è reso possibile grazie ad attività formative finalizzate ad acquisire conoscenze matematiche di base, oltre a conoscenze fondamentali sulle principali aree dell’informatica (tra le quali linguaggi di programmazione, algoritmi, sistemi operativi, basi di dati e sistemi informativi) affiancate ad attività progettuali e di laboratorio.

<!-- image -->

La possibilità di iniziare un percorso di specializzazione verso tematiche di specifico interesse dello studente si apre al terzo anno con un’ampia scelta di corsi complementari in numerosi ambiti, tra i quali sistemi embedded, dispositivi mobili, applicazioni di intelligenza artificiale, sistemi complessi a microcomponenti in cloud, diritto dell’informatica.

Il laureato in Ingegneria e Scienze Informatiche si collocherà facilmente nel mondo del lavoro ma potrà scegliere di proseguire la propria formazione in un corso di laurea magistrale.

Puoi trovare qui risposte alle domande sulle classi L-8 e L-31

### In evidenza

- Brochure del corso

[
          .pdf
          1343Kb
          ]

- Sosteniamo il diritto alla conoscenza