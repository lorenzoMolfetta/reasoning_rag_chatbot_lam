# Rappresentanti degli studenti

Periodicamente gli studenti del Corso eleggono i propri rappresentanti per proporre e sostenere le proprie istanze presso il Consiglio di Corso, di cui sono componenti.

Le modalità di elezione e la durata del mandato sono definiti nell'apposito Regolamento d’Ateneo.

Per il Corso di Studio in Ingegneria e Scienze Informatiche  non vi sono attualmente rappresentanti in carica

- Sosteniamo il diritto alla conoscenza