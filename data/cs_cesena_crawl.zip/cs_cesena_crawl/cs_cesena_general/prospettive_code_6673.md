# Prospettive

Se devi iscriverti fai riferimento al codice 6673.
 Se sei già iscritto puoi verificare il codice del tuo corso su Studenti Online.

- Codice 6673
- Codice 8615

6673 - Ingegneria e scienze informatiche

## Profili professionali

### Analista, Progettista e Programmatore di Software

#### Funzione in un contesto di lavoro

L'Analista, progettista e programmatore di software è generalmente incaricato dell'analisi, progettazione e sviluppo di nuove applicazioni informatiche e/o dell'evoluzione di applicazioni software esistenti. La sua collocazione naturale è in aziende del settore ICT che producono software e applicazioni, e in aziende dotate di un centro elaborazione dati interno; più in generale trova collocazione in tutte le aziende, le pubbliche amministrazioni, i centri di elaborazione dati e le società di servizi che devono gestire dati attraverso strumenti/procedure di tipo informatico.

La figura professionale in oggetto si occupa di:
- sviluppare applicazioni che operano su architetture complesse;
- progettare sistemi informativi e database di media complessità;
- sviluppare applicazioni basate sulle tecnologie e i linguaggi legati al mondo web;
- sviluppare applicazioni per reti di calcolatori e architetture distribuite;
- progettare e sviluppare sistemi informatici, costituiti da microservizi (container), resilienti, scalabili e dispiegati in cloud;
- eseguire test e collaudo di applicazioni informatiche;
- redigere documentazione tecnica.

#### Competenze associate alla funzione

Per lo svolgimento delle funzioni sopra descritte sono richieste conoscenze, capacità e abilità in ambito informatico, tra cui:
- l'utilizzo delle tecniche di ingegneria del software per il progetto di applicazioni e i rudimenti delle tecniche di controllo versione abilitanti i processi di sviluppo agili;
- l'utilizzo dei principali linguaggi e ambienti di programmazione;
- le conoscenze riguardanti gli ambiti di basi di dati, reti di calcolatori e tecnologie web;
- le conoscenze riguardanti l'ambito dei sistemi operativi, le tecniche di virtualizzazione, le metodologie devops;
- l'utilizzo di algoritmi e tecniche numeriche per la soluzione di problemi di ottimizzazione.

Il CdS permette di approfondire maggiormente competenze concernenti:
- strumenti di base per elaborare immagini e per individuare e riconoscere oggetti in immagini e video;
- sviluppo di applicazioni native (Kotlin per Android e Swift per iOS) e ibride per piattaforme mobili;
- sistemi embedded, IoT e real-time basati su RTOS;
- applicazioni di computer grafica;
- progettazione di basi di dati NoSQL;
- fondamenti e applicazioni di machine learning e analisi dei dati per l'intelligenza artificiale;
- algoritmi crittografici a supporto della sicurezza dei sistemi e delle informazioni;
- sviluppo di applicazioni resilienti e scalabili a microservizi (container) in cloud;
- concetti giuridici di base rilevanti per il settore informatico (protezione dei dati, proprietà industriale e intellettuale, regole di responsabilità).

Oltre a capacità di auto-apprendimento e di aggiornamento continuo, sono richieste infine adeguate competenze trasversali di tipo comunicativo-relazionale, organizzativo-gestionale e di pianificazione.

#### Sbocchi occupazionali

I principali sbocchi occupazionali sono:
- Esperto di architetture software;
- Analista di procedure informatiche;
- Progettista di software applicativo.

Tali sbocchi potranno essere esercitati principalmente presso:
- Aziende di sviluppo software;
- Aziende del settore ICT;
- Aziende del settore manifatturiero che utilizzano sistemi ICT a supporto della produzione;
- Centri di elaborazione dati di aziende;
- Settore ricerca e sviluppo di aziende legate al settore ICT;
- Università ed enti pubblici e privati.

### Amministratore di Sistemi Informatici

#### Funzione in un contesto di lavoro

L'Amministratore di sistemi informatici installa, configura e gestisce software di base e d'ambiente e in particolare: sistemi operativi, sistemi e gestione di basi di dati, sistemi web. Sebbene la sua specializzazione prevalente sia nell'ambito del software, conosce e gestisce apparati hardware e reti. La sua collocazione naturale è in aziende del settore ICT che producono software e applicazioni e in aziende dotate di un centro elaborazione dati interno; più in generale trova collocazione in tutte le aziende, le pubbliche amministrazioni, i centri di elaborazione dati e le società di servizi che devono gestire dati attraverso strumenti/procedure di tipo informatico.

La figura professionale in oggetto si occupa di:
- amministrare sistemi operativi, web server e application server;
- gestire e configurare server fisici, server virtuali, piccoli cluster on premise e piccoli cloud privati;
- realizzare e gestire infrastrutture di elaborazione e comunicazione;
- configurare e gestire apparati e protocolli di rete;
- installare, configurare e amministrare sistemi di gestione di database;
- configurare e gestire infrastrutture virtuali in cloud secondo l'approccio Infrastructure as Code (IaC);
- utilizzare i servizi di directory per piccole organizzazioni, basati su Microsoft Active Directory;
- gestire gli aspetti essenziali di cybersecurity dei sistemi informatici tenendo anche conto del profilo di rischio connesso al loro funzionamento;
- eseguire test e collaudo di applicazioni informatiche;
- redigere documentazione tecnica.

#### Competenze associate alla funzione

Per lo svolgimento delle funzioni sopra descritte sono richieste specifiche conoscenze, capacità e abilità di tipo specialistico in ambito tecnico-scientifico. Può essere necessaria una maggiore specializzazione e capacità di approfondimento in uno o più settori di professionalizzazione. Oltre a capacità di auto-apprendimento e di aggiornamento continuo, sono richieste adeguate competenze trasversali di tipo comunicativo-relazionale, organizzativo-gestionale e di programmazione, in accordo con il livello di autonomia e responsabilità assegnato, con le modalità organizzative e di lavoro adottate e con i principali interlocutori (colleghi, altri professionisti e clienti pubblici e/o privati).

Per lo svolgimento delle funzioni sopra descritte sono richieste conoscenze, capacità e abilità in ambito informatico, tra cui:
- l'utilizzo dei principali linguaggi e ambienti di programmazione;
- la conoscenza approfondita di sistemi operativi, tecniche e piattaforme di virtualizzazione, applicazioni client-server e le basi minime delle metodologie devops;
- le conoscenze riguardanti gli ambiti di basi di dati, reti di calcolatori e tecnologie web.

Il CdS permette di approfondire ulteriormente competenze specifiche in:
- interfacce e protocolli di comunicazione;
- sistemi embedded, IoT e real-time basati su RTOS, e componenti e sistemi elettronici programmabili ad elevato livello di integrazione;
- piattaforme di virtualizzazione in cloud e per cluster on-premise;
- sviluppo e dispiegamento di applicazioni resilienti e scalabili a microservizi (container) in cloud;
- servizi di directory come Microsoft Active Directory e Samba per l'amministrazione dei sistemi informatici di piccole organizzazioni.

Oltre a capacità di auto-apprendimento e di aggiornamento continuo, sono richieste infine adeguate competenze trasversali di tipo comunicativo-relazionale, organizzativo-gestionale e di pianificazione.

#### Sbocchi occupazionali

I principali sbocchi occupazionali sono:
- Gestore di sistemi operativi;
- Gestore di reti informatiche;
- Progettista e gestore di infrastrutture Web;
- Amministratore di database;
- Sviluppatore e Amministratore di Infrastrutture virtuali dispiegate via software (modello IaC), in cloud o in cluster on-premise;
- Utilizzatore di sistemi informatici basati su servizi di directory (Microsoft Active Directory e Samba), per piccole organizzazioni.

Tali sbocchi potranno essere esercitati principalmente presso:
- Aziende di sviluppo software;
- Aziende del settore ICT;
- Aziende del settore manifatturiero che utilizzano sistemi ICT a supporto della produzione;
- Centri di elaborazione dati di aziende;
- Settore ricerca e sviluppo di aziende legate al settore ICT;
- Università ed enti pubblici e privati.

## Proseguire gli studi

Dà accesso agli studi di secondo ciclo (laurea specialistica / magistrale) e master universitario di primo livello.

### Archivio

- Sosteniamo il diritto alla conoscenza