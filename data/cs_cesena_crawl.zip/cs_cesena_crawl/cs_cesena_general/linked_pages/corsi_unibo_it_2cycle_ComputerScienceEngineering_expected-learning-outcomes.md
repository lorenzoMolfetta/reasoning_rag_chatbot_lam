# Expected learning outcomes

If you haven’t enrolled yet, please look at code 6699.
 If you have already enrolled, the course code is available in Studenti Online.

- Codice 6699
- Codice 8614

8614 - Computer Science and Engineering

This content is not currently available.

### Archive

- Support the right to knowledge