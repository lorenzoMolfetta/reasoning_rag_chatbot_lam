# Continuing your university studies: What’s in it for you?

What you can rely on to make an informed choice. Join us at the Virtual Fair – Master's programmes on February 26

Published on
        04 February 2025

At the Virtual Fair, you will find sessions on specific topics. 
 Check these events (in Italian only):

10 a.m. – 10:30 a.m.  Proseguire gli studi: intrecciare connessioni e possibilità

11 a.m. – 12 p.m.  Borse di studio: studiare oltre le possibilità economiche

12 p.m. – 1 p.m.  Strategie per la scelta della laurea magistrale

3:30 p.m. – 4:30 p.m.  Come conciliare lavoro o carriera sportiva con lo studio

4:30 p.m. – 5 p.m.  Vivere fuori sede: esperienze e consigli per trovare alloggio

How to participate

The Virtual Fair will be held online. Participation is free, with compulsory registration.  
You can register until 25 February.

- Support the right to knowledge