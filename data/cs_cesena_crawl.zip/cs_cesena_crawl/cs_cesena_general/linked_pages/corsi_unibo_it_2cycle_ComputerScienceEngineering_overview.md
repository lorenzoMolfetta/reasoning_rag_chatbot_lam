# Overview

The programme stands out for its balance between theory and practice, integrating engineering, scientific, and applied skills in a dynamic, interdisciplinary, and innovative approach. It focuses on technological innovation, artificial intelligence, and digital transformation. Strongly connected to the local business environment, it also offers numerous opportunities for international experiences.

## At a Glance

- Place of teaching

                                  
                                      Cesena
- Language

                                  
                                      English, Italian
- Degree Programme Class
                          
                          
                              LM-18 - Computer science
LM-32 - Computer systems engineering
- Duration

                                  
                                      2 years
- International programmes

                                  
                                      Double/Multiple degree

### Open day

At the moment there are no new events. If you need information, contact the Degree Programme Tutor

## What you will study

You will study computer technologies, software design, and data analysis, balancing theory and practice. In the second year, you will explore advanced topics in Data &amp; Knowledge Engineering and Software Systems Engineering, choosing from a range of courses and developing skills for the design of complex systems.

### Learning activities

You can choose from the proposed paths (curricula), each offering different subjects and topics:

- INTELLIGENT EMBEDDED SYSTEMS
- COMPUTER SCIENCE AND ENGINEERING

### Lecture attendance

Find out more on the 
                    dedicated page

## Professional profiles

The course offers various professional opportunities, equipping you with the skills to pursue qualified roles. Discover the profiles you can aspire to:

- professional profile

## Experiences abroad

In addition to study and internship opportunities abroad, the programme offers various international experiences, including the Intelligent Embedded Systems curriculum with EIT Digital, which combines technical and managerial skills. You will have the chance to collaborate with foreign universities and leading companies, developing your thesis within international research projects.

### International programmes

Double/Multiple degree

## Enrolment, fees and exemptions

## How much does it cost to enrol?

Studying at the University of Bologna is an attainable goal regardless of your financial situation. 
              
Simulate the approximate amount you will need to pay by entering your ISEE value.

              See all information on fees and exemptions: amounts and deadlines.

### The main steps to enrol

Open access
                    
                    

                  To enroll in the programme, follow the steps on the  dedicated page

## 5 reasons to enrol on the degree programme

1. Choose the Intelligent Embedded Systems curriculum: study in English with EIT Digital for an advanced and international learning experience.
2. Experience at the Cesena Campus: study in a modern and dynamic environment with advanced laboratories and an active student community.
3. Multidisciplinary education: integrates engineering, scientific, and applied knowledge for a comprehensive and versatile preparation.
4. Balance between theory and practice: engage in real-world projects and lab activities, combining theoretical models with applied technologies.
5. High satisfaction and employability: 98% of graduates are satisfied, and the employment rate one year after graduation is close to 100%.

## The course in numbers

Some data about the course. Go to  the full page to learn more and read the opinions of those attending it.

- 28%
        International students and students not residing in the region
- 42%
        Graduates aligned to the exam schedule
- 24%
        Graduates with experience abroad
- 98%
        Graduates satisfied with their studies
- 92%
        Graduates who are working
- 8%
        Graduates who are not working but are studying or not looking for work
- 0%
          Graduates who are not working but looking for work

## Course participants' experiences

- Experience Bologna - Student life at the University of Bologna







Watch on YouTube

## Receive programme updates

- Support the right to knowledge