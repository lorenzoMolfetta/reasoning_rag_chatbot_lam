# Preparing the study plan

Information on how to prepare and present a study plan.

## What is a study plan?

The study plan is the complete set of exams that you need to sit in order to graduate. Some exams are compulsory, while others are elective.

Students can choose only exams that are included in the course structure diagram for this programme.

For the Italian curriculum, you can find here a presentation about the profiles you can choose with the "guided choices".

## Who can present a study plan?

A study plan can be presented by properly enrolled students who have paid their tuition fees and, in the case of international students, who hold a valid residence permit.

If you are "fuori corso" (you still haven't completed your exams in the due time), if you transferred from another Programme and/or another University, if you asked for recognition of exams you previously passed, you can fill your study plan, too.

Students who opted for the "percorso flessibile" (part-time student status) or students who wants to choose courses that are part of "restricted access" programmes need to submit their study plan by filling a paper form.

The form can be downloaded through the "Attachment" section and it must be sent to the Students' Office by email: segcesena@unibo.it.

The email must be sent within the due deadlines.

As for the elective courses (D type courses, 12 CFU), students can choose among the proposed courses and the all the courses available in other Master Degree Programmes in Unibo.

If students want to choose courses that are part of Degree Programmes, they need to fill the paper form, too. Their request must be sent to the Students' Administrative procedures Committee, who can approve or reject it.

The paper form must be sent by email to the Students' Office (segcesena@unibo.it). Please do not forget to fill in the part called "Motivation letter".

## 

## When do you need to present a study plan?

You can present and amend your study plan in two periods during the academic year.

The open windows for the 2024/2025 AY are:

- First period: from the 7th of October to the 10th of November 2024

- Second period: from the 10th of February to the 7th of March 2025

Following expiry of the deadlines, the last study plan presented will be deemed valid and no further amendments will be made.

## How to...?

Studenti Online

The study plan can be submitted through Studenti Online by enrolled students who, accessing the website using their University usernames and passwords:
- need to add optional subjects to their plan;
- need to choose a curriculum;
- need to amend choices made in prior years.

After making the desired choices, remember to click on “save” so that your study plan can be presented correctly.

It is also advisable to print a copy of your completed study plan. This copy is in fact the only way to check for formal or substantive errors that might arise after uploading your study plan.

Please remember that you can edit your study plan only during the abovementioned periods.

You can submit your study plan if you are duly enrolled  in the programme and have paid the tuition fees. If you are a non-EU international student, you must also hold a valid Residence Permit.

To submit/change your study plan, you need to access Studenti Online with your University username and password and select the activities you are interested in, then click on “save”.

If you are a part-time student or if you want to choose an activity from a degree programme with restricted access, you have to fill in  a paper form which will be available on this page and you have to send it to the Student Administration Office at segcesena@unibo.it , within the deadlines stated above.

Also in case you wish to choose a learning activity from a Bachelor's Degree, you have to fill in the paper form, and the choice will have to be approved by the Degree Programme Board. In the "Motivational Letter" part, please explain the reasons for your choice.

The form will have to be sent to  the Student Administration Office at segcesena@unibo.it.

FINAL EXAMINATION

Please remember that you need to make a choice about your final examination, too, otherwise you won't be able to complete your study plan.

You can choose between:

- FINAL EXAMINATION : 30 ECTS

or

- FINAL EXAMINATION: 6 ECTS

+

one of these options:

- FINAL EXAMINATION PREPARATION ABROAD (18 ECTS)

- INTERNSHIP ABROAD FOR THE FINAL EXAMINATION PREPARATION (18 ECTS)
- INTERNSHIP FOR THE FINAL EXAMINATION PREPARATION (18 ECTS)

FINAL EXAMINATION PREPARATION ABROAD

Changes about the final examination can be done at any time, by sending an e-mail at: segcesena@unibo.it, before taking your final examination or preparation.

if you want to choose the final examination preparation abroad, you need to take part in a Erasmus +, Overseas or a mobility authorised by the Professors of this Master Degree Programme. It is also possible to apply for a study grant for mobility abroad offered by the Department.

If students are willing to leave for their preparation abroad, but study plan filling period is over, they will be able to make their choice through the Learning Agreement (in case of Erasmus + Studio or Overseas) or by informing the Students' Office (in case of a Study grant for mobility award)

INTERNSHIP FOR FINAL EXAMINATION PREPARATION ABROAD

If students want to make this choice, they can add it in their study plan.

If they want to make this choice but study plan filling period is over, the Students' Office will edit their study plan only after students' request for internship which has to be sent to the Internship Office.

As for students having their internship for final examination preparation through the Erasmus + Traineeship Mobility, they will be able to make their choice through the Learning Agreement for Traineeship.

APPROVAL OF YOUR STUDY PLAN

If you select elective subjects from among those offered by the degree programme, there is no need for assessment and your plan is approved automatically and input to your career file.

On the other hand, if you want to choose exams not specifically offered by your degree programme, approval or otherwise will be decided by the Degree Programme Board.

### ATTACHMENTS

- Study plan paper form

[
          .pdf
          52Kb
          ]

- Support the right to knowledge