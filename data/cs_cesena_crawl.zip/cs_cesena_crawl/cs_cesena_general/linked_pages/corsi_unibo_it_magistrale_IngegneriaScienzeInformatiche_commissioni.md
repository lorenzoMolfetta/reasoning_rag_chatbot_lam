# Commissione di gestione AQ e altre

Per svolgere alcune delle sue funzioni il Consiglio di Corso si avvale di commissioni costituite da docenti del corso. Di seguito un elenco delle commissioni con le rispettive funzioni e contatti.

## Commissione di gestione AQ

La Commissione di gestione Assicurazione di Qualità del Corso ha il compito di supportare il Coordinatore nel presidio delle procedure di assicurazione di qualità e nella diffusione della cultura delle qualità.

A questo scopo la Commissione di gestione AQ si occupa di:

- verificare l'attuazione delle azioni di miglioramento approvate annualmente dal Consiglio di Corso nel documento di riesame;
- monitorare l'andamento delle carriere degli studenti, la loro opinione sulle attività formative, la soddisfazione al termine del percorso formativo e la condizione occupazionale dei laureati;
- condividere con il Consiglio di Corso i risultati del monitoraggio svolto.

L’Ateneo ha previsto che la Commissione di gestione AQ del Corso di studio sia composta  dal Coordinatore coadiuvato da altri componenti del Consiglio di Corso di studio inclusi i rappresentanti degli studenti:

- Prof.ssa Annalisa Franco, Coordinatrice del Corso di Studi
- Prof. Alessandro Ricci, vice coordinatore
- Prof. Mario Bravetti
- Prof. Mirko Viroli
- Prof. Matteo Ferrara
- Dott. Gabriele D'Angelo
- Dott. Roberto Girau
- Dott. Giovanni Ciatto

## Commissione Didattica

La Commissione didattica coadiuva il Coordinatore di Corso di studio per le attività inerenti al buon funzionamento e coordinamento dell'attività didattica.

Componenti della commissione:

- Prof.ssa Annalisa Franco
- Prof. Mirko Viroli
- Prof. Matteo Ferrara
- Prof. Alessandro Ricci
- Prof.ssa Antonella Carbonaro
- Prof. Mario Bravetti
- Dott. Gabriele D’Angelo
- Dott. Roberto Girau
- Dott. Giovanni Ciatto

## Commissione Pratiche Studenti

La commissione pratiche studenti effettua il riconoscimento dei crediti formativi acquisiti in altri corsi di studio di questo o di altri atenei, comprese le abbreviazioni di corso. Esamina i piani di studio: scelte libere e piani di studio individuali. Gestisce l’accettazione corsi singoli ed eventuali richieste studenti.

Componenti della commissione:

- Prof. Alessandro Ricci (Presidente)
- Prof. Andrea Roli
- Prof. Roberto Girau

## Commissione Tirocinio in preparazione della prova finale

La commissione approva le domande di tirocinio per tesi.

Componenti della commissione

- Prof.ssa Damiana Lazzaro (approvazione inizio tirocinio e riconoscimento attività lavorativa o extra-universitaria in sostituzione del tirocinio in preparazione della prova finale);
- Prof. Annalisa Franco (valuta e verbalizza l'attività formativa in preparazione della prova finale)
- Prof. Mario Bravetti (valuta e verbalizza l'attività formativa in preparazione della prova finale)

## Commissione pratiche studenti EIT e IES

Componenti della commissione:

Prof. Andrea Roli

Prof. Franco Callegati

Prof. Mirko Viroli

## Commissione Orientamento

La Commissione organizza iniziative volte a fornire informazioni sui contenuti del Corso di Laurea, consentendo ai futuri studenti di prendere una decisione più consapevole in merito all'iscrizione.

Referente

Prof.ssa Alessandra Lumini

## Commissione Internazionalizzazione

La Commissione relazioni internazionali si occupa di valutare i Learning Agreement presentati dagli studenti outgoing e seguire gli stessi prima della partenza e durante il periodo all'estero nella scelta degli insegnamenti.

Componenti della commissione:

- Prof. Andrea Roli (Presidente)
- Prof. Vittorio Maniezzo
- Prof. Giovanni Ciatto

Contatti: campuscesena.internazionalizzazioneingegneria@unibo.it

- Sosteniamo il diritto alla conoscenza