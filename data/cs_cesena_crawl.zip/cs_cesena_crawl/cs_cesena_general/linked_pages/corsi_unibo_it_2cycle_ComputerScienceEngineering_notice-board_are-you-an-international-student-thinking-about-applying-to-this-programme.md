# Are you an international student thinking about applying to this programme?

Join our Virtual Fair on 26 February for Master's programmes and learn how to make it happen!

Published on
        18 February 2025

During the Virtual Fair – Master's programmes on 26 February you will find all the information you need to get started at Unibo, particularly:

- General information about the admission and enrolment process

- Pre-enrolment and immigration procedures for non-EU students

- Study grants and subsidies

- Services and opportunities available to you during your studies.

Register now, you have until 25 February.

Access the preview from 18 February and choose the events you want to attend!

- Support the right to knowledge