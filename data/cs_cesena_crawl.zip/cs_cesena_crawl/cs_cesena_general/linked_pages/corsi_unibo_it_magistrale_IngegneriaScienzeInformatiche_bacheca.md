# Bacheca

## Bandi

Mi interessa se: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando per il programma di mobilità internazionale TNE - Studio

Scadenza: 14 nov 2025

Mi interessa se: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di Concorso per n. 1 assegno di tutorato per la realizzazione di materiale didattico accessibile per studenti con disabilità e con DSA Sede di Bologna

Scadenza: 31 lug 2025, 13:00

Mi interessa se: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di concorso per n. 11 assegni di tutorato di Area medico - scientifica - tecnologica per attività a supporto degli studenti con disabilità e con DSA presso il Servizio per studenti con disabilità e con DSA sedi di Bologna e Campus della Romagna

Scadenza: 31 lug 2025, 13:00

Mi interessa se: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di concorso per l’assegnazione di contributi a favore di studenti con disabilità e a favore di studenti con disturbi dell’apprendimento iscritti all’A.A. 2024/2025

Scadenza: 17 giu 2025, 17:00

Consulta le borse di studio, gli esoneri, gli incentivi e i prossimi bandi in uscita.

Vai al sito dei bandi di Ateneo

## Notizie

### Pubblicato bando CV Italiano Ingegneria e scienze informatiche 25/26

Leggi attentamente il bando e segui i passi per l'iscrizione

### Premio di laurea Bernardo Nobile

L’Area Science Park bandisce premi di laurea per valorizzare studi e metodologie relativi alla proprietà intellettuale e a tecnologie deep tech. Scadenza: 30 giugno.

### Premio Valeria Solesin

Premio di laurea sul tema de “Il talento femminile come fattore determinante per lo sviluppo dell’economia, dell’etica e della meritocrazia nel nostro paese.” Scadenza: 31 luglio.

### Idoneità linguistica.

Scopri quando puoi sostenerla: consulta il calendario delle prossime date e delle iscrizioni.

### Premio tesi di Laurea Antonio Genovesi.

Guida La Fondazione Finanza Etica bandisce un premio per tesi in tema di finanza etica variamente declinata. Scadenza: 19 agosto.

### Premio Tesi di Laurea “Ingenio al Femminile”

Il Consiglio Nazionale degli Ingegneri bandisce un concorso a premi riservato a donne ingegnere in tema  di "Intelligenza artificiale per le nuove sfide del 2050". Scadenza: 30 giugno.

### Premio per tesi “IA prospettive e sfide per le donne della generazione zeta”

FIDAPA con BPW ITALY bandisce un premio per tesi per giovani donne in tema di IA, per favorire la crescita della cultura scientifica nella generazione zeta femminile. Scadenza 30 giugno.

## Eventi

Non ci sono eventi

## Eventi di orientamento

Oggi non ci sono open day

- Sosteniamo il diritto alla conoscenza