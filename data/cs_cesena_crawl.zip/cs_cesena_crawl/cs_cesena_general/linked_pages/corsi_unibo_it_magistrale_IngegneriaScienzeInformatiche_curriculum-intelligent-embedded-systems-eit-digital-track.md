# Curriculum: Intelligent Embedded Systems - EIT Digital track

<!-- image -->

Il curriculum Intelligent Embedded Systems offre due percorsi differenti, ognuno con un proprio processo di ammissione e scadenze diverse. Per i dettagli sulle ammissioni, consulta la pagina dedicata.

Nel percorso locale, gli studenti frequentano entrambi gli anni presso l'Università di Bologna.

Nel percorso in collaborazione con EIT Digital Master School, dopo il primo anno all'Università di Bologna, gli studenti frequentano il secondo anno in una delle università partner in un altro paese europeo, da decidere al momento dell'ammissione.

## Intelligent Embedded Systems - percorso locale

Nel percorso locale, gli studenti possono frequentare sia il primo che il secondo anno presso l'Università di Bologna.

Tuttavia, gli studenti avranno la possibilità di candidarsi ai programmi di mobilità offerti dall'Università di Bologna (Erasmus+, Overseas, preparazione della tesi all'estero...).

Il processo di ammissione e le tasse universitarie sono gestiti direttamente dall'Università di Bologna.

## Intelligent Embedded Systems – percorso EIT Digital Master School

Questa versione del curriculum Intelligent Embedded Systems fa parte dell'EIT Digital Master School. L'Istituto Europeo di Innovazione e Tecnologia (EIT) è un organismo indipendente dell'UE creato per aumentare la capacità di innovazione in Europa attraverso la formazione di talenti imprenditoriali. EIT Digital è il ramo dell'EIT focalizzato sull'innovazione digitale.

Il programma offre un'educazione biennale: il primo anno presso l'Università di Bologna e il secondo presso un'università straniera a scelta tra Budapest, Tallinn, Tampere, Tolone o Turku. Il curriculum ha un focus tecnico sugli Intelligent Embedded Systems, ma include anche 30 CFU su tematiche di innovazione digitale e imprenditorialità. Il primo anno all'Università di Bologna mira a fornire una comprensione approfondita delle tendenze più recenti dell'ingegneria del software per sistemi embedded, con esempi applicativi. Il secondo anno può essere orientato più verso il software o l'hardware e prevede una specializzazione e un progetto di laurea. Il progetto di laurea include un tirocinio presso un'azienda o un istituto di ricerca e porta alla stesura di una tesi di laurea con una forte dimensione innovativa e imprenditoriale.

Parte del curriculum è l'EIT Digital Summer School, un programma di due settimane organizzato in diverse sedi europee e dedicato a cinque aree con sfide e opportunità di business significative per la società e l'industria: Digital Cities, Digital Industry, Digital Wellbeing, Digital Tech e Digital Finance.

L'EIT Digital Master School permette agli studenti di collaborare con partner accademici, di ricerca e industriali in tutta Europa. Come studente, avrai l'opportunità di lavorare con partner industriali dell'EIT e portare innovazioni sul mercato nell'ambito degli studi di Innovazione e Imprenditorialità.

- Sosteniamo il diritto alla conoscenza