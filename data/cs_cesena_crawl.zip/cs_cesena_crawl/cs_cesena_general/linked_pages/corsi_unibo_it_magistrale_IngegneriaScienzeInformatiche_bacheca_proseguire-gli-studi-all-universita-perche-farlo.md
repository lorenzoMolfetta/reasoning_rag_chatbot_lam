# Proseguire gli studi all’università: perché farlo

Su cosa potrai contare per una scelta consapevole. Ne parliamo online alla Giornata di Orientamento il 26 febbraio.

Pubblicato il
        04 febbraio 2025

Durante la Giornata dell'Orientamento, online il 26 febbraio, troverai incontri su alcuni temi specifici.
Questi quelli da segnare:

10 – 10:30 Proseguire gli studi: intrecciare connessioni e possibilità

11 – 12  Borse di studio: studiare oltre le possibilità economiche

12 – 13  Strategie per la scelta della laurea magistrale

15:30 – 16:30  Come conciliare lavoro o carriera sportiva con lo studio

16:30 – 17  Vivere fuori sede: esperienze e consigli per trovare alloggio

Come partecipare

La Giornata è online, la partecipazione è gratuita con iscrizione obbligatoria.

Iscriviti entro il 25 febbraio.

- Sosteniamo il diritto alla conoscenza