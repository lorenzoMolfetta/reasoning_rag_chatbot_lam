# Orario delle lezioni

Consulta il calendario delle lezioni in base all'anno a cui sei iscritto.

Le lezioni nel prossimo a.a. 2024/25 si svolgeranno in presenza.

CALENDARIO DIDATTICO

Potrai visualizzare gli orari dopo aver selezionato anno e curriculum.

### IDONEITA' LINGUA INGLESE B-2

- Idoneità di Lingua Inglese B-2

- Sosteniamo il diritto alla conoscenza