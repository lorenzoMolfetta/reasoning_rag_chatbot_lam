# Studying

<!-- image -->

## Teaching activities

- Course Structure Diagram
- Academic Calendar
- Course Timetable
- Lecture attendance
- Exam dates
- Preparing the study plan
- Faculty
- Classrooms, labs and libraries
- Health and Safety mandatory training

<!-- image -->

## Internship

- Internships abroad

<!-- image -->

## Get ready for the job market

- Ideas for your future: steps you can take
- Entrepreneurship: it is interesting for every student
- Get ready to meet employers

### How to

- Transfer to a study programme running under the new degree programme system
- Changing study programme within the university of Bologna
- Balancing study and work
- Leaving and returning to university
- Activate an alias career
- Obtain student-athlete status
- Residence permit renewal
- Erasmus abroad
- Transferring to another italian university
- From idea to business project
- Information to request certificates and duplicates

- Support the right to knowledge