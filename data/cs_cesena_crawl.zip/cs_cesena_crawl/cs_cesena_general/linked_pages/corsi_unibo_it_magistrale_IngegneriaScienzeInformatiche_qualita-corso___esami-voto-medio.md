# Esami e voto medio conseguito

Elenco degli insegnamenti del Corso con l'indicazione relativa al numero degli esami e al voto medio.

I dati sono relativi all'anno precedente e ogni voce accorpa eventuali articolazioni (moduli, sottogruppi per lettera, esami integrati). 
 Le idoneità non sono comprese nell'elenco.

| Insegnamento                                             |   N. Esami con voto |   Voto medio |
|----------------------------------------------------------|---------------------|--------------|
| SISTEMI INFORMATIVI                                      |                  60 |           27 |
| INTELLIGENT SYSTEMS ENGINEERING                          |                   5 |           30 |
| EMBEDDED SYSTEMS AND INTERNET OF THINGS                  |                   4 |           28 |
| SISTEMI DISTRIBUITI                                      |                  59 |           29 |
| ANALISI DI IMMAGINI 3D E SISTEMI DI COMPUTER VISION      |                   3 |           28 |
| SISTEMI INFORMATIVI E BUSINESS INTELLIGENCE (C.I.)       |                   1 |           24 |
| INSTRADAMENTO E TRASPORTO IN INTERNET                    |                   8 |           27 |
| SMART VEHICULAR SYSTEMS                                  |                  11 |           30 |
| SVILUPPO DEI SISTEMI SOFTWARE (C.I.)                     |                  52 |           28 |
| NETWORKS AND OPERATING SYSTEM                            |                   3 |           26 |
| BIG DATA                                                 |                  27 |           26 |
| SOFTWARE ENGINEERING FOR INTELLIGENT DISTRIBUTED SYSTEMS |                   2 |           27 |
| CYBERSECURITY                                            |                  62 |           26 |
| WEB SEMANTICO                                            |                  53 |           29 |
| LABORATORIO DI SISTEMI SOFTWARE                          |                  36 |           29 |
| SISTEMI AUTONOMI                                         |                   2 |           29 |
| LABORATORY OF NETWORK PROGRAMMABILITY AND AUTOMATION     |                  12 |           30 |
| AUTONOMOUS SYSTEMS                                       |                   3 |           30 |
| SMART CITY E TECNOLOGIE MOBILI                           |                  43 |           29 |
| OPERATIONAL ANALYTICS                                    |                   9 |           28 |
| MACHINE LEARNING                                         |                  70 |           28 |
| LINGUAGGI DI PROGRAMMAZIONE E MODELLI COMPUTAZIONALI     |                   1 |           20 |
| PROJECT MANAGEMENT                                       |                  65 |           29 |
| DATA MINING                                              |                  12 |           27 |
| LINGUAGGI, COMPILATORI E MODELLI COMPUTAZIONALI          |                  56 |           27 |
| ENTREPRENEURSHIP                                         |                   3 |           28 |
| ATTIVITA' PROPEDEUTICA ALLA PROVA FINALE                 |                   1 |           30 |
| PROGRAMMABLE NETWORKING                                  |                   1 |           30 |
| ORGANIZATION, TEAMS AND DIGITAL LEADERSHIP               |                   5 |           28 |
| APPLICAZIONI E SERVIZI WEB                               |                  54 |           28 |
| MARKETING, SALES AND PLATFORMS FOR THE DIGITAL AGE       |                   4 |           28 |
| BUSINESS MODELS                                          |                   3 |           23 |
| PERVASIVE COMPUTING                                      |                  21 |           29 |
| SMART VEHICULAR-SYSTEMS                                  |                   3 |           28 |
| BUSINESS INTELLIGENCE                                    |                  36 |           25 |
| SICUREZZA DELLE RETI                                     |                   1 |           21 |
| SISTEMI DI SUPPORTO ALLE DECISIONI                       |                   4 |           27 |
| INTELLIGENT ROBOTIC SYSTEMS                              |                  25 |           29 |
| DEEP LEARNING                                            |                  19 |           28 |
| VISIONE ARTIFICIALE E RICONOSCIMENTO                     |                  14 |           27 |

- Sosteniamo il diritto alla conoscenza