# Guidance

Guidance services and activities to help you choose a degree programme and at each stage of your studies.

## Guidance for those who want to enroll

To help you in your choice and support your preparation for entrance exams, you can turn to the tutoring service. You will receive information about educational objectives, academic activities, and career opportunities, and you will be able to clarify any doubts you may have.

Contact details:
-Elvis Perlika - Orientation Tutor: elvis.perlika2@unibo.it
-Luca Patrignani - Degree Programme Tutor: campuscesena.tutorlmisi@unibo.it

### Guidance activities

The Degree Programme participates in orientation events promoted by the University and organizes specific activities to present the study program's features and help enrolled students start their studies with all the necessary information.

- AlmaOrienta: held at BolognaFiere at the beginning of March.
- Meeting with first-year students: at the beginning of classes, meetings are held to talk about how the course units are organized and the related learning activities.
- Open Day: between January and May, the Degree Programme organizes a series of meetings to provide detailed information on admission procedures and academic activities. Students also have the opportunity to visit the program's research laboratories.

## Guidance for enrolled students

Alma Mater provides students with various tools to maximize their University experience and obtain information and guidance during their studies.

In addition to tutorial services, guidance, and internships, the University also organizes events and activities that will benefit your studies.

Further information

## Guidance for final-year students and graduates

The University of Bologna offers support to those who intend to continue their studies or enter into the world of work.

Each academic year, the faculty of the Degree Programme organizes a JOB DAY at the programme's campus, where companies introduce themselves to students and meet them in person, offering internship or job opportunities.

- Support the right to knowledge