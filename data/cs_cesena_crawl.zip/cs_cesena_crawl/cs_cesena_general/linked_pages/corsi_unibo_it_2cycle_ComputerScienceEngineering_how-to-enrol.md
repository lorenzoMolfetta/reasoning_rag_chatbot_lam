# Programme enrolment: requirements, deadlines and methods

## The main steps to follow

1. Requirements

See what the admission requirements are.
2. Selection

Apply to the Programme
3. Ranking

Check the results of the exam.
4. Matriculation

Complete your enrolment.

Below you will find some information on how to apply, detailed in the call for applications, which varies depending on your citizenship.

If you have any doubts, check the application process to follow.

## Admission requirements

- Qualification required Qualification obtained in Italy This Programme has two curricula: one in Italian called "Computer Science &amp; Engineering", the other in English called "Intelligent Embedded Systems". The English curriculum has 2 tracks: the local track, directly managed by Unibo, and the EIT track, managed by EIT Digital Master School. Access to the Master Degree programme is allowed to candidates having (whatever curriculum are they interested in) L-8 – Ingegneria dell'informazione (Computer Engineering)L-31 – Scienze e tecnologie informatiche (Computer Science Technologies) or I haven't graduated yet Application is possibile. However, if you are a winner but you do not graduate by 31 December 2025 , you will not be able to finalise your enrolment.

### Qualification required

#### Qualification obtained in Italy

This Programme has two curricula: one in Italian called "Computer Science &amp; Engineering", the other in English called "Intelligent Embedded Systems".

The English curriculum has 2 tracks: the local track, directly managed by Unibo, and the EIT track, managed by EIT Digital Master School.

Access to the Master Degree programme is allowed to candidates having  (whatever curriculum are they interested in)

- A First cycle degree programme in one of the following fields:

L-8 – Ingegneria dell'informazione (Computer Engineering)
L-31 – Scienze e tecnologie informatiche (Computer Science Technologies)

or

- A first cycle degree/Bachelor in a different field, including at least 42 ECTS in the following sectors (Settori scientifico-disciplinari SSD): INF/01, ING-INF/05, from MAT/01 to MAT/09, FIS/01, FIS/02 and FIS/03.
18 ECTS out of 42 must belong to the following sectors: INF/01 and ING-INF/05
- Furthermore, access to the Master Degree Programme is allowed exclusively to candidates who will demonstrate the required knowledge and skills. Assessing methods will be described in the call for application (which will be published as soon as possible)
- Foreign qualification: if deemed suitable, degrees obtained abroad will be accepted.

#### I haven't graduated yet

Application is possibile. However, if you are a winner but you do not graduate by 31 December 2025, you will not be able to finalise your enrolment.

Knowledge of the English language



For the English curriculum Intelligent Embedded Systems (English)
As for English language skills and proficiency, at least B2 level (CEFR) is required. In order to assess their level, candidates will be asked to upload a valid language certificate or to take a test (please check the Call for application).
For the Italian curriculum Ingegneria e Scienze informatiche (Italian)
No English entry level is needed. However, you will need to pass a B2 level exam during your career.

## How to start

- Scholarships, exemptions and incentives



You can count on financial support from the start of your studies. Depending on your financial circumstances, merit or specific requirements, you may be able to apply for a reduction or exemption of the enrolment fee.
Find out more about opportunities
- Fees and amounts



Tuition fees is calculated according to the 2025 ISEE certificate (Economic Situation Indicator) with special subsidies in relation to the right to higher education. Full exemption is granted to first-year students with a low ISEE.
The ISEE value must be submitted, even if you are not enrolled in the degree programme,  by October 30, 2025, at 6:00 PM (or by November 17, 2025, at 6:00 PM with a €100 late fee) by accessing ER-GO Online Services; otherwise, you will have to pay thefull amount.
If you cannot obtain an ISEE certification, check how the fees are calculated according to your country of origin and where your family has income and assets.
Read all information about tuition fees and exemptions.

Remember
Prepare documents and submit applications for scholarships and other funding opportunities. Depending on your financial status, you can obtain scholarships, student accommodation, full or partial exemption from fees and other funding opportunities. To apply, you will have to prepare documentation on your family's income and assets.
- Health coverage From your arrival in Italy and throughout your stay, you must have health coverage. You have several options: European Health Insurance Card (EHIC) card, private health insurance or registration with the Italian National Health Service (SSN). If you have an EHIC card If you have a valid European Health Insurance Card (EHIC) from your EU country of origin, you are entitled to all medically necessary treatment. You can obtain healthcare services directly from a public or contracted provider by presenting the EHIC. You will be provided the service free of charge, except for any co-payment (“ticket”) which is paid directly by patients and is not reimbursable. With the EHIC, you can go directly to a general practitioner (also known as a family doctor) by choosing from the list of affiliated general practitioners (MMG) available on the Salute Bologna website, if you study in Bologna, or the AUSL della Romagna website, if you are studying at other campuses. You cannot use the EHIC for 'planned treatment abroad', i.e. predictable treatment (e.g. non-urgent dental treatment, spa treatment, etc.). If you have a certificate of entitlement (e.g. E106, E109, etc.) If you are in possession of a certificate of entitlement other than the EHIC, as a general rule, in order to be entitled to healthcare, you must first present this certificate to one of the Local Health Authority Desks (CUP) , which will check whether you can register with the National Health Service (SSN), in which case you will be entitled to full healthcare under the same conditions as Italian citizens. Access to healthcare may vary depending on the certificate of entitlement you possess. Ask the Local Health Authority Desk (CUP) for more information when registering. See the list of Local Health Authority Desks (CUP) in Bologna and Romagna (provinces of Cesena, Forlì, Ravenna and Rimini). Other cases If you have neither an EHIC card nor a Certificate of Entitlement, you must take out private health insurance valid in Italy or register with the Italian National Health Service (SSN), where applicable. If you have private health insurance , you can go to any general practitioner. If you need to see a specialist, you can choose which doctor you to go directly, possibly with the advice of the general practitioner.Private health insurance policies: If your stay is for study purposes , check with one of Local Health Authority Desks (CUP) to see if you can register with the Italian National Health Service (SSN) . To register voluntarily with the National Health Service (SSN) as a student, you must be resident in Italy and pay an annual lump sum contribution of at least €700.Registration with the SSN is on a calendar year basis, from 1 January to 31 December. If you are employed or self-employed and pay taxes in Italy, you are entitled to free compulsory registration with the National Health Service (SSN) . Check at one of the Local Health Authority Desks (CUP) how to register with the SSN. If you have been living in Italy for at least five years , you can apply to the municipality where you live for an 'Attestato di Soggiorno Permanente' (Permanent Residence Certificate), which entitles you to registration with the National Health Service and a choice of general practitioner. Check at one of the Local Health Authority Desks (CUP) how to register with the SSN. How to register voluntarily for the National Health Service as a student If you apply for or have a residence permit for study purposes, the minimum cost will be €700 per year from 2024. Registration is per calendar year only (e.g. from 1 January 2024 to 31 December 2024) and it is not possible to pay reduced fees for shorter periods. It is possible to pay to register for the current year and also for the entire following calendar year (e.g. 2024 and 2025). This possibility grants health coverage for one academic year and is useful for students who arrive, for example, in September and intend to apply for a 1-year residence permit for study purposes. The minimum contribution is €2,000 to cover dependant family members per year. To register: Go to a Local Health Authority Desk (CUP). See the list of Local Health Authority Desks (CUP) in Bologna and Romagna (provinces of Cesena, Forlì, Ravenna and Rimini). Take with you: Ask for information on how to pay the voluntary student registration fee; remember that the payment must be made using the ordinary F24 form .You have to complete the sections: Pay the annual lump sum using form F24 for each year of registration with the SSN at post offices, banks, online via your bank account or with Pagobancomat, Postepay or Postamat cards and keep the receipts. Make a copy of the receipts and attach them to your application for the first issue or renewal of your residence permit. After submitting your application for a residence permit, return to the Local Health Authority Desk (CUP) as soon as possible to activate your health coverage and choose a general practitioner.Take with you: Payment alone does not imply coverage. You have to complete registration at the offices of a Local Health Authority and choose a general practitioner. If you are paying for two consecutive years, remember that at the end of the current year you must return to the CUP with the payment receipt for the following year, and ask for the service to be activated. Always check the coverage end date. Those registered with the Italian National Health Service will receive a Health Card by post. The card is sent to the address provided to the Italian Revenue Agency; you can contact the Italian Revenue Agency to update your address and to have the card reprinted .

### Health coverage

From your arrival in Italy and throughout your stay, you must have health coverage. You have several options: European Health Insurance Card (EHIC) card, private health insurance or registration with the Italian National Health Service (SSN).

### If you have an EHIC card

If you have a valid European Health Insurance Card (EHIC) from your EU country of origin, you are entitled to all medically necessary treatment.

You can obtain healthcare services directly from a public or contracted provider by presenting the EHIC. You will be provided the service free of charge, except for any co-payment (“ticket”) which is paid directly by patients and is not reimbursable.

With the EHIC, you can go directly to a general practitioner (also known as a family doctor) by choosing from the list of affiliated general practitioners (MMG) available on the Salute Bologna website, if you study in Bologna, or the AUSL della Romagna website, if you are studying at other campuses.

You cannot use the EHIC for 'planned treatment abroad', i.e. predictable treatment (e.g. non-urgent dental treatment, spa treatment, etc.).

### If you have a certificate of entitlement (e.g. E106, E109, etc.)

If you are in possession of a certificate of entitlement other than the EHIC, as a general rule, in order to be entitled to healthcare, you must first present this certificate to one of the Local Health Authority Desks (CUP), which will check whether you can register with the National Health Service (SSN), in which case you will be entitled to full healthcare under the same conditions as Italian citizens.

Access to healthcare may vary depending on the certificate of entitlement you possess. Ask the Local Health Authority Desk (CUP) for more information when registering.

See the list of Local Health Authority Desks (CUP) in Bologna and  Romagna (provinces of Cesena, Forlì, Ravenna and Rimini).

### Other cases

If you have neither an EHIC card nor a Certificate of Entitlement, you must take out private health insurance valid in Italy or register with the Italian National Health Service (SSN), where applicable.

If you have private health insurance, you can go to any general practitioner. If you need to see a specialist, you can choose which doctor you to go directly, possibly with the advice of the general practitioner.
Private health insurance policies:

    - do not allow registration with the Italian National Health Service (SSN) or the choice of a general practitioner;
    - usually require the policyholder to pay the cost and then claim reimbursement from the insurance company.
When purchasing the policy, carefully check the conditions and limits of reimbursement. Keep in mind that the medical expenses to be paid in advance can be very high, for example in the case of hospitalisation. It is advisable to heck in advance, by contacting your insurance company, whether the type of medical service you require is covered.

If your stay is for study purposes, check with one of Local Health Authority Desks (CUP) to see if you can register with the Italian National Health Service (SSN). To register voluntarily with the National Health Service (SSN) as a student, you must be resident in Italy and pay an annual lump sum contribution of at least €700.
Registration with the SSN is on a calendar year basis, from 1 January to 31 December.

If you are employed or self-employed and pay taxes in Italy, you are entitled to free compulsory registration with the National Health Service (SSN). Check at one of the Local Health Authority Desks (CUP) how to register with the SSN.

If you have been living in Italy for at least five years, you can apply to the municipality where you live for an 'Attestato di Soggiorno Permanente' (Permanent Residence Certificate), which entitles you to registration with the National Health Service and a choice of general practitioner. Check at one of the Local Health Authority Desks (CUP) how to register with the SSN.

### How to register voluntarily for the National Health Service as a student

If you apply for or have a residence permit for study purposes, the minimum cost will be €700 per year from 2024. Registration is per calendar year only (e.g. from 1 January 2024 to 31 December 2024) and it is not possible to pay reduced fees for shorter periods.

It is possible to pay to register for the current year and also for the entire following calendar year (e.g. 2024 and 2025). This possibility grants health coverage for one academic year and is useful for students who arrive, for example, in September and intend to apply for a 1-year residence permit for study purposes.

The minimum contribution is €2,000 to cover dependant family members per year.

To register:

Go to a Local Health Authority Desk (CUP). See the list of Local Health Authority Desks (CUP) in Bologna and Romagna (provinces of Cesena, Forlì, Ravenna and Rimini).  
Take with you:

    - your passport;
    - your official Italian tax code;
    - certificate of enrolment at the University of Bologna or, for exchange students, the Declaration of Arrival;
    - for the Local Health Authority Desks (CUP) of Bologna, the voluntary registration form [.pdf 967 KB] for non-EU citizens; here you will find an example with instructions on how to fill in the form [.pdf 371 KB].

Ask for information on how to pay the voluntary student registration fee; remember that the payment must be made using the ordinary F24 form.
You have to complete the sections:

    - "taxpayer', entering your personal data;
    - “region section”, entering the region code 06 (Emilia-Romagna) and tax code 8846;
    - reference year: the calendar year in which you want to enrol in the SSN, e.g. 2024;
    - debit amounts paid: €700, if you have no other income apart from your scholarship and do not wish to cover your family members. If you want to register for two consecutive years (e.g. 2024 and 2025), you have to make two payments.

Pay the annual lump sum using form F24 for each year of registration with the SSN at post offices, banks, online via your bank account or with Pagobancomat, Postepay or Postamat cards and keep the receipts.

Make a copy of the receipts and attach them to your application for the first issue or renewal of your residence permit.

After submitting your application for a residence permit, return to the Local Health Authority Desk (CUP) as soon as possible to activate your health coverage and choose a general practitioner.
Take with you:

    - receipts of payment of the annual contribution;
    - the postal receipt of the residence permit application (or the residence permit if already obtained);
    - certificate of enrolment at the University of Bologna or, for exchange students, the Declaration of Arrival.

Payment alone does not imply coverage. You have to complete registration at the offices of a Local Health Authority and choose a general practitioner.

If you are paying for two consecutive years, remember that at the end of the current year you must return to the CUP with the payment receipt for the following year, and ask for the service to be activated.

Always check the coverage end date.

Those registered with the Italian National Health Service will receive a Health Card by post. The card is sent to the address provided to the Italian Revenue Agency; you can contact the Italian Revenue Agency to update your address and to have the card reprinted.

Italian tax code



To study in Italy, you will need to apply for an Italian tax code. Contact the Italian Revenue Agency or contact us for assistance in obtaining one. The code will be necessary also to register with the Italian National Health Service (SSN).

Submitting your foreign qualifications



The qualification you declare you possess at the admission stage will be checked by the International Student Administration Office of the relevant campus after you have applied for enrolment and submitted originals of all the necessary documents.  
We recommend you submit them to the International Student Administration Office as soon as possible for a preliminary check and, if necessary, to obtain unreserved validation of your pre-enrolment.

Italian tax code



To study in Italy, you will need to apply for an Italian tax code. Contact the Italian Revenue Agency or contact us for assistance in obtaining one. The code will be necessary also to register with the Italian National Health Service (SSN).

Submitting your foreign qualifications



The qualification you declare you possess at the admission stage will be checked by the International Student Administration Office of the relevant campus after you have applied for enrolment and submitted originals of all the necessary documents.  
We recommend you submit them to the International Student Administration Office as soon as possible for a preliminary check and, if necessary, to obtain unreserved validation of your pre-enrolment.

## Selection

- Available places




For the Italian Curriculum "Ingegneria e Scienze Informatiche"
There is no limited number of places, because it's not a restricted access curriculum.

For the English curriculum "Intelligent Embedded Systems"

For the IES, local track, admission to the degree programme is limited to 15 places.
For the EIT track, admission is limited to 10 places.
- What this consists of



For the Italian Curriculum "Ingegneria e Scienze Informatiche"
There is no admission or entry exam. You will need to pass an interview only if the Commission evaluates your study title as not suitable to be admitted directly.
For the English Curriculum "Intelligent embedded systems"
For the IES local track, please refer to the call for application (downloadable down here). Evaluation is divided into two phases: Phase I is evaluation of your study titles, phase II is about curriculum and and interview to be taken if phase I is successful.
For the EIT track, please refer to EIT admission page.
In order to briefly sum up here, EIT admission does not consist in an entrance exam, but rather in analysing your career, your curriculum and your motivation through a motivation letter. Anyway, please refer to the page above in order to have more specific and official pieces of information.
- When and where to take the exam



For the Italian Curriculum  "Ingegneria e Scienze informatiche"
If the Examination Board asks you to take an interview, this will be online.
For the English Curriculum "Intelligent Embedded systems"
As for the IES local track, interviews will be taken online. Interview calendar will be published after phase II in the Studenti Online private profile of each candidate, within the date published in the call for application.

As for the EIT track, please refer to the portal, but selection does not include any exams.
- How to register For the Italian curriculum "Ingegneria e scienze informatiche" Please refer to the call which will be published within June 2025. You will need to connect to Studenti Online. For the English curriculum "Intelligent embedded systems" As for the IES local track , please connect to Studenti Online with your SPID or CIE credentials or with your institutional credentials "@studio.unibo.it".Follow the steps to 'Apply for the Selection', as indicated in the call. The registration process for the exam will not be complete until you have paid the €50 fee. This fee will not be refunded under any circumstances. As for the EIT local track , please register through this link: Admission page and follow all the instructions and deadlines. DEADLINES FOR EIT TRACK Application: For 2025/26 there are three intakes available: Depending on your citizenship, you might need more time to complete all formalities in order to relocate. Therefore, EIT highly encourages students to apply before February 2025. The enrollment process is managed by EIT Digital Master School. Please refer to the EIT admission page for the updated requirements and all the details.

### How to register

For the Italian curriculum "Ingegneria e scienze informatiche"

Please refer to the call which will be published within June 2025. You will need to connect to  Studenti Online.

For the English curriculum "Intelligent embedded systems"

As for the IES local track, please connect to Studenti Online with your SPID or CIE credentials or with your institutional credentials "@studio.unibo.it".
Follow the steps to 'Apply for the Selection', as indicated in the call.

The registration process for the exam will not be complete until you have paid the €50 fee. This fee will not be refunded under any circumstances.

As for the EIT local track,  please register through this link: Admission page and follow all the instructions and deadlines.

DEADLINES FOR EIT TRACK Application:

For 2025/26 there are three intakes available:

- 1st intake: 1 November 2024 9.00 CET  - 10 February 2025 h.18.00 CET - Open to EU/EEA/CH/Non-EU citizens

- 2nd intake: 11 February 2025 9.00 CET- 14 April 2025 18.00 CEST - Open to EU/EEA/CH/Non-EU citizens
- 3rd intake: 15 April 2025  9.00 CEST- 22 May 2025 18.00 CEST - Open to EU/EEA/CH/Non-EU citizens.
Due to time constraints, application period three is only open for applicants who do not require an EU study visa. Non-EU students can apply only if a study visa is not required for them.

Depending on your citizenship, you might need more time to complete all formalities in order to relocate. Therefore, EIT highly encourages students to apply before February 2025.

The enrollment process is managed by EIT Digital Master School.
Please refer to the EIT admission page for the updated requirements and all the details.

Adaptations for people with disabilities or SLD



If you wish to request adaptations for the entrance exam, you must do so when you register on Studenti Online. You will need to download the form you will find on Studenti Online and attach the relevant medical documentation certifying the disability or SLD.
See the service website for further information

How the exam is evaluated For the Italian curriculum "Ingegneria e Scienze Informatiche" There is no entry exam. Possible interviews aim at evaluating your preparation in terms of knowledge of the main topics this Programme is about. Please refer to the call which will be published within June 2025. For the English curriculum "Intelligent embedded systems" As for the IES local track, please refer to the call for application (downloadable here under) As for the EIT track , the ranking is based on a total evaluation of the following criteria: Source: FAQ Please refer to this page, as it's the official and primary source for the EIT track.

### How the exam is evaluated

For the Italian curriculum "Ingegneria e Scienze Informatiche"

There is no entry exam. Possible interviews aim at evaluating your preparation in terms of knowledge of the main topics this Programme is about. Please refer to the call which will be published within June 2025.

For the English curriculum "Intelligent embedded systems"

As for the IES local track, please refer to the call for application (downloadable here under)

As for the EIT track, the ranking is based on a total evaluation of the following criteria:

- suitability of acquired bachelor degree for intended study program;
- academic excellence (quality and recognition of home university, study success)
- entrepreneurial excellence
- innovative potential

Source: FAQ

Please refer to this page, as it's the official and primary source for the EIT track.

## Ranking list

- What this consists of



Just for the English curriculum , local track (there is no ranking list for the Italian curriculum. For the EIT track, please refer to the EIT website )
 
Ranking is in descending order, based solely on the score obtained in the entrance exam. It will be published on Students Online, on the main page, under the 'Current Requests' detail section.
In the event of a tie, priority is given to the youngest candidate.

Publication of results will take place within the dates published in the call for application (Calendar section).
- Winner



If you are on the ranking list, you can enrol.
- Eligible



If you are not on the ranking list, you can state your interest in participating in the ‘Unallocated Places’ procedure.
- Unallocated places



For each selection, any remaining places are made available again to those who state their interest in the ‘Unallocated Places’ procedure. 
Taking part in this procedure is not automatic: you have to state your interest at every selection via Studenti Online .
Once stated, your interest is irrevocable and cannot be modified.  
In the call you will find information on the requirements, procedures and deadlines for stating your interest in the ‘Unallocated Places’ procedure.

## Matriculation

- Application for enrolment



If you are high up in the ranking list, go to Studenti Online, fill in the application form and pay the first tuition fee instalment or the one-off fee in accordance with the procedures given and by the deadlines indicated in the call. If you do not pay the fees as specified, you will be excluded from the process. Payment in arrears is also not permitted.
- Pre-enrolment on Universitaly



After you have passed the entrance exam, if you have not already done so, submit the pre-enrolment application online on Universitaly . You will need this to apply for an entry visa.
Please indicate this degree programme on your application. Read the Guide and FAQs [.pdf 730 KB] to understand how to fill in the application. 
If you have passed the entry exam and paid the first instalment by the mandatory deadline set by the call, the offices will validate your pre-enrolment.
Download the application summary and submit it to the Embassy or Consulate to apply for a visa.
If you need to change the degree programme or the university you entered on your pre-enrolment application, please read the information on making changes to your pre-enrolment and reallocation.
The University of Bologna's offices could be closed for several days in August, during which pre-enrolments are not validated, so pre-enrolment validation times could be longer in August.
If your embassy or consulate requires your pre-enrolment to be validated without reservation, go to the 'Career activation and badge' section of this page to find out how to do this.
Remember that pre-enrolment does guarantee admission to degree programmes. To enrol, you must also meet the admission requirements and pass the entrance exams required by the degree programme.
The University of Bologna does not issue letters of academic eligibility for the purpose of obtaining a visa.
An entry visa for tourism cannot be used for university enrolment or to obtain a residence permit for study purposes.
- Visa application and health coverage To apply for a visa, you must have health insurance . From the moment you arrive in Italy and throughout your stay, you must be covered by private health insurance or by the Italian National Health Service. You can only register with the Italian National Health Service after your arrival in Italy. If you intend to do so, you may consider purchasing short-term private insurance to cover the trip and the first period in Italy (unless otherwise specified by the Embassy for the purposes of obtaining your visa). If you do not intend to do so, you may consider buying a longer private insurance policy (at least 1 year). Entry visa for 'study/university enrolment’ purposes If you do not yet have a long-term visa, make an appointment at the Embassy or Consulate and bring with you: You will need to obtain a “Study - University Enrolment” visa, the required documents and possibly an Italian tax code from the Embassy or Consulate.

### Visa application and health coverage

To apply for a visa, you must have health insurance.

From the moment you arrive in Italy and throughout your stay, you must be covered by private health insurance or by the Italian National Health Service. You can only register with the Italian National Health Service after your arrival in Italy. If you intend to do so, you may consider purchasing short-term private insurance to cover the trip and the first period in Italy (unless otherwise specified by the Embassy for the purposes of obtaining your visa). If you do not intend to do so, you may consider buying a longer private insurance policy (at least 1 year).

Entry visa for 'study/university enrolment’ purposes

If you do not yet have a long-term visa, make an appointment at the Embassy or Consulate and bring with you:

    - the summary of the pre-enrolment application on Universitaly validated by the University of Bologna
    - the document certifying the economic resources needed to stay in Italy (minimum required for 2024: € 6,947.33). For example, you can submit your bank or post office account statement
    - any certificates relating to the degree programme’s language requirement
    - any health insurance
    - Italian Revenue Agency forms to apply for the Italian tax code. The forms can be found on the website of the Embassy or Consulate if they offer this service
    - your qualification documents in order to translate, legalise and authenticate it, if required and when the service is provided
    - any documentation to obtain financial benefits

You will need to obtain a “Study - University Enrolment” visa, the required documents and possibly an Italian tax code from the Embassy or Consulate.

Identity validation Validating your identity means associating your account name.surname@studio.unibo.it with your identity. What you need to do Your identity will be validated automatically , without you having to do anything, if one of the following applies: If any of the above conditions do not apply, and you are unable to obtain SPID credentials because you are a minor or you are a resident abroad, contact the Student Administration Office or, if you are resident abroad and have a qualification obtained abroad, contact the International Student Administration Office.

### Identity validation

Validating your identity means associating your account name.surname@studio.unibo.it with your identity.

### What you need to do

Your identity will be validated automatically, without you having to do anything, if one of the following applies:

    - you have SPID credentials and have used them at least once to access Studenti Online;
    - you have an electronic identity card and access Studenti Online via the pathway Log in with CIE;
    - you have been part of the student community at the University of Bologna since 2004;
    - you have taken a written or oral exam, also remotely, at the University of Bologna (not including TOLC tests and national competitive exams).

If any of the above conditions do not apply, and you are unable to obtain SPID credentials because you are a minor or you are a resident abroad, contact the Student Administration Office or, if you are resident abroad and have a qualification obtained abroad, contact the International Student Administration Office.

Career activation and badge Career activation is required to create a study plan, book and take exams, change degree programme, transfer to another university, withdraw from or suspend studies, graduate, and print certificates. It is also required to use certain services, such as access to online library resources and the Wi-Fi network. Your career will be automatically activated after identification. It is not automatically activated if: The career must be activated by 26 February 2026. Once the career is activated, you will receive an e-mail with instructions on how to obtain your badge.

### Career activation and badge

Career activation is required to create a study plan, book and take exams, change degree programme, transfer to another university, withdraw from or suspend studies, graduate, and print certificates. It is also required to use certain services, such as access to online library resources and the Wi-Fi network.

Your career will be automatically activated after identification.

It is not automatically activated if:

- you obtained your qualification abroad:  you must submit your qualification to the International Student Administration Office of the campus where you will be studying. Gather all the necessary documentation on your qualification; go to Studenti Online under 'Calls', select 'Matriculation a.y. 25\_26 academic year - document upload for international students with foreign qualifications' and upload the study documents. Make an appointment with the International Student Administration Office to present the original documents
- you have not yet received your qualification: as soon as you receive it, log into Studenti Online and enter your grade details. Remember that the qualification must be obtained by 31 December 2025; otherwise, your enrolment will be cancelled.
- you are still a minor at the time of matriculation, fill in the attached form of parental responsibility and send it, duly completed and signed by your parents, to the email address of the Student Administration Office of your chosen degree programme.

The career must be activated by 26 February 2026.

Once the career is activated, you will receive an e-mail with instructions on how to obtain your badge.

Career activation and badge Career activation is required to create a study plan, book and take exams, change degree programme, transfer to another university, withdraw from or suspend studies, graduate, and print certificates. It is also required to use certain services, such as access to online library resources and the Wi-Fi network. Your career will be automatically activated after your identity has been validated. It is not automatically activated if: The career must be activated by 26 February 2026 . Once the career is activated, you will receive an e-mail with instructions on how to obtain your badge.

### Career activation and badge

Career activation is required to create a study plan, book and take exams, change degree programme, transfer to another university, withdraw from or suspend studies, graduate, and print certificates. It is also required to use certain services, such as access to online library resources and the Wi-Fi network.

Your career will be automatically activated after your identity has been validated.

It is not automatically activated if:

- you are a non-EU citizen, but hold an equivalent qualification and have obtained your qualification in Italy: email a copy of your residence permit allowing equivalence to the Student Administration Office of your degree programme;
- you are a non-EU citizen, but hold an equivalent qualification and have obtained your qualification abroad: submit your qualification to the International Student Administration Office of the campus where you will be studying:
    - gather all the necessary documents relating to your qualification;
    - log on to Studenti Online;
    - if you haven’t already done so, and you are still within the deadline, pay the first instalment of the tuition fees;
    - go to the 'Calls' section, search for the call 'Matriculation for the 25\_26 - document upload for international students with foreign qualifications";
    - upload the required documents and the residence permit allowing equivalence.
The International Student Administration Office will check the documents. 
Make an appointment with the International Student Administration Office to present the original documents. 
When you arrive in Italy, go to the appointment and bring your qualification documents and passport with you.
- you are an EU citizen and have obtained your qualification abroad: submit your qualification to the International Student Administration Office of the campus where you will be studying:
    - gather all the necessary documents relating to your qualification;
    - log on to Studenti Online;
    - if you haven’t already done so, and you are still within the deadline, pay the first instalment of the tuition fees;
    - go to the 'Calls' section, search for the call 'Matriculation for the 25\_26 - document upload for international students with foreign qualifications";
    - upload the required documents.
The International Student Administration Office will check the documents. 
Make an appointment with the International Student Administration Office to present the original documents. At the appointment, bring your qualification documents and ID document with you.
- you have not yet received your qualification: as soon as you receive it, log into Studenti Online and enter your grade details. Remember that the qualification must be obtained by 31 December 2025; otherwise, your enrolment will be cancelled.
- you are still a minor at the time of matriculation, fill in the attached form of parental responsibility and send it, duly completed and signed by your parents, to the email address of the Student Administration Office of your chosen degree programme.

The career must be activated by 26 February 2026.

Once the career is activated, you will receive an e-mail with instructions on how to obtain your badge.

Career activation and badge Career activation is required to create a study plan, book and take exams, change degree programme, transfer to another university, withdraw from or suspend studies, graduate, and print certificates. It is also required to use certain services, such as access to online library resources and the Wi-Fi network. If you obtained your qualification abroad , you must submit your qualification to the International Student Administration Office of the campus where you will be studying: If you need unreserved validation on Universitaly, please notify the International Student Administration Office by e-mail. The International Student Administration Office will check the documents. If they are complete and their authenticity and value can be verified, your pre-enrolment on Universitaly will be unconditionally validated. Make an appointment with the International Student Administration Office to present the original documents.When you arrive in Italy, go to the appointment and bring your qualification documents and passport with you. If the documents are complete, the student administration office will give you a certificate of registration. You will then need to email the receipt of your residence permit application to the International Student Administration Office to activate your career. Your enrolment will be considered conditional until you have received your residence permit and sent a copy to the Student Administration Office. If you are a non-EU citizen, reside abroad, but have an Italian degree obtained in Italy, contact the International Student Administration Office on your campus to find out how to proceed. If you are still a minor at the time of matriculation, fill in the attached form of parental responsibility and send it, duly completed and signed by your parents, to the email address of the Student Administration Office of your chosen degree programme. The career must be activated by 26 February 2026 .Once the career is activated, you will receive an e-mail with instructions on how to obtain your badge.

### Career activation and badge

Career activation is required to create a study plan, book and take exams, change degree programme, transfer to another university, withdraw from or suspend studies, graduate, and print certificates. It is also required to use certain services, such as access to online library resources and the Wi-Fi network.

If you obtained your qualification abroad, you must submit your qualification to the International Student Administration Office of the campus where you will be studying:

    - gather all the necessary documents relating to your qualification;
    - log on to Studenti Online
    - if you haven’t already done so, and you are still within the deadline, pay the first instalment of the tuition fees;
    - go to the 'Calls' section, search for the call 'Matriculation for the 25\_26 - document upload for international students with foreign qualifications";
    - upload the required documents and, if you already have one, your student visa.

If you need unreserved validation on Universitaly, please notify the International Student Administration Office by e-mail. The International Student Administration Office will check the documents. If they are complete and their authenticity and value can be verified, your pre-enrolment on Universitaly will be unconditionally validated.

Make an appointment with the International Student Administration Office to present the original documents.
When you arrive in Italy, go to the appointment and bring your qualification documents and passport with you. If the documents are complete, the student administration office will give you a certificate of registration.

You will then need to email the receipt of your residence permit application to the International Student Administration Office to activate your career. Your enrolment will be considered conditional until you have received your residence permit and sent a copy to the Student Administration Office.

If you are a non-EU citizen, reside abroad, but have an Italian degree obtained in Italy, contact the International Student Administration Office on your campus to find out how to proceed.

If you are still a minor at the time of matriculation, fill in the attached form of parental responsibility and send it, duly completed and signed by your parents, to the email address of the Student Administration Office of your chosen degree programme.

The career must be activated by 26 February 2026.
Once the career is activated, you will receive an e-mail with instructions on how to obtain your badge.

Residence permit and health coverage Registering with the Italian National Health Service (SSN) If you want to register with the Italian National Health Service (SSN), you have to pay an annual fee. If you apply for or have a residence permit for study purposes, the minimum cost will be €700 per year from 2024. Registration is on a calendar year basis only (e.g. from 1 January 2024 to 31 December 2024) and it is not possible to pay reduced fees for shorter periods. It is possible to pay the registration fee for the current year and for the whole of the following calendar year (e.g. 2024 and 2025). This option provides health cover for an academic year and is useful, for example, if you arrive in September and intend to apply for a one-year residence permit for study purposes. The minimum contribution is €2,000 to cover dependant family members per year. To register at a Local Health Authority Desk (CUP), take with you: Ask for information on how to make the payment for the "voluntary student registration” fee. Payment must be made using the ordinary F24 form . The following sections must be completed: Pay the annual lump sum using form F24 for each year of registration with the SSN at post offices, banks, online via your bank account or with Pagobancomat, Postepay or Postamat cards and keep the receipts. Make a copy of the receipts and attach them to your application for the first issue or renewal of your residence permit. Payment alone does not imply coverage. You have to complete registration at the offices of a Local Health Authority and choose a general practitioner. Applying for a residence permit Within eight days of arrival in Italy, apply for a permit . You can do this on your own or with our support.Email the receipt of the residence permit application to your International Student Administration Office. Remember that your residence permit has to be renewed every year . Activating health coverage and choosing a general practitioner After submitting your application for a residence permit, return to the Local Health Authority Desk (CUP) as soon as possible to activate your health coverage and choose a general practitioner. Take with you: If you are paying for two consecutive years, remember that at the end of the current year you must return to the CUP with the payment receipt for the following year, and ask for the service to be activated. Always check the coverage end date.You will receive a Health Insurance Card by post. It will be sent to the address you gave to the Revenue Agency. You can contact the Internal Revenue Agency to update your address and, if necessary, to request a replacement card.

### Residence permit and health coverage

#### Registering with the Italian National Health Service (SSN)

If you want to register with the Italian National Health Service (SSN), you have to pay an annual fee. If you apply for or have a residence permit for study purposes, the minimum cost will be €700 per year from 2024. Registration is on a calendar year basis only (e.g. from 1 January 2024 to 31 December 2024) and it is not possible to pay reduced fees for shorter periods.

It is possible to pay the registration fee for the current year and for the whole of the following calendar year (e.g. 2024 and 2025). This option provides health cover for an academic year and is useful, for example, if you arrive in September and intend to apply for a one-year residence permit for study purposes. The minimum contribution is €2,000 to cover dependant family members per year.

To register at a Local Health Authority Desk (CUP), take with you:

    - your passport;
    - your official Italian tax code;
    - the certificate of enrolment in the University of Bologna;
    - for the Local Health Authority Desks (CUP) in Bologna, the voluntary registration form [.pdf 967 KB].  Here you will find an example with instructions on how to fill in the form [.pdf 371 KB].

Ask for information on how to make the payment for the "voluntary student registration” fee. Payment must be made using the ordinary F24 form. The following sections must be completed:

    - "taxpayer', entering your personal data;
    - “region section”, entering the region code 06 (Emilia-Romagna) and tax code 8846;
    - reference year: the calendar year in which you want to enrol in the SSN (e.g. 2024);
    - debit amounts paid: €700, if you have no other income apart from your scholarship and do not wish to cover your family members. If you want to register for two consecutive years (e.g. 2024 and 2025), you have to make two payments.

Pay the annual lump sum using form F24 for each year of registration with the SSN at post offices, banks, online via your bank account or with Pagobancomat, Postepay or Postamat cards and keep the receipts.

Make a copy of the receipts and attach them to your application for the first issue or renewal of your residence permit.

#### Applying for a residence permit

Within eight days of arrival in Italy, apply for a permit. You can do this on your own or with our support.
Email the receipt of the residence permit application to your International Student Administration Office. Remember that your residence permit has to be renewed every year.

#### Activating health coverage and choosing a general practitioner

After submitting your application for a residence permit, return to the Local Health Authority Desk (CUP) as soon as possible to activate your health coverage and choose a general practitioner. Take with you:

    - receipts of payment of the annual contribution;
    - the postal receipt of the residence permit application (or the residence permit if already obtained);
    - your certificate of enrolment at the University of Bologna or, if you are an exchange student, your Declaration of Arrival.

If you are paying for two consecutive years, remember that at the end of the current year you must return to the CUP with the payment receipt for the following year, and ask for the service to be activated. Always check the coverage end date.
You will receive a Health Insurance Card by post. It will be sent to the address you gave to the Revenue Agency.

You can contact the Internal Revenue Agency to update your address and, if necessary, to request a replacement card.

## Call for application

- Call for application 25/26 - Intelligent embedded systems local track
        
          [.pdf
          2656Kb]
          
        
(Deadline: 22/04/25 1.00 p.m. Italian local time) - Please be aware this English version has been created for information purposes only. In the event of claims and legal disputes, the Italian version shall prevail
- Call for application Intelligent Embedded Systems 25/26 local track : ITALIAN VERSION
        
          [.pdf
          602Kb]
          
        
Please be aware this English version has been created for information purposes only. In the event of claims and legal disputes, the Italian version shall prevail.

<!-- image -->

Do you want to transfer?

Are you from another university and want to transfer to Unibo?

<!-- image -->

Do you want to change your Degree programne?

Follow your passions and discover how you can make a change.

- Support the right to knowledge