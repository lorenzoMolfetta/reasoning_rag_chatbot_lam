# Cosa si studia?

L'offerta didattica del corso di studio.

Il corso di studio in Ingegneria e Scienze Informatiche è uno dei primi corsi di studio in Italia che offre agli studenti la possibilità di studiare l'informatica in modo più completo, approfondendone sia gli aspetti di tipo progettuale/ingegneristico, sia quelli di tipo matematico/scientifico.

Il corso di Laurea Magistrale in Ingegneria e Scienze Informatiche costituisce il naturale proseguimento del corso triennale e consente di approfondire ulteriormente la preparazione teorica, metodologica e tecnologica in ambito informatico, sia di acquisire specifiche competenze operative in settori di riferimento per il mondo del lavoro.

Il corso offre due indirizzi (curriculum) alternativi: "Ingegneria e Scienze Informatiche" e "Intelligent Embedded Systems".

## Curriculum "Ingegneria e Scienze Informatiche"

Il curriculum Ingegneria e Scienze Informatiche, erogato in italiano, prevede anzitutto il consolidamento e approfondimento di competenze specialistiche nei settori dei linguaggi di programmazione e paradigmi computazionali, della progettazione e sviluppo del software, dei sistemi operativi e di programmazione concorrente/multi-core, dei sistemi informativi e delle tecnologie web, dei sistemi distribuiti e delle reti di calcolatori, della sicurezza delle reti e dei sistemi informatici, e del machine learning.

Il corso prevede poi la possibilità per lo studente di scegliere un certo insieme di insegnamenti per approfondire specifiche tematiche. In particolare, tutti gli insegnamenti del II anno sono a scelta, e sono organizzati sulla base di due profili formativi.

### Profilo Data Knowledge Engineering

Il profilo studia la modellazione e gli algoritmi necessari alla costruzione e allo sfruttamento della conoscenza al servizio di applicazioni aziendali e scientifiche avanzate. Gli ambiti applicativi di riferimento sono quelli della Business Intelligence, del Semantic Web e dell'Internet-of-Things.

Gli insegnamenti di questo profilo includono: Big Data, Business Intelligence, Data Mining, Project Management, Operational Analytics, Web Semantico.

### Profilo Software Systems Engineering

Il profilo affronta le tematiche di costruzione del software in sistemi informatici moderni, distribuiti e autonomi, con particolare riferimento a contesti di Information e Communication Technology (ICT), quali Internet-of-Things, Pervasive Computing, Smart City, visione artificiale e robotica.

Gli insegnamenti di questo profilo includono:

- Area "Software Architect": Advanced Software Modelling and Design, Software Architecture and Platforms, Software Process Engineering

- Area "Sistemi Intelligenti": Intelligent Systems Engineering, Intelligent Robotic Systems, Visione Artificiale e Riconoscimento

### Altri insegnamenti a scelta del II anno

Instradamento e Trasporto in Internet, Smart Vehicular Systems, Laboratory of Network Programmability and Automation, Deep Learning, Analisi di Immagini 3D e Sistemi di Computer Vision

Per saperne di più: Piano didattico

## Curriculum "Intelligent Embedded Systems"

Il curriculum Intelligent Embedded Systems è erogato interamente in inglese e offre due percorsi differenti, ognuno con un proprio processo di ammissione e scadenze diverse.

Nel percorso locale, gli studenti frequentano entrambi gli anni presso l'Università di Bologna.

Nel percorso in collaborazione con EIT Digital Master School, dopo il primo anno all'Università di Bologna, gli studenti frequentano il secondo anno in una delle università partner in un altro paese europeo, da decidere al momento dell'ammissione.

Maggiori informazioni sul curriculum Intelligent Embedded Systems sono reperibili a questo indirizzo.

### In evidenza

- Presentazione del corso

[
          .pdf
          104Kb
          ]

- Sosteniamo il diritto alla conoscenza