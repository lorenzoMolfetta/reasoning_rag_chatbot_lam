# Diventare Tutor

Il tutor costituisce un utile punto di riferimento per gli studenti durante il percorso universitario.

## I tutor dei Corsi di Studio

I tutor dei Corsi di Studio sono un utile punto di riferimento per gli studenti anche nei rapporti con i docenti ed in generale nell’organizzazione delle proprie attività di studio. Gli studenti dell’Università di Bologna possono rivolgersi ai tutor dei Corsi di Studio per ricevere supporto relativamente alle attività didattiche e integrative e per avere informazioni  sui corsi.

Consulta i bandi per ottenere gli assegni di tutorato.

## I tutor a supporto della didattica

I tutor didattici garantiscono lo svolgimento delle attività di supporto e assistenza alla didattica (attività di esercitazione, di laboratorio, pratiche, propedeutiche all'attribuzione dei crediti formativi).

Consulta i bandi per l’assistenza alla didattica.

- Sosteniamo il diritto alla conoscenza