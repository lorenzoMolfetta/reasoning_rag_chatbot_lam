# Degree Programme Tutor

The Degree Programme Tutor is a useful reference point to help students in their relations with lecturers and, more in general, in the organisation of their study activities.

## Degree Programme Tutor's role

The tutor's role aims at fostering communication between students and professors or administrative staff.

For example, s/he can offer a valuable help in providing information about admission or classes, or events related to the programme, or information about the Campus and its classrooms.

Additionally, the tutor offers personalised support to students who struggle, whether for work or other personal reasons, to keep up with the programme and exam schedules.

## Internationalisation Tutor's role

Her/his role aims at providing information and help to both outcoming and incoming students during their international exchange (Erasmus +, Overseas etc).

### Contacts

#### Degree Programme Tutor

How can we help you:
                    From choosing a degree programme to your course timetable, from preparing your study plan to taking exams or writing your dissertation. Studying together, getting advice on how to plan your activities.

Contact person's name for the office
                      Luca Patrignani

E-mail
campuscesena.tutorlmisi@unibo.it

#### Internationalisation Tutor

How can we help you:
                    Information on study and research opportunities and mobility programmes abroad.

Contact person's name for the office
                      Alberto Antonello

E-mail
campuscesena.internazionalizzazioneingegneria@unibo.it

Other information
Information on study and research opportunities and mobility programmes abroad.

- Support the right to knowledge