# Consigli e strategie per la scrittura della tesi e l’inserimento nel mondo del lavoro

Dalla bibliografia a come sostenere i primi colloqui. Parliamone online il 26 febbraio.

Pubblicato il
        11 febbraio 2025

Nell’ambito della Giornata dell’orientamento il 26 febbraio tanti eventi dedicati a chi sta pensando alla tesi e per chi sta muovendo i primi passi verso il mondo del lavoro.

Da segnare:

#### Come partecipare

La Giornata di Orientamento è online, la partecipazione è gratuita con iscrizione obbligatoria.

Iscriviti entro il 25 febbraio.

- Sosteniamo il diritto alla conoscenza