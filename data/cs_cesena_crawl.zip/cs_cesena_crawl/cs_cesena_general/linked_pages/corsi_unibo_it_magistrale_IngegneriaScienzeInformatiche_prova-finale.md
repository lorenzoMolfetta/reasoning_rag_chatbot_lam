# Prova finale: modalità e scadenze

Per conseguire la Laurea devi sostenere una prova finale che ha l’obiettivo di verificare il raggiungimento degli obiettivi formativi previsti dal corso.

## Modalità della Prova Finale

La prova finale consiste nella redazione di una tesi su un argomento coerente con i tuoi studi, elaborata in modo originale e con la guida di un relatore. La tesi sarà poi discussa pubblicamente nel corso di un’apposita seduta dinanzi ad una Commissione.
La Commissione ti valuterà avendo come riferimento il tuo curriculum. Nel corso della presentazione puoi decidere di esporre il tuo lavoro con l’ausilio di slide e la Commissione potrà porti delle domande di approfondimento su aspetti metodologici, risultati ed eventuali sviluppi del tuo lavoro.

## La domanda di laurea

Per presentare la domanda di laurea accedi al servizio Studenti Online rispettando le scadenze sia per la presentazione delle domande, sia per il possesso dei requisiti.

## Requisiti di ammissione

Per poterti laureare devi:

- aver sostenuto e verbalizzato tutti gli esami previsti dal tuo piano di studi;
- essere in regola con il pagamento delle tasse;
- aver caricato l’elaborato di tesi (upload della tesi) in formato pdf tramite il servizio Studenti Online. Il caricamento della tesi può essere ripetuto più volte entro la scadenza del possesso dei requisiti. Al momento del caricamento il sistema richiede la definizione delle parole chiave e l'inserimento di un breve abstract;
- aver compilato il questionario Alma Laurea tramite il servizio Studenti Online.

La Segreteria Studenti effettuerà tutti i controlli e in caso di incongruenze verrai contattato per regolarizzazione la tua posizione prima della prova finale.

La domanda di laurea prevede il pagamento dell'imposta di bollo (pari a 32,00 €, ossia due marche da bollo da €16,00: una per la domanda di laurea, una per la pergamena).

Nel caso di presentazione tardiva della domanda di ammissione alla prova finale entro le scadenze previste (indicate in fondo a questa pagina), è previsto il pagamento di una ulteriore indennità di mora di 100€.

La domanda di Laurea è valida per un solo anno accademico. Se lo studente si laurea in un anno accademico successivo dovrà ripresentare domanda di laurea e versare solo l'importo della marca da bollo.

La domanda/prenotazione on line si riferisce a un solo specifico appello. Lo studente, che non riesce a laurearsi nell’appello scelto, deve chiedere l’annullamento della prenotazione alla segreteria studenti e ripresentarla online per un appello successivo, entro le scadenze previste sotto indicate.

UPLOAD DELL’ELABORATO FINALE SU STUDENTI ONLINE

Gli studenti laureandi devono caricare l'elaborato completo di frontespizio, in formato PDF testuale e non protetto da password, su Studenti Online, entro la scadenza.

Il contenuto del file e il livello di accesso in AMS tesi di Laurea devono essere stati concordati preventivamente con il relatore che li approverà successivamente al caricamento della tesi in SOL;

Nuove modifiche al regolamento per l'uso del Marchio dell'Ateneo consentono di inserire il marchio sulla copertina e sul frontespizio della prova finale. Per informazioni ulteriori: https://corsi.unibo.it/magistrale/IngegneriaScienzeInformatiche/utilizzo-del-marchio-di-ateneo-nella-prova-finale

-  Lo studente deve rispettare la scadenza per l'upload del proprio elaborato e ricevere l'approvazione del relatore.

- Solo dopo l'approvazione del relatore lo studente deve scaricare la dichiarazione di deposito, prodotta dal sistema in automatico, firmarla e inviare la scansione via mail bibliotecacesena.info@unibo.it alla Biblioteca, insieme alla scansione del proprio documento di identità (come da istruzioni nel Box Allegati), per le tesi il cui livello di accesso lo prevede. Solo con l’invio della dichiarazione di deposito si potrà procedere alla pubblicazione online del lavoro di tesi nell’archivio istituzionale dell’Ateneo AMS Tesi di Laurea, in base al livello di accesso prescelto e concordato con il relatore.

## 

## Scadenze

Ogni anno è prevista un’unica sessione di laurea. All’ interno della sessione sono previsti gli appelli per i quali sono indicati i termini che riguardano la presentazione della domanda di laurea, il possesso dei requisiti necessari, le date delle sedute.

Calendario a.a. 2024/2025

| Scadenza presentazione di laurea   |  Scadenza domanda di laurea tardiva (con indennità di mora)    |  Scadenza requisiti di carriera    |  Scadenza upload tesi di  laurea da parte studente    |  Approvazione tesi da parte del relatore    |    Consegna dichiarazione di deposito    |  Appello di Laurea    |
|------------------------------------|----------------------------------------------------------------|------------------------------------|-------------------------------------------------------|---------------------------------------------|------------------------------------------|-----------------------|
| 05/06/2025                         | 19/06/2025                                                     | 26/06/2025                         | 10/07/2025                                            | 14/07/2025                                  | 15/07/2025                               | 17/07/2025            |
| 20/08/2025                         | 04/09/2025                                                     | 10/09/2025                         | 24/09/2025                                            | 29/09/2025                                  | 01/10/2025                               | 02/10/2025            |
| 30/10/2025                         | 13/11/2025                                                     | 20/11/2025                         | 04/12/2025                                            | 09/12/2025                                  | 10/12/2025                               | 11/12/2025            |
| 29/01/2026                         | 12/02/2026                                                     | 19/02/2026                         | 05/03/2026                                            | 09/03/2026                                  | 12/03/2026                               | 13/03/2026            |

### Vedi anche

- Volume PDF e Deposito online dell'elaborato
- Riprese fotografiche e video durante le sedute di laurea
- Istruzioni AMS Laurea

[
          .pdf
          122Kb
          ]

### Contatti

#### Servizio didattico

Come ti può aiutare
                    Informazioni sull'orario delle lezioni, supporto per l’iscrizione agli appelli d’esame, compilazione del piano degli studi, riconoscimento dei crediti nel caso di trasferimenti o passaggi di corso e organizzazione delle sedute di laurea.

E-mail
campuscesena.didattica.isa@unibo.it

Telefono
+39 0547338300
Orario telefonico

Altre informazioni
Puoi contattarci via e-mail e via Teams. Scrivi una e-mail per informazioni o per un collegamento diretto tramite l'app Teams. Riceverai una e-mail con data, ora e link a cui collegarti dopo aver scaricato l'app.

#### Segreteria studenti

Come ti può aiutare
                    Iscrizioni, cambi di corso, trasferimenti da e verso altri atenei, laurea, diploma supplement e altre procedure.

Nome referente
                      Stefano Macrelli

Sportello virtuale

E-mail
segcesena@unibo.it

Indirizzo
Palazzo Urbinati - Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico

                            Mercoledì
                            9-12

Altre informazioni
Prendi un appuntamento via e-mail per la consegna dei documenti oppure inviali per posta.

- Sosteniamo il diritto alla conoscenza