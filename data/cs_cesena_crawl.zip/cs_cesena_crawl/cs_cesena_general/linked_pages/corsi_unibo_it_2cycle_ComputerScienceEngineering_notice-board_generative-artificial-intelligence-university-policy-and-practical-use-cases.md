# Generative Artificial Intelligence: University Policy and Practical Use Cases

Guidelines, practical examples, and operational insights to ethically and responsibly use GenAI in your academic journey.

Published on
        10 January 2025

The University of Bologna has introduced a policy to promote the ethical and responsible use of Generative Artificial Intelligence (GenAI) in academic activities, ensuring its integration aligns with academic standards of quality, ethics, and integrity.

## Why is the policy important?

- Practical Guidelines
The policy provides actionable guidelines for responsibly using GenAI in academic activities, ensuring awareness and accountability.
- Real-World Applications
Real-world examples illustrate how GenAI can be applied in various contexts, helping you understand its potential and limitations.
- Support for Learning and Research
Familiarizing yourself with the policy ensures you can leverage GenAI's opportunities while adhering to ethical standards.

For further details, visit the dedicated page on the University of Bologna website.

## Want to learn more?

Join our series of events, "For an Ethical and Responsible Use of Generative AI: From Knowledge to Applications," (in Italian only) available both in person and online.

View the schedule and register now!

- Support the right to knowledge