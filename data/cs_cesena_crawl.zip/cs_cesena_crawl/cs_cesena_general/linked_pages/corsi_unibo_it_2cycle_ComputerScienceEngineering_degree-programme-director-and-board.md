# Degree Programme Director and Board

Degree Programme Director and Board: duties and responsibilities.

## Director

Annalisa Franco

The Degree Programme Director is elected by the professors and researches oin the Degree Programme Board. The Director, who remains in office for three years, is responsible for the implementation of the Board’s guidelines, acting as a liaison with relevant Departments and other structures.

## Degree Programme Board

The Degree Programme Board is formed by the academic staff responsible for the teaching activities of the Degree Programme and by three student representatives, elected according to University regulations.
 The Degree Programme Board formulates recommendations regarding didactic planning, system revisions and teaching regulations for the various Departments. It also formulates recommendations regarding teaching organisation and support activities for the various Departments.

Its duties include:

- forming progress verification committees;
- recognising credits;
- authorising and recognising learning activities carried out abroad, within international mobility programmes (Learning Agreement);
- organising graduation exam boards and their schedules.

- Support the right to knowledge