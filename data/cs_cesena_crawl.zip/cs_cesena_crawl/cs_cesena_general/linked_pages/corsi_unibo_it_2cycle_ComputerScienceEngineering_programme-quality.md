# Programme Quality: facts and figures

In line with transparency principles and the university's actions fostering programme and service quality, we wish to provide useful data about the Degree Programme, in particular from the last 3 years.

"Cohort" refers to a student group starting university in a given year and does not include students transferring from another programme or students acquiring a second degree. Specific years or topics might be missing if the programme has not completed a full cycle.

Data updated to June 18, 2024

## Students

### Number of enrolled students

#### A.Y. 2023-2024

- first year

75
- subsequent years

68
- "fuori corso" (years in addition)

62

#### A.Y. 2022-2023

- first year

71
- subsequent years

78
- "fuori corso" (years in addition)

67

#### A.Y. 2021-2022

- first year

83
- subsequent years

79
- "fuori corso" (years in addition)

55

### Gender

- Female students 15.1%
- Male students 84.9%

- Female students 10.4%
- Male students 89.6%

- Female students 15.6%
- Male students 84.4%

### Programme attractiveness

#### Cohort 2023/2024

- Residents in other Italian regions
19.2%
- Residents abroad
4.1%

#### Cohort 2022/2023

- Residents in other Italian regions
26.9%
- Residents abroad
3%

#### Cohort 2021/2022

- Residents in other Italian regions
27.3%
- Residents abroad
3.9%

### Required qualification

- Bachelor's degree from University of Bologna
                                                            84.9%
- Bachelor's degree from other university (including international degrees)
                                                            15.1%

- Bachelor's degree from University of Bologna
                                                            85.1%
- Bachelor's degree from other university (including international degrees)
                                                            14.9%

- Bachelor's degree from University of Bologna
                                                            83.1%
- Bachelor's degree from other university (including international degrees)
                                                            16.9%

## Compliance with study plan

### Students moving on to second year

#### Cohort 2022/2023

- Students leaving university
13.4%
- Students transferring to another programme
0%

#### Cohort 2021/2022

- Students leaving university
14.3%
- Students transferring to another programme
0%

#### Cohort 2020/2021

- Students leaving university
8.2%
- Students transferring to another programme
0%

The item "Students leaving university\Students transferring to another programme" includes students transferring to another university and those transferring to a different programme of the University of Bologna.

### Exams and average marks

Most recent data on programme's course units

### Graduates

#### Cohort 2021/2022

- Graduates aligned to the exam schedule
41.6%

#### Cohort 2020/2021

- Graduates aligned to the exam schedule
30.1%

#### Cohort 2019/2020

- Graduates aligned to the exam schedule
29.3%

## International mobility

### International mobility programme participants

- A.Y. 2023-2024

12
- A.Y. 2022-2023

12
- A.Y. 2021-2022

9

### Graduates with experience abroad

- Year 2023

23.7%
- Year 2022

13.2%
- Year 2021

8.2%

## Students' opinions

### What students say about the programme

Statistical data regarding programme's course units.

### Graduate satisfaction

#### Year 2023

- 97.7%
With this programme
- 90.6%
With programmes in the same Class (Italy)

Satisfied graduates

#### Year 2022

- 94.3%
With this programme
- 90.3%
With programmes in the same Class (Italy)

Satisfied graduates

#### Year 2021

- 93%
With this programme
- 92.3%
With programmes in the same Class (Italy)

Satisfied graduates

- With this programme
- With programmes in the same Class (Italy)

AlmaLaurea survey

## Situation 1 year after graduation

- 92.3%
With this programme
- 90%
With programmes in the same Class (Italy)

Work

- 0%
With this programme
- 4.5%
With programmes in the same Class (Italy)

Don't work and look for work

- 7.7%
With this programme
- 5.5%
With programmes in the same Class (Italy)

Don't work and don't look for work

- 87.8%
With this programme
- 92.5%
With programmes in the same Class (Italy)

Work

- 2.4%
With this programme
- 2.2%
With programmes in the same Class (Italy)

Don't work and look for work

- 9.8%
With this programme
- 5.3%
With programmes in the same Class (Italy)

Don't work and don't look for work

- 87.9%
With this programme
- 76.2%
With programmes in the same Class (Italy)

Work

- 6.1%
With this programme
- 5.1%
With programmes in the same Class (Italy)

Don't work and look for work

- 6.1%
With this programme
- 18.7%
With programmes in the same Class (Italy)

Don't work and don't look for work

- With this programme
- With programmes in the same Class (Italy)

AlmaLaurea survey

- Support the right to knowledge