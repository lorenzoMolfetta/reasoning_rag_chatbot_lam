# Balancing study and work

The University of Bologna supports you in your university journey to help you balance study activities with your work commitments.

Additional support measures will be published on this page in the coming months. You can find detailed information about specific measures for your programme of study on its website.

## Who can benefit

These measures are dedicated to those who obtain recognition of the "working student" status, which you can request at the time of the notice publication if you meet the following requirements:

    1. You are enrolled in a Bachelor's, Single Cycle, or Master's Degree programme and have registered for the academic year 2024/25
    2. You have performed work activity:
- For at least 3 months, with a commitment of at least 4 hours per week, in the twelve months preceding the notice deadline
or
- For no fewer than thirty working days in the twelve months preceding the notice deadline.

## How to apply

Read the notice to find out how to apply

For the academic year 2025/26 you can apply from 17 November 2025 to 16 January 2026.

You must submit your application exclusively through the Studenti Online platform.
Within 60 days of submitting your application, you will find the outcome of your request on Studenti Online.

Once you have obtained the recognition, it will be valid for the entire academic year, and you can reapply for all the years you renew your enrolment.

The achieved status will be visible to professors on the Almaesami online service.

Servizio Conciliazione studio e lavoro: conciliazione.studiolavoro@unibo.it

## What you can count on

If you achieve the status of a working student, the measures available immediately – to which others will be added in the coming months, currently in the planning stage – are as follows:

- Dedicated online appointments with teachers;
- Flexibility in exam dates, varying based on the organisational characteristics of the programme. You must contact the course instructor at least 14 days before the exam date, providing all necessary information. You will be given an alternative date or time or suggested solutions compatible with what individual course units can offer you. Please note that the final decision regarding the request is at the teacher's discretion.
- Dedicated tutoring services for peer-to-peer support activities.

- Support the right to knowledge