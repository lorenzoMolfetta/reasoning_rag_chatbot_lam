# Volume PDF e Deposito online dell'elaborato

La prova finale consiste nella discussione di un elaborato sotto la guida di un docente relatore.

UPLOAD DELLA TESI SU STUDENTI ONLINE

Gli studenti laureandi devono caricare l¹elaborato completo di frontespizio, in formato PDF testuale e non protetto da password, su Studenti Online, entro la scadenza che trovate qui

§  Il contenuto del file e il livello di accesso in AMS tesi di Laurea devono essere stati concordati preventivamente con il relatore che li approverà successivamente al caricamento della tesi in SOL;

§  È vietato riprodurre il logo dell¹Ateneo di Bologna su qualunque parte dell¹elaborato;

§  Il file non dovrà superare i 30Mb.

§  Per pubblicare la tesi in AMS tesi di Laurea è necessario stampare, sottoscrivere e consegnare alla Sezione Centrale della Biblioteca del Campus di Cesena in via dell’Università, 50 la declaratoria che lo studente troverà nel dettaglio della domanda di laurea in StudentiOnLine dopo l¹approvazione del relatore. Per ulteriori informazioni sulla pubblicazione in AMS tesi online si vedano le istruzioni nel box allegati.

## Redazione dell’elaborato

La redazione dell’elaborato dovrà essere standardizzata, con l’avvertenza che non verranno accettati elaborati/tesi redatti in modo difforme dalle seguenti prescrizioni:

- pagine di 32-35 righe, ciascuna di 65-70 caratteri di tipo prestabilito (Times, Courier o Helvetica);

- frontespizio conforme al fac-simile (vedi box allegati);

- figure e tavole in formato UNI (A4 e A3);

- formato PDF.

La conformità dell’elaborato alle regole suddette deve essere verificata anche dal Relatore.

### allegati

- il-diritto-autore-sulla-tesi-di-laurea.pdf

[
          .pdf
          159Kb
          ]
- Frontespizio Laurea Magistrale

[
          .pdf
          124Kb
          ]
- ISTRUZIONI AGLI STUDENTI PER AMS TESI ON LINE

[
          .pdf
          279Kb
          ]

- Sosteniamo il diritto alla conoscenza