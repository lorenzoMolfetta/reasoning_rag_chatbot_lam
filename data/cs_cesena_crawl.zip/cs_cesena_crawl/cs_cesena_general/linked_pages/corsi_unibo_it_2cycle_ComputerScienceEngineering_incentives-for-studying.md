# Incentives for studying

Please refer to: https://www.unibo.it/en/study/study-grants-and-subsidies/scholarships-and-funding-opportunities

- Support the right to knowledge