# Registering for Subsequent Years

Check the two things to remember for continuing your studies after the first year.

## Pay the Fees for the New Academic Year

Until you haven’t completed your degree, you must enrol in your degree programme each year. 
To do this, pay the first instalment or the full amount of the fees. Check from around 25 July for the amounts, discounts, and deadlines to avoid late fees or interruptions in your student career.

Additionally, verify if you meet the merit or income requirements to apply for scholarships.

## Renew Your Residence Permit if You Are a Non-EU Citizen

If you have a student residence permit, remember that you need to renew it each year for the duration of your degree programme.  
Apply for renewal at least 60 days before the expiration date and email a copy of the receipt to your Student Office. 
Go to the renewal procedure

- Support the right to knowledge