# Premio di laurea “Giovanni Grossi”

Per tesi riguardanti l’IA nell’ambito della corporate governance e dei processi di controllo e gestione dei rischi. Rivolta a laureati magistrali nell’anno accademico 2023/2024.

Pubblicato il
        19 marzo 2025

### Per informazioni:

- Bando

- Sosteniamo il diritto alla conoscenza