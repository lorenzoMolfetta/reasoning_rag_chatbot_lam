# Opportunities

<!-- image -->

## Study grants and subsidies

- ER.GO: Regional Authority for the Right to Higher Education in Emilia Romagna
- Exemptions for international students
- Study grants and subsidies
- University canteens, places to eat and discounted catering services

<!-- image -->

## Experiences abroad

- Overseas
- All the opportunities
- Internships abroad

<!-- image -->

## After graduating

- Prospects
- Prepare for the job market
- Job Opportunities

<!-- image -->

## Students and the city

- Living in the city
- Transport and mobility
- Student associations and cooperatives

### University Services

- Student ombudsman
- The psychological support service - SAP
- University Language Centre - CLA
- WIFI
- Almae Matris Alumni Association
- Helpdesk against gender based violence
- Training and guidance internships
- Medical assistance
- Bologna University Sports Centre - CUSB
- University Library System - SBA
- Housing and residences
- Insurance for students
- University Museum Network - SMA
- Services for students with special needs

- Support the right to knowledge