# Valeria Solesin Award

Deadline: 31 July

Published on
        30 May 2025

Graduation award for theses on the theme: “Female talent as a key factor for the development of the economy, ethics, and meritocracy in our country.”

https://forumdellameritocrazia.it/premio-valeria-solesin/pubblicazione-bando-nona-edizione-premio-valeria-solesin.html

- Support the right to knowledge