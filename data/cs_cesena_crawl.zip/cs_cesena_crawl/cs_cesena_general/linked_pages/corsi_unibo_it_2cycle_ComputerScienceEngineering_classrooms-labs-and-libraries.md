# Classrooms, labs and libraries

## Lecture halls

At the Cesena campus, numerous classrooms are available for educational activities, distributed across various facilities. All classrooms have free university Wi-Fi and vary with different equipment and capacities.

## Laboratories

Educational laboratories provide support for both basic and advanced courses. Students can use these laboratories during lessons under the guidance of professors and tutors, as well as outside class hours for individual or group exercises and in-depth study. Both guided and independent activities in these laboratories are a fundamental part of the educational path for Engineering students.

## Library

The Computer Science Section is part of the "Leon Battista Alberti" Central Library at the Cesena Campus. Its services are primarily intended for institutional users (students, faculty, researchers, and administrative staff) but are open to all types of users.

## Study rooms

The Alfa Albatros and Beta study halls, which remain open all-day until late in the evening, significantly enhance study opportunities and provide an important service for university students in Cesena.

- Support the right to knowledge