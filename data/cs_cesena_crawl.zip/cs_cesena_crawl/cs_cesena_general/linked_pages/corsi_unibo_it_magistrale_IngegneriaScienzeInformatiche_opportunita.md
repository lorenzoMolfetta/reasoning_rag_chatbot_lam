# Opportunità

<!-- image -->

## Borse di studio e agevolazioni

- ER.GO: diritto agli studi
- Borse di studio e agevolazioni
- Agevolazioni per gli studenti internazionali
- Borse di studio, premi e altre opportunità
- Alloggi e residenze
- Muoversi in città: agevolazioni e sostenibilità per la comunità Unibo
- Diventare Tutor

<!-- image -->

## Esperienze all'estero

- Mobilità internazionale
- Overseas
- Tutte le opportunità
- Borse di studio per tesi all'estero
- Tirocini all'estero
- Curriculum: Intelligent Embedded Systems - EIT Digital track

<!-- image -->

## Dopo la laurea

- Prospettive
- Prepararti al mondo del lavoro
- Offerte di lavoro
- Hai un'idea? Trasformala in progetto d'impresa

<!-- image -->

## Studenti e città

- Vivere la città
- Trasporti e mobilità
- Mense e punti di ristoro
- Associazioni e cooperative studentesche

### Servizi di Ateneo

- Garante degli studenti
- WIFI
- Assicurazione per gli studenti
- Assistenza sanitaria
- CLA-Centro Linguistico di Ateneo
- CUSB-Centro Universitario Sportivo Bologna
- SBA-Sistema Bibliotecario d'Ateneo
- Servizi per gli studenti con disabilità e con DSA
- Servizio di Aiuto Psicologico a Giovani Adulti (SAP)
- Associazione Almae Matris Alumni
- Sportello universitario contro la violenza di genere
- Tirocini post laurea
- SMA- Sistema Museale d'Ateneo
- Consigliera di Fiducia: un aiuto in caso di discriminazioni, molestie sessuali e psicologiche

- Sosteniamo il diritto alla conoscenza