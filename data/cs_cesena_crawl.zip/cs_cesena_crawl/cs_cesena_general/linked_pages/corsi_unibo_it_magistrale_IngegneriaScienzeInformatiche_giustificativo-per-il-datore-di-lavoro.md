# Giustificativo per il datore di lavoro

Modulo da far firmare al Docente e consegnare al datore di lavoro per certificare l'assenza lavorativa in caso di partecipazione alle lezioni o prove d'esame.

### Allegati

- Giustificativo per datore di lavoro

[
          .pdf
          162Kb
          ]

- Sosteniamo il diritto alla conoscenza