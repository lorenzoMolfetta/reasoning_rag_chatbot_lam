# Tutor del Corso

Il tutor del corso di studio costituisce un utile punto di riferimento per gli studenti nei rapporti con i docenti ed in generale nell'organizzazione delle attività relative al proprio percorso.

## Le funzioni

Il tutor svolge una funzione di interfaccia tra gli studenti e il corso e offre un punto di riferimento concreto per reperire informazioni, ad esempio, sulle modalità di accesso al Corso e lo svolgimento delle attività didattiche.  
Gli studenti possono rivolgersi al tutor anche per segnalare eventuali richieste relative ad aspetti logistici o organizzativi.

Il tutor svolge, inoltre, un'attività di sostegno personalizzato all'apprendimento per quegli studenti, che per ragioni lavorative o altro, abbiano maggiori difficoltà a mantenere una chiara programmazione degli studi e degli esami.

## Tutor per l'internazionalizzazione

Oltre al Tutor del Corso è presente il Tutor per l'internazionalizzazione che svolge attività di informazione e assistenza agli studenti in ingresso e in uscita, nell’ambito di programmi di scambio internazionali (Erasmus+, Overseas, etc.) riservati agli studenti dei corsi di studio.

### Contatti

#### Tutor del corso

Come ti può aiutare
                    Dalla scelta del corso all’orario delle lezioni, dalla compilazione del piano di studi agli esami o alle indicazioni per la tesi. Studia come te, può consigliarti su come organizzare gli studi.

Nome referente
                      Luca Patrignani

E-mail
campuscesena.tutorlmisi@unibo.it

Telefono
Riceve su appuntamento tramite e-mail.
Orario telefonico

#### Tutor per l'internazionalizzazione

Come ti può aiutare
                    Informazioni su opportunità di studio e ricerca all'estero e programmi di mobilità.

Nome referente
                      Alberto Antonello

E-mail
campuscesena.internazionalizzazioneingegneria@unibo.it

Altre informazioni
Riceve su appuntamento tramite e-mail.

- Sosteniamo il diritto alla conoscenza