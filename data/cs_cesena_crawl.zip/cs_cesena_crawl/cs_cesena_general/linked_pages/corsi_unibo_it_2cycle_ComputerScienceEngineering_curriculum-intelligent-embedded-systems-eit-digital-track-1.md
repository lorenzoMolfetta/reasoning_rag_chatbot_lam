# Curriculum: Intelligent Embedded Systems - EIT Digital track

<!-- image -->

The curriculum Intelligent Embedded Systems offers two different tracks which have different admission processes and deadlines. For the details on admissions, refer to the dedicated page.

In the local track, students attend both years at the University of Bologna.

In the EIT Digital Master School track, after the first year at the University of Bologna, students attend the second year in one of the other partner universities in another European country.

## Intelligent Embedded Systems - local track

In the local track, students can attend both the first and second year at the University of Bologna.

Nonetheless, students will be able to apply to the mobility programme offered to students of the University of Bologna (Erasmus+, Overseas, preparation of thesis abroad...).

The admission process and tuition fees are managed directly by the University.

## Intelligent Embedded Systems – EIT Digital Master School track

This version of the curriculum in Intelligent Embedded Systems is part of the EIT Digital Master School. The European Institute of Innovation and Technology (EIT) is an independent EU body created to increase Europe’s ability to innovate by nurturing entrepreneurial talents. The EIT Digital is the branch of the EIT focusing on Digital innovation.

The program offers a two-year education, the first at the University of Bologna, and the second at a University of choice in Budapest, Stockholm, Tallinn, or Turku.
The curriculum is technically focused on Intelligent Embedded Systems but also includes a minor of 30 CFUs covering topics in digital innovation and entrepreneurship.

The first year at the University of Bologna aims to offer a full understanding of the most recent trends in software engineering for embedded systems, including examples of applications. The second year may be chosen to be more software or hardware-oriented and offers a specialization and a graduation project. The graduation project includes an internship at a company or a research institute and results in a Master's thesis with a strong innovation and entrepreneurship dimension.

Part of the curriculum is the EIT Digital Summer School, a two-week programmes held at several locations in Europe, in relation to five areas with major societal and industrial challenges and business opportunities: Digital Cities, Digital Industry, Digital Wellbeing, Digital Tech, and Digital Finance.

The EIT Digital Master School enables the students to engage with academic, research, and industrial partners across Europe. As a student, you will have the opportunity to collaborate with the EIT industrial partners and bring innovation to the market as part of your Innovation and Entrepreneurship studies.

- Support the right to knowledge