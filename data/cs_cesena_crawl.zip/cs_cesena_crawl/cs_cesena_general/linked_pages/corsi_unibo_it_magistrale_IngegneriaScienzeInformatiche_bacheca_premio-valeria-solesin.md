# Premio Valeria Solesin

Premio di laurea sul tema de “Il talento femminile come fattore determinante per lo sviluppo dell’economia, dell’etica e della meritocrazia nel nostro paese.” Scadenza: 31 luglio.

Pubblicato il
        30 maggio 2025

### Per informazioni:

- Link:

- Sosteniamo il diritto alla conoscenza