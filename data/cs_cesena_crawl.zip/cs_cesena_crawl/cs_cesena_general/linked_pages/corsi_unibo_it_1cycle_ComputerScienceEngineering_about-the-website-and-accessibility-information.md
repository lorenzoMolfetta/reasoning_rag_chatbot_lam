# About the website and accessibility information

How the website is managed and organised, and by whom

## Management and updating of contents

Website updates are carried out by the degree programme web team.

### Website design and development

The website was built on the Open Source Plone platform. University Portal Unit – Artec and Web Technology Unit - Cesia are responsible for the design and development.

### Images

Unless otherwise stated, the images are part of the University database managed by the Communications Unit.

## Accessibility

A website is accessible when it allows you to easily access the contents and services it offers, independently of any mental or physical disability, technical equipment or context in which you are working.

This website was developed in compliance with the current provisions on the accessibility of websites and using the Responsive Web Design technique, to allow consultation also from mobile devices.

### Accessibility statement

Accessibility statement (in Italian)

### Accessibility reports

Despite monitoring, it is not always possible to guarantee full accessibility to the website, we therefore ask you to report any difficulties you may have in accessing the information and services by writing to accessibile@unibo.it.

- Support the right to knowledge