# Quality Assurance Committee and other Committees

In order to carry out some of its functions, the Degree Programme Board is assisted by committees comprised of teachers involved in the programme. These committees are listed below, indicating their specific functions and contact persons.

## Quality Assurance Committee

The Degree Programme Quality Assurance Committee helps the Coordinator to monitor the quality assurance procedures and promote a culture of quality.

For this purpose, the Quality Assurance Committee is responsible for:

- verifying implementation of the improvement measures approved in the annual report of the Degree Programme Board;
- monitoring the careers of students, their opinions about the learning activities and their level of satisfaction at the end of the programme, as well as graduate employment rates;
- reporting the results of its monitoring activities to the Degree Programme Board.

University regulations require the Degree Programme Quality Assurance Committee to comprise the Coordinator and other members of the Degree Programme Board, including student representatives:

Members of the Committee:

- Prof. Annalisa Franco
- Prof. Alessandro Ricci
- Prof. Mario Bravetti
- Prof. Mirko Viroli
- Prof. Matteo Ferrara
- Dr. Gabriele D'Angelo
- Dr. Roberto Girau
- Dr. Giovanni Ciatto

## Degree programme Teaching Committee

The Degree programme Teaching Committee assists the Course Coordinator in the activities related to the proper functioning and coordination of the teaching activity.

Members of the Committee:

- Prof. Annalisa Franco
- Prof. Mirko Viroli
- Prof. Matteo Ferrara
- Prof. Alessandro Ricci
- Prof. Antonella Carbonaro
- Prof. Mario Bravetti
- Dr. Gabriele D’Angelo
- Dr. Roberto Girau
- Dr. Giovanni Ciatto

## Students' Administrative procedures Committee

The Students' Administrative procedures Committee assesses:

- applications to change or transfer to the Degree Programme;
- changes to the study plans of the students enrolled in the Degree Programme;

Members of the Committee:

- Prof. Alessandro Ricci
- Prof. Andrea Roli
- Prof. Roberto Girau

## Internship Committee for the final examination preparation

The Committee approves the internship requests for the final examination preparation.

Members of the Committee:

- Prof. Damiana Lazzaro (approves the start of internships and recognizes work or extracurricular activities as substitutes for the internship in final thesis preparation)
- Prof. Annalisa Franco (evaluates and records the training activity in preparation for the final thesis)
- Prof. Mario Bravetti (evaluates and records the training activity in preparation for the final thesis)

## EIT and IES Students' Administrative Procedures Committee

Members of the Committee:

- Prof. Andrea Roli
- Prof. Franco Callegati
- Prof. Mirko Viroli

## Guidance Committee

The Guidance Committee organizes initiatives to provide clearer information about the Degree Programme's content, enabling prospective students to make a more informed decision about enrollment.

Referent:

- Prof.ssa Alessandra Lumini

## Internationalization Committee

This committee authorizes the activities to be carried out abroad and to be added in the Learning Agreement, and authorizes the recognition of the corresponding credits acquired during mobility programmes, nationally or abroad.

Members of the Committee:

- Prof. Andrea Roli
- Prof. Vittorio Maniezzo
- Prof. Giovanni Ciatto

Contacts: campuscesena.internazionalizzazioneingegneria@unibo.it

- Support the right to knowledge