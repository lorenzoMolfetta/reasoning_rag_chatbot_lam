# Student administration offices

The administration of student careers for this Degree Programme is managed by several offices.

## Student Administration Office

The Office is responsible for managing the academic records of students enrolled in the program. In particular, it handles all administrative activities: from enrollment to transfers between degree programmes, from issuing certificates and duplicates to monitoring university tuition fees, from processing applications for the graduation exam to issuing degree diplomas.

## Degree Programmes Office for Engineering, Science, and Architecture

The Office coordinates and oversees activities related to the functioning of Degree Programmes and the organization of educational activities in support of students and faculty. STAFF: Alberto Alvisi, Rita Baldrati, Fabio Grotti, Romina Mingozzi, Maria Smurro.

## International Relations and Internship Office - Internships Service

The office promotes experiences for students to complete their academic journey and transition into the job market through the promotion, organization, and management of internship opportunities. These include curricular and post-graduate internships, including professional training internships, in collaboration with partner organizations and academic structures in Cesena.

The office particularly focuses on developing and strengthening relationships with companies, local institutions, and associations to facilitate graduates' entry into the workforce.

## International Relations and Internship Office -

## International Relations Service

The International Relations Office works with the University’s International Relations Division to manage international mobility programs. It provides information on study, internship, and training opportunities abroad for students enrolled in programs at the Cesena Campus. Additionally, the office welcomes and supports exchange students, international students, and visiting faculty or administrative staff at the Cesena campus.

- Support the right to knowledge