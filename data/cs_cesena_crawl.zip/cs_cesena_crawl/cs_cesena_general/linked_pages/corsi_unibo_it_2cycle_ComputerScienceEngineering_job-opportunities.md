# Job Opportunities

## Job announcements board for undergraduates and graduates

The job announcements board lists available jobs offered by companies. It is reserved exclusively for graduates / undergraduates (those who have applied for a degree) of the University of Bologna.

Job offers are published and updated in real time, allowing you to choose the ones most suited to your studies, and your skills and aspirations.

To apply for a job offer, log in with the AlmaLaurea credentials you were given when completing the pre-degree questionnaire.

Access the job announcements board

## Are you a company that wants to offer a job opportunity?

The Job Placement service promotes collaborations with companies in order to better exploit the skills of graduates in the labor market.

It’s quick and easy to access and use the service if you want to publish job offers and consult the CVs of undergraduates / graduates.

Register, enter your ad and consult the graduate database for free

The Job Placement service also provides support during the registration process and to customize your database search.

- Support the right to knowledge