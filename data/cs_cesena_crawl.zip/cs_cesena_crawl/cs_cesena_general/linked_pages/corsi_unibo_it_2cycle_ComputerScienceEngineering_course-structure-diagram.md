# Course Structure Diagram

## Plans available in A.Y. 2025/2026

Look at the course structure diagram you are interested in, based on your year of enrolment.

- Codice 6699
- Codice 8614

8614 - Computer Science and Engineering

### CURRICULUM Computer Science and Engineering

- Curriculum Ingegneria e Scienze Informatiche: for students enrolled a.y. 2024-25

### CURRICULUM INTELLIGENT EMBEDDED SYSTEMS

- Curriculum Intelligent Embedded Systems: for students enrolled a.y. 2024-25

### Highlights

- Curriculum in Intelligent Embedded System - Course Structure Diagram a.y. 21/22

[
          .pdf
          152Kb
          ]
- Elective courses: pieces of advice

- Support the right to knowledge