# Cosa dicono i nostri studenti

<!-- image -->

Ho scelto la Magistrale di Cesena perchè ho ritenuto estremamente positiva la flessibilità che veniva fornita nella compilazione del piano di studio.  A posteriori posso anche dire che la qualità della didattica che mi aspettavo è stata assolutamente confermata.

Alberto Giunta, studente

<!-- image -->

Grande passione per le nuove tecnologie, insieme al giusto mix tra la ricerca dello stato dell'arte e un approccio pragmatico ai problemi fuori dal contesto accademico. Lezioni sempre stimolanti, ottimo rapporto tra studenti e docenti completano il quadro e spiegano perché oggi sceglierei ancora questo corso.

Fabio Limardo, laureato

- Sosteniamo il diritto alla conoscenza