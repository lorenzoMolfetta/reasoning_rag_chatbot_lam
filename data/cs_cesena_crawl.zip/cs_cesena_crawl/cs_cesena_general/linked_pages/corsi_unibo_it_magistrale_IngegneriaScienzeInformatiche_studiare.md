# Studiare

<!-- image -->

## Attività didattiche

- Insegnamenti: piano didattico
- Calendario didattico
- Orario delle lezioni
- Frequenza delle lezioni
- Appelli d'esame
- Compilare il Piano di studi
- Docenti
- Aule, laboratori e biblioteche
- Formazione obbligatoria su sicurezza e salute

<!-- image -->

## Tirocinio

- Tirocinio in preparazione della prova finale
- Tirocini all'estero
- Richiesta riconoscimento attività lavorativa o extra-universitaria in sostituzione del tirocinio
- Tirocini curriculari in Scuole e Organizzazioni no profit

<!-- image -->

## Prova finale

- Prova finale: modalità e scadenze
- Redazione della tesi e voto finale
- Borse di studio per tesi all'estero

<!-- image -->

## Preparati al mondo del lavoro

- Idee sul futuro: i passi da compiere
- Imprenditorialità: dall'idea al progetto di startup
- Preparati per incontrare le aziende

### Come fare per

- Trasferirsi ad altro Ateneo
- Gestire un infortunio
- Ottenere un certificato o un duplicato
- Passaggio (opzione) al Corso di Nuovo Ordinamento
- Lasciare e riprendere gli studi
- Giustificativo per il datore di lavoro
- Sistema Bibliotecario di Ateneo - Informazioni e supporto da studente a studente tramite LiveChat su Teams
- Prolungare la durata degli studi - Studente a tempo parziale
- Ottenere lo status di studente-atleta
- Attivare una carriera alias
- Conciliare studio e lavoro
- Rinnovo del permesso di soggiorno
- Riconoscimento crediti
- Cambiare Corso

- Sosteniamo il diritto alla conoscenza