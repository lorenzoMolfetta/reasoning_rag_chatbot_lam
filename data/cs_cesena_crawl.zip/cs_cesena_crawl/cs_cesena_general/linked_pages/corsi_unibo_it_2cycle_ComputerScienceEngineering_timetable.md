# Course Timetable

View the lecture schedule for the year you are enrolled in.

Lectures in the academic year 2024/25 will be in person.

ACADEMIC CALENDAR

You will be able to see the times once you have selected year and curriculum.

- Support the right to knowledge