# Admission

<!-- image -->

## How to apply

- Programme enrolment: requirements, deadlines and methods
- Registering for Subsequent Years
- Incentives for studying

<!-- image -->

## Guidance

- Degree Programme Tutor
- Guidance
- Lecture attendance
- How to reduce costs, avail of services and live better while studying

### How to

- Transfer to a study programme running under the new degree programme system
- Enrolling in single learning activities
- Balancing study and work
- Recognition of academic qualifications
- Leaving and returning to university
- Activate an alias career
- Transferring to the University of Bologna
- Obtain student-athlete status
- Institutional credentials and student access to Bologna University online services
- Enrolling in years following the first one
- Recognition of credits

- Support the right to knowledge