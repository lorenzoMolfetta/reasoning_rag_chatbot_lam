# Archivio notizie

### Pubblicato bando CV Italiano Ingegneria e scienze informatiche 25/26

Leggi attentamente il bando e segui i passi per l'iscrizione

Pubblicato il
                            04 giugno 2025

### Premio di laurea Bernardo Nobile

L’Area Science Park bandisce premi di laurea per valorizzare studi e metodologie relativi alla proprietà intellettuale e a tecnologie deep tech. Scadenza: 30 giugno.

Pubblicato il
                            30 maggio 2025

### Premio Valeria Solesin

Premio di laurea sul tema de “Il talento femminile come fattore determinante per lo sviluppo dell’economia, dell’etica e della meritocrazia nel nostro paese.” Scadenza: 31 luglio.

Pubblicato il
                            30 maggio 2025

### Idoneità linguistica.

Scopri quando puoi sostenerla: consulta il calendario delle prossime date e delle iscrizioni.

Pubblicato il
                            26 maggio 2025

### Hai un’idea imprenditoriale? Hai un’idea da sviluppare e ti piacerebbe capire come trasformarla in un’impresa?

ISIHUB Romagna ti offre un percorso formativo gratuito per supportarti nella crescita e accompagnarti in ogni fase de tuo progetto !

Pubblicato il
                            19 maggio 2025

### Call for Players 2025

Non hai avuto modo di partecipare all'evento evento concluso ad aprile 2025? Non temere, puoi ancora contribuire a creare una startup di successo. Scopri come fare.

Pubblicato il
                            13 maggio 2025

### Premio tesi di Laurea Antonio Genovesi.

Guida La Fondazione Finanza Etica bandisce un premio per tesi in tema di finanza etica variamente declinata. Scadenza: 19 agosto.

Pubblicato il
                            13 maggio 2025

### Premio Tesi di Laurea “Ingenio al Femminile”

Il Consiglio Nazionale degli Ingegneri bandisce un concorso a premi riservato a donne ingegnere in tema  di "Intelligenza artificiale per le nuove sfide del 2050". Scadenza: 30 giugno.

Pubblicato il
                            13 maggio 2025

### Bando tirocini MAECI – Scadenza: 20 maggio

È online il bando di selezione per 14 tirocini curriculari della durata di tre mesi presso le Scuole italiane all’estero.

Pubblicato il
                            06 maggio 2025

### Una Europa Student Visual Art Contest 2025

Sei pronto a mostrare la tua creatività? Partecipa al concorso per esprimere il tuo talento attraverso un'opera che rappresenti il tema dell'Alleanza tra università. Scadenza: 11 maggio.

Pubblicato il
                            28 aprile 2025

### Referendum popolari abrogativi - voto fuorisede

Studi in un comune di una provincia diversa da quella di iscrizione elettorale? Puoi chiedere di votare nel tuo comune di domicilio temporaneo.

Pubblicato il
                            28 aprile 2025

### Chiusura delle sedi venerdì 18 aprile 2025

In occasione delle Festività Pasquali

Pubblicato il
                            17 aprile 2025

- 1
- 2
- 3
- 4
- Successivi 12 elementi

- Sosteniamo il diritto alla conoscenza