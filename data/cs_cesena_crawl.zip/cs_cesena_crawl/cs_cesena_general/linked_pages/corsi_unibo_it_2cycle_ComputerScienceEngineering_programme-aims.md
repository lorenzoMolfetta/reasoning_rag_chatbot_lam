# Programme aims

If you haven’t enrolled yet, please look at code 6699.
 If you have already enrolled, the course code is available in Studenti Online.

- Codice 6699
- Codice 8614

8614 - Computer Science and Engineering

The 2nd cycle degree programme in Computer Science and Engineering aims specifically to train professional specialists, as described i the list of functions and competences for this figure.
 The specific learning outcomes are achieved through a curriculum focusing on three main learning areas, consistent with the competences required by the professional profiles which aim to provide learning in products, processes and management:
 1. Specialist transversal computer skills
 2. Analysis, design and management of computer, web and network systems
 3. Design of embedded systems and infrastructures
 In addition to these three learning areas, graduates will develop communication and self-learning skills.
 These learning outcomes are achieved through a curriculum focusing on laboratory work, facilitating the practical application of theoretical and methodological learning.
 The study plan thus provides learning opportunities within a system of the above described competences, guaranteeing the ability to respond to different specialist demands for the advanced analysis and design of processes and products relating to production and industrial research.

### Archive

- Support the right to knowledge