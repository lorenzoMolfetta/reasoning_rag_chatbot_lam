# Course Structure Diagram

## Plans available in A.Y. 2025/2026

Look at the course structure diagram you are interested in, based on your year of enrolment.

- Codice 6673
- Codice 8615

8615 - Computer Science and Engineering

- Course structure diagrams for students enrolled a.y. 2024-25
- Course structure diagrams for students enrolled a.y. 2023-24

- Support the right to knowledge