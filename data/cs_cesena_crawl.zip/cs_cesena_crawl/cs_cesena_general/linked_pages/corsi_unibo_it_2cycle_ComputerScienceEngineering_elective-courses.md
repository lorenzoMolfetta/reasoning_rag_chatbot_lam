# JavaScript required

JavaScript is required. This web browser does not support JavaScript or JavaScript in this web browser is not enabled.

To find out if your web browser supports JavaScript or to enable JavaScript, see web browser help.

<!-- image -->

Sign in

Alma Mater Studiorum

University of Bologna

Having trouble logging in?

Forgot your credentials?Do you want to change your password?

More information about credential
Choose the appropriate credential type:

- @studio.unibo.it
- @unibo.it
- @esterni.unibo.it