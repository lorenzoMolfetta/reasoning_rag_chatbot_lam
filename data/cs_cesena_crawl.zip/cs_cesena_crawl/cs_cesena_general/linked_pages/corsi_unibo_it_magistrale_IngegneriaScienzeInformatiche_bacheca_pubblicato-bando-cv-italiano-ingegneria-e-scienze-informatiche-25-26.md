# Pubblicato bando CV Italiano Ingegneria e scienze informatiche 25/26

Leggi attentamente il bando e segui i passi per l'iscrizione

Pubblicato il
        04 giugno 2025

Il bando è disponibile al link: https://corsi.unibo.it/magistrale/IngegneriaScienzeInformatiche/iscriversi-al-corso

Consulta il riquadro in basso a destra.

- Sosteniamo il diritto alla conoscenza