# home page

<!-- image -->

## From ideas to systems

Design, transform and innovate with information technology.

- Place of teaching

                                    
                                        Cesena
- Language

                                    
                                        English, Italian
- Degree Programme Class
                            
                            
                                LM-18 - Computer science
LM-32 - Computer systems engineering
- Degree Programme Director


                                        Annalisa Franco
- Type of access

                                    
                                        Open access
- International programmes

                                    
                                        Double/Multiple degree
- Department

Computer Science and Engineering - DISI
- Proposed paths (Curricula)
    - INTELLIGENT EMBEDDED SYSTEMS
    - COMPUTER SCIENCE AND ENGINEERING
- State

                                
                                    Programme will run only following the completion of the established ministerial procedure.

## What you need today

- Course timetable
- Course structure diagram
- Exam Dates
- Faculty List
- Towards the job market
- Study method

## What to keep in mind

News, events, and notices for your studies

### Call for the Italian curriculum A.Y. 25/26 Computer Science and Engineering is online!

You can now apply.

### Bernardo Nobile Graduation Award

Deadline: 30 June

### Valeria Solesin Award

Deadline: 31 July

Who it's for: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando per il programma di mobilità internazionale TNE - Studio

Deadline: 14 nov 2025

Who it's for: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di Concorso per n. 1 assegno di tutorato per la realizzazione di materiale didattico accessibile per studenti con disabilità e con DSA Sede di Bologna

Deadline: 31 lug 2025, 13:00

Who it's for: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di concorso per n. 11 assegni di tutorato di Area medico - scientifica - tecnologica per attività a supporto degli studenti con disabilità e con DSA presso il Servizio per studenti con disabilità e con DSA sedi di Bologna e Campus della Romagna

Deadline: 31 lug 2025, 13:00

<!-- image -->

## Summer and Winter Schools

Deepen your interests and enhance your skills, broaden your horizons through interdisciplinary and cultural experiences.

Deepen your interests

## Pursue your interests and passions

- Transferable skills

Enhance your resume and foster relationships, even in the workplace.
- International experiences

Add an international dimension to your university journey, from study programmes to internships.
- Sports and culture

Take advantage of opportunities and initiatives to enrich your free time with sports and cultural experiences.
- Libraries and digital resources

A wealth of science, art, and history at your disposal for free, even online.

- Support the right to knowledge