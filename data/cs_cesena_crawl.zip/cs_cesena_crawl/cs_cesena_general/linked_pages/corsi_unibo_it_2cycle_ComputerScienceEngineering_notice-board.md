# Notice board

## Call for Applications

Who it's for: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando per il programma di mobilità internazionale TNE - Studio

Deadline: 14 nov 2025

Who it's for: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di Concorso per n. 1 assegno di tutorato per la realizzazione di materiale didattico accessibile per studenti con disabilità e con DSA Sede di Bologna

Deadline: 31 lug 2025, 13:00

Who it's for: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di concorso per n. 11 assegni di tutorato di Area medico - scientifica - tecnologica per attività a supporto degli studenti con disabilità e con DSA presso il Servizio per studenti con disabilità e con DSA sedi di Bologna e Campus della Romagna

Deadline: 31 lug 2025, 13:00

Who it's for: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di concorso per l’assegnazione di contributi a favore di studenti con disabilità e a favore di studenti con disturbi dell’apprendimento iscritti all’A.A. 2024/2025

Deadline: 17 giu 2025, 17:00

Check the scholarships, exemptions, incentives, and upcoming calls for applications.

Go to the university's call for applications website

## News

### Call for the Italian curriculum A.Y. 25/26 Computer Science and Engineering is online!

You can now apply.

### Bernardo Nobile Graduation Award

Deadline: 30 June

### Valeria Solesin Award

Deadline: 31 July

### International info session

Are you an international prospective student? Join our online sessions to get practical information about tuition fees, financial aid, and benefits available through ER-GO.

### Antonio Genovesi Thesis Award

The Ethical Finance Foundation announces a prize for theses on the various aspects of ethical finance. Deadline: 19 August.

### “Ingenio al Femminile” Thesis Award

The National Council of Engineers announces a prize competition reserved for female engineers on the theme: "Artificial Intelligence for the New Challenges of 2050". Deadline: 30 June.

## Events

There are no events

## Orientation events

At the moment there are no new events

- Support the right to knowledge