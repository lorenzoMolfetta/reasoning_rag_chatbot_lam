# What will you study during this Programme?

Discover in here which learning opportunities this Programme can offer you.

The degree programme in Computer Engineering and Science is one of the first in Italy to offer students a comprehensive approach to computer science, covering both engineering/design aspects and mathematical/scientific foundations.

The Master's Degree in Computer Engineering and Science serves as a natural continuation of the Bachelor program, allowing students to further deepen their theoretical, methodological, and technological expertise in computer science while acquiring practical skills relevant to the job market.

The program offers two alternative curricula: "Computer Science and Engineering" and "Intelligent Embedded Systems".

## Curriculum "Computer Science and Engineering"

The Computer Science and Engineering curriculum, taught in Italian, first aims to develop and strengthen specialized skills in the following fields: programming languages and computational paradigms; software design and development; operating systems and concurrent/multi-core programming; information systems and web technologies; distributed systems and computer networks; network and system security;  machine learning.

Then, the programme gives students the possibility to choose a given number of elective courses to deepen specific topics. In particular, all second-year courses are elective and are organized into two profiles.

### Data Knowledge Engineering Profile

This profile focuses on modeling and algorithms for the creation and use of knowledge in advanced business and scientific applications, falling within the reference areas of Business Intelligence, Semantic Web, and Internet-of-Things.

The elective courses of this profile include: Big Data, Business Intelligence, Data Mining, Project Management, Operational Analytics, Semantic Web.

### Software Systems Engineering Profile

This profile addresses software development for modern distributed and autonomous systems, with a focus on ICT contexts such as IoT, Pervasive Computing, Smart Cities, Artificial Vision, and Robotics.

The elective courses of this profile include:

- "Software Architect" area: Advanced Software Modelling and Design, Software Architecture and Platforms, Software Process Engineering

- "Intelligent Systems" area: Intelligent Systems Engineering, Intelligent Robotic Systems, Computer Vision

### Additional elective courses of the 2nd year

Internet Routing and Transport, Smart Vehicular Systems, Laboratory of Network Programmability and Automation, Deep Learning, 3D Image Analysis and Computer Vision Systems.

To learn more: Course structure

## Curriculum "Intelligent Embedded Systems"

The curriculum Intelligent Embedded Systems (entirely taught in English) offers two different tracks which have different admission processes and deadlines.

In the local track, students attend both years at the University of Bologna.

In the EIT Digital Master School track, after the first year at the University of Bologna, students attend the second year in one of the other partner universities in another European country.

More details about the Intelligent Embedded Systems curriculum are available at this link.

- Support the right to knowledge