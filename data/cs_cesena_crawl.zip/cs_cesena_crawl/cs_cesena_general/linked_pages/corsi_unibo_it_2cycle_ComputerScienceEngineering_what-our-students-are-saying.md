# What our students are saying

<!-- image -->

I chose the Master's program in Cesena because I found the flexibility offered in creating the study plan extremely positive. In hindsight, I can also say that the quality of the teaching I expected was fully confirmed.

Alberto Giunta, student

<!-- image -->

A great passion for new technologies, combined with the right balance between the pursuit of state-of-the-art solutions and a pragmatic approach to problems beyond the academic context. Always stimulating lessons and excellent relationships between students and professors complete the picture and explain why I would still choose this course today.

Fabio Limardo, graduated student

- Support the right to knowledge