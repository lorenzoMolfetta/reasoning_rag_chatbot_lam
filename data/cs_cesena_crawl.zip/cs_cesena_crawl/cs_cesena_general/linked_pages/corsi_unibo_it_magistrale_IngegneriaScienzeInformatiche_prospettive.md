# Prospettive

Se devi iscriverti fai riferimento al codice 6699.
 Se sei già iscritto puoi verificare il codice del tuo corso su Studenti Online.

- Codice 6699
- Codice 8614

8614 - Ingegneria e scienze informatiche

## Profili professionali

### Specialista in ingegneria e scienze informatiche  (esame stato non necessario se non in regime libero-professionale)

#### Funzione in un contesto di lavoro

Lo Specialista in ingegneria e scienze informatiche opera nella analisi, progettazione, pianificazione, sviluppo e gestione di componenti, sistemi e processi che richiedono elaborazione di informazione sia nel contesto della manifattura e dei servizi  sia nel contesto di comparti di ricerca e sviluppo industriale.

Tra le principali funzioni svolte si possono elencare le seguenti:
-	analizza problemi in cooperazione con esperti di dominio selezionando le metodologie, le tecnologie e gli standard utili alla documentazione e allo sviluppo di applicazioni, effettuando anche ricerche su standard tecnologici, normative, e brevetti
-	progetta e partecipa alla realizzazione di prodotti, processi e servizi informatici e presiede al collaudo e/o verifica delle proprietà di quanto realizzato 
-	gestisce le attività di  produzione di componenti, sistemi e servizi informatici  coordinando il lavoro di più persone anche attraverso l’uso di strumenti informatici custom ritagliati alle esigenze della specifica produzione
-	sviluppa nuove tecniche operative e strumenti di ausilio alla produzione, curandone i risvolti connessi ad una concreta applicazione 
-	promuove processi aziendali di innovazione tecnologica, fondati su risultati di attività sperimentali e di ricerca condotti anche collaborando a progetti in ambito nazionale e/o internazionale
Lo Specialista in ingegneria e scienze informatiche formato nella Laurea Magistrale è intrinsecamente rivolto all’auto-aggiornamento delle proprie conoscenze. Maggiori opportunità di crescita professionale, di specializzazione, di ampliamento delle competenze e delle responsabilità professionali in specifici settori dell’industria di processo potranno essere ottenute integrando la formazione attraverso master, dottorati e iniziative di formazione congiunte tra Università e imprese pubbliche e private.

#### Competenze associate alla funzione

Tra le principali competenze dello Specialista in ingegneria e scienze informatiche
possono essere elencate le seguenti:

•	approfondita conoscenza sulle moderne metodologie, tecnologie e infrastrutture per la progettazione e realizzazione di componenti, sistemi e servizi concentrati e/o distribuiti che richiedono elaborazione di informazione  unita a capacità di auto-apprendimento e di aggiornamento continuo
•	approfondita conoscenza sui processi di produzione del software, sulla costruzione di ambienti di sviluppo custom  unita a capacità comunicativo-relazionali ed organizzativo-gestionali
•	conoscenze nel campo dell'organizzazione aziendale e della gestione dei progetti
•	capacità di identificare, formulare e risolvere anche in modo innovativo, problemi complessi o che richiedono un approccio interdisciplinare
•	capacità di ideare, pianificare, progettare e gestire sistemi, processi e servizi complessi e/o innovativi;

#### Sbocchi occupazionali

•	industrie produttrici e/o utilizzatrici di componenti e sistemi informatici;
•	imprese e centri di servizio operanti nel settore dei sistemi informativi;
•	imprese fornitrici di strutture e servizi per sistemi e reti informatiche;
•	imprese fornitrici di servizi di Internet computing e infrastrutture Web;
•	società di ingegneria del software;
•	aziende operanti nel comparto dell'automazione industriale e della robotica;
•	industrie di processo dei comparti meccanico, elettrico, elettro-meccanico, energetico, chimico;
•	laboratori industriali di ricerca e sviluppo;
•	strutture tecniche della pubblica amministrazione che si avvalgono di infrastrutture informatiche per la gestione dei servizi sia interni che rivolti all'utenza;
•	enti di formazione;
•	centri di ricerca.

## Proseguire gli studi

Dà accesso agli studi di terzo ciclo (Dottorato di ricerca e Scuola di specializzazione) e master universitario di secondo livello.

### Archivio

- Sosteniamo il diritto alla conoscenza