# Offices will close on Friday 18 April 2025

On the occasion of the Easter Holidays

Published on
        17 April 2025

We will be closed on Friday, April 18, 2025.

Our offices will reopen on Tuesday, April 22, 2025.

- Support the right to knowledge