# News archive

### Call for the Italian curriculum A.Y. 25/26 Computer Science and Engineering is online!

You can now apply.

Published on
                            04 June 2025

### Bernardo Nobile Graduation Award

Deadline: 30 June

Published on
                            30 May 2025

### Valeria Solesin Award

Deadline: 31 July

Published on
                            30 May 2025

### International info session

Are you an international prospective student? Join our online sessions to get practical information about tuition fees, financial aid, and benefits available through ER-GO.

Published on
                            28 May 2025

### Call for Players 2025

Didn't get a chance to attend the event that concluded in April 2025? Don't worry — you can still help build a successful startup. Find out how.

Published on
                            13 May 2025

### Antonio Genovesi Thesis Award

The Ethical Finance Foundation announces a prize for theses on the various aspects of ethical finance. Deadline: 19 August.

Published on
                            13 May 2025

### “Ingenio al Femminile” Thesis Award

The National Council of Engineers announces a prize competition reserved for female engineers on the theme: "Artificial Intelligence for the New Challenges of 2050". Deadline: 30 June.

Published on
                            13 May 2025

### Una Europa Student Visual Art Contest 2025, Are you ready to showcase your creativity?

Join the  competition that give you the opportunity to express your talent through a piece that represents the theme of Alliance between universities. Deadline: 11 May.

Published on
                            28 April 2025

### Offices will close on Friday 18 April 2025

On the occasion of the Easter Holidays

Published on
                            17 April 2025

### European University Basketball Championships 2025

Join the Basket Heroes volunteer team and be a key player in the championships taking place place in Bologna from 6 to 13 July. Apply online!

Published on
                            29 March 2025

### Become a student community representative. Apply by 8 April

On 14 and 15 May, students will vote to elect their representatives to the University Governing Bodies. Step up and become the spokesperson for the needs and projects of our student community.

Published on
                            24 March 2025

### Collegio Superiore: the new call for admissions is online

Applications for the admission competition to the Collegio Superiore courses are open until 15 April. The call is dedicated to students enrolling in the first year of a 2nd Cycle Degree Programmes.

Published on
                            24 March 2025

- 1
- 2
- 3
- Next 12 items

- Support the right to knowledge