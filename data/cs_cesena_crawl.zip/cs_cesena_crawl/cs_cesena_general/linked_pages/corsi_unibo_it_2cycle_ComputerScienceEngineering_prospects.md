# Prospects

If you haven’t enrolled yet, please look at code 6699.
 If you have already enrolled, the course code is available in Studenti Online.

- Codice 6699
- Codice 8614

8614 - Computer Science and Engineering

## Professional profiles

### professional profile

This content is not currently available.

## Continuing to study

It gives access to third cycle studies (Dottorato di ricerca/Scuole di specializzazione) and master courses of second degree.

### Archive

- Support the right to knowledge