# Corsi a scelta

Attività per la scelta guidata degli insegnamenti nel secondo anno di corso.

Gli insegnamenti a scelta guidata che possono essere inseriti in piano al secondo anno del corso di studio, possono essere idealmente suddivisi in due profili differenti.

Chi volesse specializzarsi in uno dei campi, può fare riferimento alla presentazione dei profili. Non è comunque obbligatorio scegliere gli esami da uno solo dei due profili, ma si potranno anche scegliere esami sia dall'uno che dall'altro.

### Profilo "Data &amp; Knowledge Engineering"

Obiettivi

Il profilo studia la modellazione e gli algoritmi necessari alla costruzione e allo sfruttamento della conoscenza al servizio di applicazioni aziendali e scientifiche avanzate. Gli ambiti applicativi di riferimento sono quelli della Business Intelligence, del Semantic Web e dell'Internet-of-Things.

Figure professionali

- Data Scientist
- Progettista e consulente nel settore della Business Intelligence e degli Analytics
- Esperto delle tecnologie in ambito Big Data
- Project manager di progetti ad elevato contenuto tecnologico

Insegnamenti

- Big Data (in inglese)
- Business Intelligence
- Data Mining (in inglese)
- Project Management
- Operational Analytics (in inglese)
- Web Semantico

Esiste un accordo Erasmus specifico con l'Universidad Politecnica de Catalunya (Barcellona) in cui ha sede un master specializzato sulle tematiche proprie del profilo.

### Profilo "Software Systems Engineering"

Obiettivi

Il profilo affronta le tematiche di costruzione del software in sistemi informatici moderni e intelligenti, e in contesti distribuiti e autonomi: Internet-of-Things, Pervasive Computing, Smart City, con ottica Software Engineering ed AI.

Figure professionali

- Esperto di infrastrutture software informatiche e IoT
- Software architect
- Esperto di tecniche di intelligenza artificiale

Ci sono poi svariate possibilità di attività pre- e post-laurea all'estero

Insegnamenti

Software Architect

- Advanced Software Modelling and Design (in inglese)
- Software Architecture and Platforms (in inglese)
- Software Process Engineering (in Inglese)

Sistemi Intelligenti

- Intelligent Systems Engineering (in inglese)
- Intelligent Robotic Systems (in inglese)
- Visione Artificiale e Riconoscimento

- Sosteniamo il diritto alla conoscenza