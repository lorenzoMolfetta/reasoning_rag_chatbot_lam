# Programme

<!-- image -->

## Profile

- Overview
- What will you study during this Programme?
- Course Structure Diagram
- Programme aims
- Expected learning outcomes
- Prospects
- Faculty
- Curriculum: Intelligent Embedded Systems - EIT Digital track
- What our students are saying

<!-- image -->

## Organisation and quality assurance

- Degree Programme Director and Board
- Degree Programme Tutor
- Student representatives
- Guidance
- Student administration offices
- Classrooms, labs and libraries
- Degree Programme Quality Assurance System
- Quality Assurance Committee and other Committees
- Programme Quality: facts and figures
- Advisory Board
- Opinions ih the student community

### Regulations

- Degree Programme Regulations
- Student Regulations
- Programme overview on Universitaly

- Support the right to knowledge