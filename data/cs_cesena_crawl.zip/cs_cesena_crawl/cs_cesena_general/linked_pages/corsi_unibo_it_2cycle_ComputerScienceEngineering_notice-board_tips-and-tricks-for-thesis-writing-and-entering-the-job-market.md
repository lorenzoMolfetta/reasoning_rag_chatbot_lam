# Tips and tricks for thesis writing and entering the job market

From compiling your bibliography to acing your first interviews. Let’s talk about it online on 26 February.

Published on
        11 February 2025

As part of Virtual Fair – Master's programmes on 26 February, a series of events dedicated to those working on their thesis and those taking their first steps into the job market.

Check these events (in Italian only):

#### How to participate

The Virtual Fair will be held online. Participation is free, with compulsory registration.

You can register until 25 February.

- Support the right to knowledge