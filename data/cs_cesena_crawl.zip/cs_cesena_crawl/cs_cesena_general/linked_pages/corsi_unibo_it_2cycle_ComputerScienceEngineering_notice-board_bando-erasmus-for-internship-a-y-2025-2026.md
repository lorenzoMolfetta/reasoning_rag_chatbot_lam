# Bando Erasmus+ for Internship A.Y. 2025-2026

Meeting on Monday the 24th of March, 12.00 a.m. (Italian local time)

Published on
        18 March 2025

In accordance with the Delegates for Internationalization for the Degree Programmes in Engineering, Architecture and Sciences – Campus of Cesena, on Monday, 24th of March at 12:00, an informative meeting via Teams will take place. This meeting aims at providing students with details about how to apply to the Erasmus+ Mobility for Traineeship 2025/26 Call:

https://www.unibo.it/en/study/international-experiences/internship-abroad/erasmus-mobility-for-traineeship/erasmus-mobility-for-traineeships-what-is-it-and-how-to-apply/erasmus-mobility-for-traineeships-what-is-it-and-how-to-apply

The mobility program allows you to carry out an internship at a company or other organization in one of the European countries, or in some non-European countries participating into the Program, and it provides for the provision of a financial contribution to cover part of the expenses incurred by the students during the internship period.

Here below you can find the link to join the meeting on the date and time specified. Please connect by using your Unibo account: name.lastname@studio.unibo.it

This meeting will be held in the Italian language. Finally, we inform you that a similar meeting will be organized in English on the 25th of March at 12:00. For the meeting in English, a dedicated email with the link to participate will be sent to your @studio.unibo.it account on March 25th.

Microsoft Teams Serve aiuto?

Partecipa alla riunione ora

- Support the right to knowledge