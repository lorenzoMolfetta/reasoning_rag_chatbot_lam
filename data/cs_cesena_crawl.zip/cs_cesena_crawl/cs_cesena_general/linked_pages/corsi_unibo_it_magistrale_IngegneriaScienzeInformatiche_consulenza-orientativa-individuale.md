# STOP AND GO! Un confronto per ripartire!

Senti la necessità di uno spazio di ascolto e di confronto per riflettere sulla scelta del Corso di Laurea intrapreso?

L’orientamento in itinere ha l’obiettivo di sostenerti durante il tuo percorso formativo e di aiutarti a gestire le difficoltà che stai incontrando.

Prenota la tua consulenza individuale e gratuita, composta da uno o più colloqui della durata di circa un’ora condotti dai nostri esperti di orientamento (al momento da remoto tramite Skype o altri canali da concordare), scrivendoci a: orientamento.fc@unibo.it  e indicando nome cognome, recapito telefonico e corso di Laurea frequentato.

- Sosteniamo il diritto alla conoscenza