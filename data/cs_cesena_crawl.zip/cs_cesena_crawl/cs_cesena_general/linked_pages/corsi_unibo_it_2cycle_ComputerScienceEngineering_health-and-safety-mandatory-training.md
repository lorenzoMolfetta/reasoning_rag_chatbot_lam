# Health and Safety mandatory training

For your safety in study and research areas

## What it’s about

These are occupational health and safety training courses required by Italian Legislative Decree 81/2008. The training is compulsory and consists of:

- General Training: Module 1
- Specific Training - Low Risk: Module 2
- Specific Training - Medium Risk: Module 2 + Module 3
- Specific Training - High Risk: Module 2 + Module 3 + Module 4

## Who it’s for

All students who during their university career carry out internships, prepare their final dissertation, or participate in activities in any sort of laboratory.

After matriculation, you will be provided all the information required to take part in the training.

## Recognition of previous training

The University considers valid:

- General training(Module 1) carried out at the University of Bologna or another institution
- Specific training (Modules 2, 3, 4), only if you already had training at the University of Bologna, for the same category of risk and within the 5-year validity of the certificate. The University does not recognise specific health and safety training provided by other entities, schools and organisations.

To request recognition, verify validity, and - if applicable - obtain exoneration from an equivalent training module, please send your certificate to the address provided in the Contacts section.

## Modules established by the Course

## Module 1 - General Training

- Method: log in to the Virtual Platform using your university credentials (@studio.unibo.it).

- Duration: 4 hours
- Dates and times: always available online
- Language: english
- Final assessment test: multiple choice. You will be able to take the online test immediately after you complete the course. If you do not pass the test, you will have to wait 7 days before you can repeat the training
- Certification: after passing the test you can download the certificate – in Italian or English – by logging into Studenti Online and going to the “Certificates and Self-certifications” page.
- Validity: permanent
- Other information: the course is preparatory for Module 2 and for Modules 3 and 4, if required

## Module 2 – Specific training low risk

- Method : log in to the Virtual Platform using your university credentials (@studio.unibo.it).
- Duration: 4 hours
- Dates and times: always available online
- Language: english
- Final assessment test: multiple choice. You will be able to take the online test immediately after you complete the course. If you do not pass the test, you will have to wait 7 days before you can repeat the training
- Certification: after passing the test you can download the certificate – in Italian or English – by logging into Studenti Online and going to the “Certificates and Self-certifications” page.
- Validity: 5 years
- Other information: the course is preparatory for Modules 3 and 4, if required

Modules 3 e 4 are not necessary for this Programme

## Contacts

- To get recognition of previous training, send the certificate to: sicurezza.formazione@unibo.it;

- For information about registering for the Modules: campuscesena.didattica.isa@unibo

- Support the right to knowledge