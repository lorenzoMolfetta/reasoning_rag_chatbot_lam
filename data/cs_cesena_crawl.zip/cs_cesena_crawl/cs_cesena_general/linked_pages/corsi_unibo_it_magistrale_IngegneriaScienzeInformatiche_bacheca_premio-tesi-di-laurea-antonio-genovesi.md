# Premio tesi di Laurea Antonio Genovesi.

Guida La Fondazione Finanza Etica bandisce un premio per tesi in tema di finanza etica variamente declinata. Scadenza: 19 agosto.

Pubblicato il
        13 maggio 2025

### Per informazioni:

- Bando

- Sosteniamo il diritto alla conoscenza