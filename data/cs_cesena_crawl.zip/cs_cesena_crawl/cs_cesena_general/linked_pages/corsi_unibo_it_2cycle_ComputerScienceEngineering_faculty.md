# Faculty

<!-- image -->

## Gianluca Aguzzi

Adjunct professor

Go to the website

<!-- image -->

## Marco Antonio Boschetti

Full Professor

Go to the website

<!-- image -->

## Mario Bravetti

Full Professor

Go to the website

<!-- image -->

## Franco Callegati

Full Professor

Go to the website

<!-- image -->

## Antonella Carbonaro

Associate Professor

Go to the website

### Latest News

Al Campus di Cesena la finalissima e le premiazioni delle Olimpiadi di Problem Solving - edizione 2025

Published on 2025-04-15 10:58:32

<!-- image -->

## Walter Cerroni

Associate Professor

Go to the website

<!-- image -->

## Giovanni Ciatto

Junior assistant professor (fixed-term)

Go to the website

<!-- image -->

## Raffaele Corrado

Associate Professor

Go to the website

<!-- image -->

## Gabriele D'Angelo

Assistant professor

Go to the website

<!-- image -->

## Matteo Ferrara

Associate Professor

Go to the website

<!-- image -->

## Stefano Ferretti

Full Professor

Go to the website

### Latest News

Tesi di Laurea

Published on 2024-10-01 11:10:15

<!-- image -->

## Guido Fioretti

Associate Professor

Go to the website

### Latest News

Class exercise for Management Skills Lab

Published on 2024-11-29 10:10:47

<!-- image -->

## Matteo Francia

Junior assistant professor (fixed-term)

Go to the website

<!-- image -->

## Annalisa Franco

Associate Professor

Go to the website

<!-- image -->

## Enrico Gallinucci

Fixed-term Researcher in  Tenure Track L. 79/2022

Go to the website

<!-- image -->

## Roberto Girau

Senior assistant professor (fixed-term)

Go to the website

<!-- image -->

## Matteo Golfarelli

Full Professor

Go to the website

<!-- image -->

## Chiara Grasselli

Adjunct professor

Go to the website

<!-- image -->

## Davide Maltoni

Full Professor

Go to the website

<!-- image -->

## Vittorio Maniezzo

Full Professor

Go to the website

### Latest News

Matheuristics, Algorithms and Implementations

Published on 2021-03-02 09:52:31

<!-- image -->

## Andrea Melis

Junior assistant professor (fixed-term)

Go to the website

<!-- image -->

## Silvia Mirri

Full Professor

Go to the website

<!-- image -->

## Gianluca Moro

Associate Professor

Go to the website

### Latest News

Dow Jones Prediction and Trading with Deep learning

Published on 2018-06-02 03:41:16

<!-- image -->

## Timothy Sean Jr. O'Connell

Adjunct professor

Go to the website

<!-- image -->

## Andrea Omicini

Full Professor

Go to the website

<!-- image -->

## Rebecca Levy Orelli

Associate Professor

Go to the website

<!-- image -->

## Danilo Pianini

Senior assistant professor (fixed-term)

Go to the website

<!-- image -->

## Catia Prandi

Associate Professor

Go to the website

<!-- image -->

## Alessandro Ricci

Associate Professor

Go to the website

### Latest News

Esami -- Data via email

Published on 2024-08-30 20:48:02

<!-- image -->

## Stefano Rizzi

Full Professor

Go to the website

<!-- image -->

## Andrea Roli

Assistant professor

Go to the website

### Latest News

Intelligent Robotic Systems exams

Published on 2021-10-12 10:42:46

<!-- image -->

## Marco Tartagni

Full Professor

Go to the website

### Latest News

Tomorrow's lessons 18-10-2023 canceled

Published on 2023-10-17 13:00:30

Foto non disponibile

## Danai Charitini Vachtsevanou

Adjunct professor

Go to the website

<!-- image -->

## Mirko Viroli

Full Professor

Go to the website

The name you entered is not in the list.

- Support the right to knowledge