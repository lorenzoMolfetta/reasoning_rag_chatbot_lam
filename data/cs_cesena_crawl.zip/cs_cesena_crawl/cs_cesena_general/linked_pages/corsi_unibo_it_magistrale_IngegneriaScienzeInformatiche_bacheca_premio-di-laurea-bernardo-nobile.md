# Premio di laurea Bernardo Nobile

L’Area Science Park bandisce premi di laurea per valorizzare studi e metodologie relativi alla proprietà intellettuale e a tecnologie deep tech. Scadenza: 30 giugno.

Pubblicato il
        30 maggio 2025

### Per informazioni:

- Link:

- Sosteniamo il diritto alla conoscenza