# Insegnamenti: piano didattico

## Piani disponibili nell'A.A. 2025/2026

Guarda il piano didattico che ti interessa, in base all'anno in cui ti sei iscritto.

- Codice 6699
- Codice 8614

8614 - Ingegneria e scienze informatiche

### CURRICULUM Ingegneria e scienze informatiche

- Curriculum Ingegneria e Scienze Informatiche: per studenti immatricolati nell'a.a. 2024-25

### CURRICULUM INTELLIGENT EMBEDDED SYSTEMS

- Curriculum Intelligent Embedded Systems: per studenti immatricolati nell'a.a. 2024-25

### Vedi anche

- Corsi a scelta
Attività per la scelta guidata del secondo anno di corso.

- Sosteniamo il diritto alla conoscenza