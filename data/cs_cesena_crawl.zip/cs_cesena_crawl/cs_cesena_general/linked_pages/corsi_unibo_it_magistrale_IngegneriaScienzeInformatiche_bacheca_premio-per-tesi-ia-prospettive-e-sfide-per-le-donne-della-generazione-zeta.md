# Premio per tesi “IA prospettive e sfide per le donne della generazione zeta”

FIDAPA con BPW ITALY bandisce un premio per tesi per giovani donne in tema di IA, per favorire la crescita della cultura scientifica nella generazione zeta femminile. Scadenza 30 giugno.

Pubblicato il
        16 aprile 2025

### Per informazioni:

- Link:

- Sosteniamo il diritto alla conoscenza