# home page

<!-- image -->

## Dalle idee ai sistemi

Progettare, trasformare e innovare con l’informatica.

- Sede didattica

                                    
                                        Cesena
- Lingua

                                    
                                        Inglese, Italiano
- Classe di corso
                            
                            
                                LM-18 - INFORMATICA
LM-32 - INGEGNERIA INFORMATICA
- Coordina il corso


                                        Annalisa Franco
- Tipo di accesso

                                    
                                        Libero
- Internazionale

                                    
                                        Titolo doppio/multiplo
- Dipartimento

Informatica - Scienza e Ingegneria - DISI
- Gli indirizzi del corso (curricula)
    - INTELLIGENT EMBEDDED SYSTEMS
    - INGEGNERIA E SCIENZE INFORMATICHE
- Stato

                                
                                    L’attivazione del corso di studio è subordinata alla conclusione dell’iter ministeriale.

## Cosa ti serve oggi

- Orario delle lezioni
- Insegnamenti: piano didattico
- Appelli d'esame
- Elenco Docenti
- Verso il mondo del lavoro
- Metodo di studio

## Cosa devi sapere

News, eventi e memo per il tuo percorso di studi

### Pubblicato bando CV Italiano Ingegneria e scienze informatiche 25/26

Leggi attentamente il bando e segui i passi per l'iscrizione

### Premio di laurea Bernardo Nobile

L’Area Science Park bandisce premi di laurea per valorizzare studi e metodologie relativi alla proprietà intellettuale e a tecnologie deep tech. Scadenza: 30 giugno.

### Premio Valeria Solesin

Premio di laurea sul tema de “Il talento femminile come fattore determinante per lo sviluppo dell’economia, dell’etica e della meritocrazia nel nostro paese.” Scadenza: 31 luglio.

Mi interessa se: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando per il programma di mobilità internazionale TNE - Studio

Scadenza: 14 nov 2025

Mi interessa se: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di Concorso per n. 1 assegno di tutorato per la realizzazione di materiale didattico accessibile per studenti con disabilità e con DSA Sede di Bologna

Scadenza: 31 lug 2025, 13:00

Mi interessa se: Studio al primo anno, Studio dal secondo anno in poi, Ho una laurea

### Bando di concorso per n. 11 assegni di tutorato di Area medico - scientifica - tecnologica per attività a supporto degli studenti con disabilità e con DSA presso il Servizio per studenti con disabilità e con DSA sedi di Bologna e Campus della Romagna

Scadenza: 31 lug 2025, 13:00

<!-- image -->

## Summer e Winter School

Approfondisci i tuoi interessi e migliora le tue competenze, allarga i tuoi orizzonti con esperienze interdisciplinari e culturali.

Scopri i corsi

## Dai spazio a interessi e passioni

- Competenze trasversali

Aggiungi valore al tuo curriculum e facilita le tue relazioni, anche sul lavoro.
- Esperienze all'estero

Dai al tuo percorso universitario una dimensione internazionale, dallo studio al tirocinio.
- Sport e cultura

Opportunità e iniziative per arricchire il tuo tempo libero con esperienze sportive e culturali.
- Biblioteche e risorse digitali

Un patrimonio fatto di scienza, arte, storia a tua disposizione gratuitamente, anche online.

- Sosteniamo il diritto alla conoscenza