# Esplora il Corso

Il corso si distingue per il suo equilibrio tra teoria e pratica, integrando competenze ingegneristiche, scientifiche e applicative in un approccio dinamico, interdisciplinare e innovativo tra innovazione tecnologica, intelligenza artificiale, trasformazione digitale. Forte della connessione con il tessuto imprenditoriale locale, offre anche molteplici opportunità per esperienze internazionali.

Iscrizioni aperte

## In breve

- Sede didattica

                                  
                                      Cesena
- Lingua

                                  
                                      Inglese, Italiano
- Classe di corso
                          
                          
                              LM-18 - INFORMATICA
LM-32 - INGEGNERIA INFORMATICA
- Durata

                                  
                                      2 anni
- Internazionale

                                  
                                      Titolo doppio/multiplo

### Open day

Al momento non ci sono eventi in programma. Se hai bisogno di informazioni contatta il Tutor del corso

## Cosa studierai

Studierai tecnologie informatiche, progettazione software, e analisi dei dati, bilanciando teoria e pratica. Al secondo anno potrai approfondire temi avanzati nelle aree data &amp; knowledge engineering e software systems engineering, scegliendo tra vari insegnamenti e sviluppando competenze per lo sviluppo di sistemi complessi.

### Insegnamenti

Puoi scegliere tra i vari indirizzi del corso (i curricula) che prevedono insegnamenti e tematiche diverse:

- INTELLIGENT EMBEDDED SYSTEMS
- INGEGNERIA E SCIENZE INFORMATICHE

### Frequenza

Approfondisci nella 
                    pagina dedicata

## Profili professionali

Il corso offre diverse opportunità professionali, fornendoti le competenze per accedere a ruoli qualificati. Scopri i profili a cui potrai ambire:

- Specialista in ingegneria e scienze informatiche

## Esperienze all'estero

Il corso, oltre a forme di studio e tirocinio all’estero, offre diverse opportunità internazionali, tra cui il curriculum Intelligent Embedded Systems con EIT Digital, che combina competenze tecniche e gestionali. Potrai collaborare con università estere e aziende leader, sviluppando la tesi in progetti di ricerca internazionali.

### Internazionale

Titolo doppio/multiplo

## Iscrizioni, tasse ed esenzioni

## Quanto costa iscriversi

Studiare all'Università di Bologna è un obiettivo raggiungibile a prescindere dalla tua situazione economica. 
              
Simula l'importo indicativo che dovrai pagare inserendo il tuo valore ISEE.

              Consulta tutte le informazioni sulle Tasse ed esenzioni: importi e scadenze.

### Tipologia di accesso

Libero
                    
                    

                  Per accedere al corso segui i passi che trovi nella pagina dedicata

## 5 motivi per iscriverti al corso

1. Formazione multidisciplinare: integra conoscenze ingegneristiche, scientifiche e applicative per una preparazione completa e versatile.
2. Puoi scegliere il curriculum Intelligent Embedded Systems, in inglese e con EIT Digital, per una formazione avanzata e internazionale.
3. Esperienza al Campus di Cesena: studia in un ambiente moderno e dinamico, con laboratori avanzati e una comunità studentesca attiva.
4. Equilibrio tra teoria e pratica: affronta progetti concreti e attività di laboratorio, combinando modelli teorici e tecnologie applicative.
5. Elevata soddisfazione e occupabilità: il 98% di chi si laurea è soddisfatto e il tasso di occupazione a un anno dalla laurea è vicino al 100%.

## I numeri del corso

Alcuni dati sul corso: visita la pagina completa per approfondire e scoprire le opinioni di chi lo frequenta.

- 28%
        Studenti internazionali e fuori regione
- 42%
        Laureati in corso
- 24%
        Laureati con una esperienza all'estero
- 98%
        Laureati soddisfatti degli studi svolti
- 92%
        Laureati che lavorano
- 8%
        Laureati che non lavorano ma studiano o non cercano
- 0%
          Laureati che non lavorano e cercano

## Le esperienze di chi vive il corso

- Presentazione del corso







Guarda su YouTube

## Ricevi aggiornamenti sul corso

- Sosteniamo il diritto alla conoscenza