# Student representatives

Student representatives sit on the Degree Programme Board. The procedures for their election and the duration of their mandate are set by the University regulations.

At present, there aren't any representatives for this Degree Programme.

- Support the right to knowledge