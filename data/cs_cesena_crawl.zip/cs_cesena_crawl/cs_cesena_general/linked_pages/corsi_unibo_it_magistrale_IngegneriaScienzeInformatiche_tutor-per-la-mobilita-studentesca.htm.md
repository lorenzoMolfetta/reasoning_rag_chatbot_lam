# Tutor per la mobilità studentesca

Per informazioni è possibile fare riferimento al tutor dedicato.

Il tutor per la mobilità studentesca svolge attività di informazione e assistenza agli studenti in ingresso e in uscita nell’ambito di programmi di scambio internazionali dei corsi di studio. Riceverà gli studenti, previo appuntamento scrivendo alla mail giulio.donati6@unibo.it

Nominativo del tutor: Giulio Donati

Recapito e-mail:  ingarc.vpce.internazionalizzazionecesena@unibo.it

- Sosteniamo il diritto alla conoscenza