# Academic Calendar

Lecture and exam periods of the Master's Degree in Computer Science and Engineering

## ACADEMIC CALENDAR 2024/2025

### Lecture periods

1st cycle: from 18/09/2024 to 18/12/2024.
Closing dates and holidays: 01/11/2024 (All Saints holiday).

2nd cycle: from 17/02/2025 to 10/06/2025.
Closing dates and holidays: Easter holidays from 17/04/2025 to 22/04/2025 (included), 23-24/04/2025 (long weekend), 25/04/2025 (Italian Liberation Day), 01/05/2025 (International Workers' Day), 02/05/2025 (long weekend), 02/06/2025 (Italian Republic Day).

### Exam sessions

1st session: from 19/12/2024 to 14/02/2025.
2nd session: from 11/06/2025 to the beginning of the new 2025/2026 first lecture period (September 2025).

According to the guidelines that the Degree Programme established concerning the organisation of the exam calendar:

- Students won't have exams of the same year on the same day, whenever possible.

- Exams won't take place during the lessons' periods, in order to allow all students to attend them.

- Professors will organise the exam calendar with sufficient notice. They will check room availabilities before fixing the dates by getting in touch with the Teaching Services office.

- Professors will fix at least two exam dates during the exam period that occurs just after the end of the classes for their teaching unit. They will fix at least one exam date for all the other exam periods.

## ACADEMIC CALENDAR 2025/2026

### Lecture periods

1st cycle: from 17/09/2025 to 19/12/2025.
Closing dates and holidays: 08/12/2025 (Immaculate Conception).

2nd cycle: from 16/02/2026 to 05/06/2026.
Closing dates and holidays: Easter holidays from 02/04/2026 to 08/04/2026 (included), 01/05/2026 (International Workers' Day), 01/06/2026 (long weekend), 02/06/2026 (Italian Republic Day).

### Exam sessions

1st session: from 22/12/2025 to 13/02/2026 (excluding 24/12/2025)
2nd session: from 08/06/2026 to 11/09/2026

According to the guidelines that the Degree Programme established concerning the organisation of the exam calendar:

- Students won't have exams of the same year on the same day, whenever possible.

- Exams won't take place during the lessons' periods, in order to allow all students to attend them.

- Professors will organise the exam calendar with sufficient notice. They will check room availabilities before fixing the dates by getting in touch with the Teaching Services office.

- Professors will fix at least two exam dates during the exam period that occurs just after the end of the classes for their teaching unit. They will fix at least one exam date for all the other exam periods.

- Support the right to knowledge