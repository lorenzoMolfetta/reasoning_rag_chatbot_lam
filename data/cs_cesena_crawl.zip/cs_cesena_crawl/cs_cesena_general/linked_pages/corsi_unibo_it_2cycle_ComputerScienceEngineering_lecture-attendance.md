# Lecture attendance

Lecture attendance is not compulsory but is strongly recommended. 
Many students find that attending lectures regularly is the easiest and quickest way of completing the degree programme.

If you are enrolled in the first year, get off on the right foot! University marks a big change in the way you study and are assessed. Getting the right pace is important to avoid finding that you have already fallen behind in the acquisition of your education credits (CFUs) at the end of the first year.

Here are a few good reasons to attend lectures:

1. A teacher's guidance and support is essential to enrich and complete the learning process. Learning is not about studying passively, but about unleashing your potential through interaction.
2. During the entire education process, you grow and improve and develop your projects by comparing and discussing with other people. You will have the opportunity to collaborate with the other students in your degree programme, organise study groups, exchange notes on the various disciplines, share experiences and strategies to prepare for exams. A precious opportunity worth experiencing.
3. While you are in class, you are studying; therefore, you are constantly learning without skipping a beat!
4. It is essential to take active part in all practical disciplines, such as laboratory work and internships.

If you are a working student, read the information about how to extend your study period (flexible curriculum)

### Contacts

#### Teaching Service

How can we help you:
                    Indications on your student career status and credit recognition if you transfer from another university or change your degree programme

E-mail
campuscesena.didattica.isa@unibo.it

Phone
+39 0547338300
Orario telefonico

Other information
You can contact us via e-mail and MsTeams. You can write an email to get further information or to book a call on Teams: you will receive an e-mail with the day, time and link to connect, after you have downloaded the app.

- Support the right to knowledge