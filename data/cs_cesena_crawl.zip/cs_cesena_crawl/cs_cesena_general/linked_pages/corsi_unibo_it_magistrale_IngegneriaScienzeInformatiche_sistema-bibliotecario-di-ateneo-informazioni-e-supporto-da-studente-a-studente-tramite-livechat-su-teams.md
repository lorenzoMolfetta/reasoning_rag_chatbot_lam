# Sistema Bibliotecario di Ateneo - Informazioni e supporto da studente a studente tramite LiveChat su Teams

Il servizio, rivolto agli studenti italiani e internazionali, è finalizzato all'aiuto nella ricerca delle informazioni e del materiale utile alla preparazione degli esami e alla stesura della tesi.

### Per informazioni:

- Sistema Bibliotecario di Ateneo - Informazioni e supporto da studente a studente tramite LiveChat su Teams

- Sosteniamo il diritto alla conoscenza