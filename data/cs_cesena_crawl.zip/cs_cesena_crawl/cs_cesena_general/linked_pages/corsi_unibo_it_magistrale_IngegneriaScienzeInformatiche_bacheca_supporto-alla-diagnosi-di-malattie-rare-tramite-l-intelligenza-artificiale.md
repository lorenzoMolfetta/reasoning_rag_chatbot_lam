# “Supporto alla diagnosi di malattie rare tramite l’intelligenza artificiale”

Il Laboratorio di Data Engineering (LADE) bandisce 6 borse per studi in tema di supporto alla diagnosi di malattie rare tramite l’IA. Scadenza 16 marzo.

Pubblicato il
        12 marzo 2025

### Per informazioni:

- Link:

- Sosteniamo il diritto alla conoscenza