# Iscriversi

<!-- image -->

## Ammissione

- Iscriversi al Corso: requisiti, tempi e modalità
- Iscriversi ad anni successivi al primo

<!-- image -->

## Orientamento

- Tutor del Corso
- Servizi di orientamento
- Frequenza delle lezioni
- Servizi per gli studenti con disabilità e con DSA
- Come iscriverti a un corso se vieni da un Paese non-UE

### Come fare per

- Trasferirsi da un altro Ateneo
- Credenziali istituzionali e accesso ai servizi online
- Passaggio (opzione) al Corso di Nuovo Ordinamento
- Riconoscimento dei titoli esteri
- Lasciare e riprendere gli studi
- Iscriversi agli anni successivi al primo
- Prolungare la durata degli studi - Studente a tempo parziale
- Ottenere lo status di studente-atleta
- Attivare una carriera alias
- Iscriversi a singole attività formative
- Conciliare studio e lavoro
- Riconoscimento crediti

- Sosteniamo il diritto alla conoscenza