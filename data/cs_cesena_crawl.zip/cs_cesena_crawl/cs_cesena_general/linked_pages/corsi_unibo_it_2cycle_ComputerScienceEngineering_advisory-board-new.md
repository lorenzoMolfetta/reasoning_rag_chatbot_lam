# Advisory Board

The Advisory Board has been established to maintain ongoing contact with the worlds of industry, services, and the professions, in order to gather feedback and guidance on the degree programme’s educational goals. It meets at least once a year.
It is composed of individuals from business, the third sector, the professions, public and private institutions involved in education and research, and civil society, who can offer meaningful contributions to the teaching and research activities relevant to the degree programme.
At least one faculty member of the Quality Assurance Committee is also part of the Advisory Board.

### 

- Support the right to knowledge