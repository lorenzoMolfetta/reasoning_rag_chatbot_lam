# Bernardo Nobile Graduation Award

Deadline: 30 June

Published on
        30 May 2025

Area Science Park is offering graduation awards to promote studies and methodologies related to intellectual property and deep tech technologies.

https://www.areasciencepark.it/call/premionobile/?\_cldee=R3x2BFUNR04MQgAyMbSfNVwiJl5bxJraYM2naUQxsx0hKAtA0EuSBhUlKVj32eEH&amp;recipientid=contact-23dcbc8d6658ed119562002248999e98-4f476cf2e90143e58eb60a2a59c38464&amp;esid=69e83538-3332-f011-8c4d-6045bddfa3d2

- Support the right to knowledge