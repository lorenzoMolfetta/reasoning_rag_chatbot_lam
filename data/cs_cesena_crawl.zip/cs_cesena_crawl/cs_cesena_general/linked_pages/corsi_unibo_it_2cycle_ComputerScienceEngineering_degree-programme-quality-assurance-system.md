# Degree Programme Quality Assurance System

The Degree Programme, in line with the measures taken by the University to guarantee the quality of its teaching activities and structures, is constantly improved by interacting directly with students and representatives from the professional world.
 Areas of intervention include:

- defining programmes and resource planning;
- organising teaching activities and services;
- collecting data and information obtained thanks to interactions with students and representatives from the professional world;
- monitoring the efficacy of the programme and planning education and service improvement interventions.

The Degree Programme website offers comprehensive, up-to-date information on the educational project (professional profiles developed, expected learning outcome, teaching activities), resources used, teaching services provided and results achieved.

- Support the right to knowledge