# Call for the Italian curriculum A.Y. 25/26 Computer Science and Engineering is online!

You can now apply.

Published on
        04 June 2025

Please find the call here:

https://corsi.unibo.it/magistrale/IngegneriaScienzeInformatiche/iscriversi-al-corso

(Please check boxes at the end of the page)

- Support the right to knowledge