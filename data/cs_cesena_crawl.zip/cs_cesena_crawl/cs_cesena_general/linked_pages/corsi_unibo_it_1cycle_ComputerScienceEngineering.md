# home page

<!-- image -->

## Designing the Digital Age

Skills to design and develop software systems and applications for the digital infrastructures of the present and future.

Find out more on the Italian version of the site

- Place of teaching

                                    
                                        Cesena
- Language

                                    
                                        Italian
- Degree Programme Class
                            
                            
                                L-8 R - 
L-31 R -
- Degree Programme Director


                                        Franco Callegati
- Type of access

                                    
                                        Restricted access - entrance exam - TOLC-I
- Department

Computer Science and Engineering - DISI
- Learning activities

Course structure diagram
- State

                                
                                    Programme will run only following the completion of the established ministerial procedure.

- Support the right to knowledge