# Mobilità internazionale

Informazioni e supporto amministrativo agli studenti outgoing e incoming

L’ufficio relazioni internazionali di Campus fornisce informazione e supporto amministrativo agli studenti outgoing per quanto riguarda i Programmi di scambio (Erasmus+Studio, Erasmus+Tirocinio, Overseas e altre opportunità) e agli studenti incoming per quanto riguarda le opportunità di studio e tirocinio presso i Corsi di studio afferenti Campus di Cesena.

L'Ufficio per la mobilità internazionale del Corso di Laurea Magistrale in Ingegneria e Scienze Informatiche segue gli studenti durante l'iter di presentazione, approvazione, modifica e riconoscimento dei Learning Agreement, monitorando l'intero stato di avanzamento della pratica.

Per informazioni più specifiche contatta il Tutor per la mobilità studentesca

### vedi anche

- Studiare all'estero
- Tirocini all’estero

### allegati

- Riunione presentazione bando\_1718.pdf

[
          .pdf
          1253Kb
          ]
- Slides\_RiunioneOverseas.pdf

[
          .pdf
          762Kb
          ]
- Guida\_vincitori\_Extra UE\_Erasmus17\_18.pdf

[
          .pdf
          496Kb
          ]

- Sosteniamo il diritto alla conoscenza