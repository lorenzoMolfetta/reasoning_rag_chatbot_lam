# Incontra il corso alla Giornata dell'Orientamento online 2025

Potrai incontrare tutte le lauree magistrali dell'Università di Bologna.

26 febbraio 2025 dalle 10:00 alle 17:00

Ms Teams -
                  Online

L’occasione giusta per conoscere attraverso l’esperienza. Durante l’evento potrai:

- conoscere i 142 Corsi di laurea
- incontrare studenti e studentesse del corso
- saperne di più sulle iscrizioni o sul lavoro che potrai fare
- assistere magari a una vera lezione per conoscere da vicino le discipline che studierai
- conoscere i servizi che ti supporteranno nel tuo percorso e le opportunità che renderanno unica la tua esperienza universitaria

Iscriviti online ed entra in anteprima per consultare il programma e scegliere gli appuntamenti a cui partecipare.

- Sosteniamo il diritto alla conoscenza