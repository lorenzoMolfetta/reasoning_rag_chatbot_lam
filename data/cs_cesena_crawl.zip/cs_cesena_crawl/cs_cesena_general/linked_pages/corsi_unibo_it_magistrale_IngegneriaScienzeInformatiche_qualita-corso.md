# Qualità: il Corso in cifre

Il Corso pubblica dati statistici sulle proprie caratteristiche e risultati in linea con il principio di trasparenza e le azioni dell'Ateneo per garantire la qualità della didattica e dei servizi offerti.

I dati presentati sono relativi all'ultimo triennio. Quando è indicata la "coorte", ci si riferisce al gruppo di studenti che ha iniziato la propria carriera universitaria in un dato anno. In questo caso non sono inclusi nel dato gli studenti trasferiti da altro Corso, né gli iscritti ad una seconda laurea.

 Alcuni anni di riferimento o alcuni ambiti di informazione possono mancare se il Corso non ha ancora completato il ciclo utile per monitorare i relativi dati.

Dati aggiornati al 18 giugno 2024

## Accesso al corso

### Numero degli iscritti

#### A.A. 2023-2024

- primo anno

75
- altri anni

68
- fuori corso

62

#### A.A. 2022-2023

- primo anno

71
- altri anni

78
- fuori corso

67

#### A.A. 2021-2022

- primo anno

83
- altri anni

79
- fuori corso

55

### Studentesse e studenti

- Studentesse 15.1%
- Studenti 84.9%

- Studentesse 10.4%
- Studenti 89.6%

- Studentesse 15.6%
- Studenti 84.4%

### Attrattività del corso

#### Coorte 2023/2024

- Residenti in altre regioni italiane
19.2%
- Residenti all'estero
4.1%

#### Coorte 2022/2023

- Residenti in altre regioni italiane
26.9%
- Residenti all'estero
3%

#### Coorte 2021/2022

- Residenti in altre regioni italiane
27.3%
- Residenti all'estero
3.9%

### Titolo presentato per l'accesso

- Laurea conseguita in Ateneo di Bologna
                                                            84.9%
- Laurea conseguita in altro Ateneo (anche estero)
                                                            15.1%

- Laurea conseguita in Ateneo di Bologna
                                                            85.1%
- Laurea conseguita in altro Ateneo (anche estero)
                                                            14.9%

- Laurea conseguita in Ateneo di Bologna
                                                            83.1%
- Laurea conseguita in altro Ateneo (anche estero)
                                                            16.9%

## Regolarità degli studi

### Prosecuzione degli studi tra primo e secondo anno

#### Coorte 2022/2023

- Abbandonano gli studi
13.4%
- Passano ad altro Corso
0%

#### Coorte 2021/2022

- Abbandonano gli studi
14.3%
- Passano ad altro Corso
0%

#### Coorte 2020/2021

- Abbandonano gli studi
8.2%
- Passano ad altro Corso
0%

Il dato "Abbandonano gli studi" comprende chi non si iscrive all'anno successivo e chi rinuncia agli studi. Il dato "Passano ad altro Corso" comprende chi si trasferisce ad altro ateneo e chi sceglie un altro Corso dell'Università di Bologna.

### Esami e voto medio conseguito

Consulta i
                            dati sugli insegnamenti del Corso relativi all'anno precedente.

### Laureati

#### Coorte 2021/2022

- Laureati in corso
41.6%

#### Coorte 2020/2021

- Laureati in corso
30.1%

#### Coorte 2019/2020

- Laureati in corso
29.3%

## Esperienze all'estero

### Partecipanti ai programmi di mobilità internazionale

- A.A. 2023-2024

12
- A.A. 2022-2023

12
- A.A. 2021-2022

9

### Laureati con una esperienza all'estero

- Anno 2023

23.7%
- Anno 2022

13.2%
- Anno 2021

8.2%

## Opinioni sul corso

### Cosa dicono gli studenti

Consulta i dati più recenti sulle opinioni degli studenti.

### Soddisfazione dei laureati

#### Anno 2023

- 97.7%
Per questo corso
- 90.6%
Per corsi della stessa classe - Italia

Laureati soddisfatti

#### Anno 2022

- 94.3%
Per questo corso
- 90.3%
Per corsi della stessa classe - Italia

Laureati soddisfatti

#### Anno 2021

- 93%
Per questo corso
- 92.3%
Per corsi della stessa classe - Italia

Laureati soddisfatti

- Per questo corso
- Per corsi della stessa classe - Italia

Consulta i dati dell'indagine AlmaLaurea

## Condizione occupazionale e formativa ad un anno dalla laurea

- 92.3%
Per questo corso
- 90%
Per corsi della stessa classe - Italia

Lavora

- 0%
Per questo corso
- 4.5%
Per corsi della stessa classe - Italia

Non lavora e cerca lavoro

- 7.7%
Per questo corso
- 5.5%
Per corsi della stessa classe - Italia

Non lavora e non cerca lavoro

- 87.8%
Per questo corso
- 92.5%
Per corsi della stessa classe - Italia

Lavora

- 2.4%
Per questo corso
- 2.2%
Per corsi della stessa classe - Italia

Non lavora e cerca lavoro

- 9.8%
Per questo corso
- 5.3%
Per corsi della stessa classe - Italia

Non lavora e non cerca lavoro

- 87.9%
Per questo corso
- 76.2%
Per corsi della stessa classe - Italia

Lavora

- 6.1%
Per questo corso
- 5.1%
Per corsi della stessa classe - Italia

Non lavora e cerca lavoro

- 6.1%
Per questo corso
- 18.7%
Per corsi della stessa classe - Italia

Non lavora e non cerca lavoro

- Per questo corso
- Per corsi della stessa classe - Italia

Consulta i dati dell'indagine AlmaLaurea

- Sosteniamo il diritto alla conoscenza