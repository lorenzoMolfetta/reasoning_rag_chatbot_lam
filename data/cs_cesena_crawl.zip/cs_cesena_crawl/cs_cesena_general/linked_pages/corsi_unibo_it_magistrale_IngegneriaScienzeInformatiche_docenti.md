# Docenti

<!-- image -->

## Gianluca Aguzzi

Professore a contratto

Vai al sito del docente

<!-- image -->

## Marco Antonio Boschetti

Professore ordinario

Vai al sito del docente

<!-- image -->

## Mario Bravetti

Professore ordinario

Vai al sito del docente

<!-- image -->

## Franco Callegati

Professore ordinario

Vai al sito del docente

<!-- image -->

## Antonella Carbonaro

Professoressa associata confermata

Vai al sito del docente

### Ultimo avviso

Al Campus di Cesena la finalissima e le premiazioni delle Olimpiadi di Problem Solving - edizione 2025

Pubblicato il 2025-04-15 10:58:32

<!-- image -->

## Walter Cerroni

Professore associato

Vai al sito del docente

<!-- image -->

## Giovanni Ciatto

Ricercatore a tempo determinato tipo a) (junior)

Vai al sito del docente

<!-- image -->

## Raffaele Corrado

Professore associato confermato

Vai al sito del docente

<!-- image -->

## Gabriele D'Angelo

Ricercatore confermato

Vai al sito del docente

<!-- image -->

## Matteo Ferrara

Professore associato

Vai al sito del docente

<!-- image -->

## Stefano Ferretti

Professore ordinario

Vai al sito del docente

### Ultimo avviso

Tesi di Laurea

Pubblicato il 2024-10-01 11:10:15

<!-- image -->

## Guido Fioretti

Professore associato

Vai al sito del docente

### Ultimo avviso

Class exercise for Management Skills Lab

Pubblicato il 2024-11-29 10:10:47

<!-- image -->

## Matteo Francia

Ricercatore a tempo determinato tipo a) (junior)

Vai al sito del docente

<!-- image -->

## Annalisa Franco

Professoressa associata

Vai al sito del docente

<!-- image -->

## Enrico Gallinucci

Ricercatore in Tenure Track L. 79/2022

Vai al sito del docente

<!-- image -->

## Roberto Girau

Ricercatore a tempo determinato tipo b) (senior)

Vai al sito del docente

<!-- image -->

## Matteo Golfarelli

Professore ordinario

Vai al sito del docente

<!-- image -->

## Chiara Grasselli

Professoressa a contratto

Vai al sito del docente

<!-- image -->

## Davide Maltoni

Professore ordinario

Vai al sito del docente

<!-- image -->

## Vittorio Maniezzo

Professore ordinario

Vai al sito del docente

### Ultimo avviso

Matheuristics, Algorithms and Implementations

Pubblicato il 2021-03-02 09:52:31

<!-- image -->

## Andrea Melis

Ricercatore a tempo determinato tipo a) (junior)

Vai al sito del docente

<!-- image -->

## Silvia Mirri

Professoressa ordinaria

Vai al sito del docente

<!-- image -->

## Gianluca Moro

Professore associato

Vai al sito del docente

### Ultimo avviso

Dow Jones Prediction and Trading with Deep learning

Pubblicato il 2018-06-02 03:41:16

<!-- image -->

## Timothy Sean Jr. O'Connell

Professore a contratto

Vai al sito del docente

<!-- image -->

## Andrea Omicini

Professore ordinario

Vai al sito del docente

<!-- image -->

## Rebecca Levy Orelli

Professoressa associata

Vai al sito del docente

<!-- image -->

## Danilo Pianini

Ricercatore a tempo determinato tipo b) (senior)

Vai al sito del docente

<!-- image -->

## Catia Prandi

Professoressa associata

Vai al sito del docente

<!-- image -->

## Alessandro Ricci

Professore associato

Vai al sito del docente

### Ultimo avviso

Esami -- Data via email

Pubblicato il 2024-08-30 20:48:02

<!-- image -->

## Stefano Rizzi

Professore ordinario

Vai al sito del docente

<!-- image -->

## Andrea Roli

Ricercatore confermato

Vai al sito del docente

### Ultimo avviso

Intelligent Robotic Systems exams

Pubblicato il 2021-10-12 10:42:46

<!-- image -->

## Marco Tartagni

Professore ordinario

Vai al sito del docente

### Ultimo avviso

Tomorrow's lessons 18-10-2023 canceled

Pubblicato il 2023-10-17 13:00:30

Foto non disponibile

## Danai Charitini Vachtsevanou

Professoressa a contratto

Vai al sito del docente

<!-- image -->

## Mirko Viroli

Professore ordinario

Vai al sito del docente

Il nome inserito non è presente nell'elenco.

- Sosteniamo il diritto alla conoscenza