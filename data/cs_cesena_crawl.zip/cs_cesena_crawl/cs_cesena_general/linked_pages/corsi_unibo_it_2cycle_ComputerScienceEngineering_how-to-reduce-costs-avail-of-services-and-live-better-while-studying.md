# How to reduce costs, avail of services and live better while studying

## Find out how to reduce university costs

<!-- image -->

## Discover the main services that can accompany you throughout your university journey

<!-- image -->

## Find out how to make the most of your university career

<!-- image -->

- Support the right to knowledge