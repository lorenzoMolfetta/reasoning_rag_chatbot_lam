# Premio Gianni Bassi

Per laureati triennali università di Bologna. Scadenza 31 maggio 2025

Pubblicato il
        20 febbraio 2025

### Per informazioni:

- Per informazioni:

### Bando

- Bando

[
          .pdf
          231Kb
          ]

- Sosteniamo il diritto alla conoscenza