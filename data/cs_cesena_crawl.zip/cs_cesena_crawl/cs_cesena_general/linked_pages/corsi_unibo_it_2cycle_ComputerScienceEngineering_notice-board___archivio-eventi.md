# Events archive

23 May

### StartUp Day 2025

09:15 - 20:30

DUMBO, Via Camillo Casarini 19 Bologna

Are you passionate about innovation? Meet those who turned a simple idea into a real opportunity. Register online.

12 May

### Job Day

09:30 - 15:00

Imola - Aula Magna di Palazzo Vespignani

On 9 May in Imola branch, meet local organizations and companies to discover internship and/or job placement opportunities.

10 Apr

### Jornada de Puertas Abiertas Virtual

21:30 - 23:00

Online

¿Eres un estudiante latino-americano y te interesa estudiar en Italia? El 10 de abril, descubre lo que significa estudiar y vivir en Unibo. Inscríbete y participa

08 Apr

### Career Day - Job networking event

All day

Padiglione 33 di BolognaFiere - Bologna

Meet companies and test your approach to the job market. Sign up now!

02 Apr

### Call for Players

All day

Online

Join the event to discover the entrepreneurial projects selected by "Call for Startup 2024/25," engage with their creators, and become part of an entrepreneurial team.

26 Feb

### If you haven't done it yet, register now to our Virtual Fair-Master's programmes! The event preview opens today

10:00 - 17:00

Ms Teams -
                  Online

You can start visiting the virtual stands and check the programme of the events you are interested in.

26 Feb

### PhD programmes: pathways, tools, and opportunities

10:30 - 11:30

Ms Teams -
                  Online

The online event to explore this opportunity to enhance your education and embark on a research journey. Th event will be held in Italian.

- Support the right to knowledge