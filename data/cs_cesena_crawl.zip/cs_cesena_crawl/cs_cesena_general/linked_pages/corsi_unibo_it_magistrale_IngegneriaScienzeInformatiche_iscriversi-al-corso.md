# Iscriversi al Corso: requisiti, tempi e modalità

## I passi principali da seguire

1. Requisiti

Verifica cosa serve per accedere.
2. Verifica adeguatezza della preparazione

Candidati per la valutazione da parte della Commissione.
3. Immatricolazione

Completa la tua iscrizione.

## Requisiti

- Titolo di studio richiesto



Titolo conseguito in Italia
Il corso prevede due percorsi di studi: “Curriculum Ingegneria e Scienze informatiche” in italiano e “Curriculum Intelligent Embedded Systems” in inglese.
Il Curriculum in inglese è suddiviso in percorso EIT e percorso locale (local track).
Per essere ammessi al corso di laurea magistrale in Ingegneria e Scienze Informatiche, a prescindere dal curriculum che si vuol scegliere, occorre essere in possesso di una laurea, di un diploma universitario di durata triennale.
Occorre, altresì, il possesso di requisiti curriculari:
Avere conseguito la laurea in una delle seguenti classi 
-L-8 – Ingegneria dell'informazione
-L-31 – Scienze e tecnologie informatiche,


L'ammissione al corso di laurea magistrale è subordinata, inoltre, al superamento di una verifica dell’adeguatezza della personale preparazione che avverrà secondo le modalità definite nel punto modalità di ammissione.
Titolo conseguito all’estero
 Per accedere al corso di laurea è necessario aver ottenuto un titolo di studio 
conseguito all’estero, riconosciuto idoneo.

Non ho un titolo di studio tra quelli richiesti
Se si è possesso di una laurea appartenente ad una classe differente da quelle indicate, è necessario avere acquisito:
- almeno 42 CFU complessivi nei settori INF/01 e ING-INF/05, MAT/01 a MAT/09, FIS/01, FIS/02e FIS/03, di cui almeno 18 sono di INF/01 e ING-INF/05.
Non ho ancora la laurea
Puoi partecipare alla prova, alla procedura di selezione e perfezionare l'immatricolazione. Se, però, non conseguirai la laurea entro il 31 dicembre 2025, l'immatricolazione verrà annullata.
- Conoscenza della lingua inglese



Per iscriverti al Curriculum Ingegneria e Scienze informatiche (in italiano)
La conoscenza della lingua inglese non è richiesta come requisito per l’iscrizione tuttavia durante il tuo percorso di studi dovrai sostenere l'idoneità di livello B2.
Per iscriverti al Curriculum Intelligent Embedded Systems (in inglese)
Il livello di conoscenza della lingua inglese richiesto per iscriverti a questo curriculum è pari ad almeno B2 (CEFR) accertato tramite certificato di idoneità oppure tramite un test di valutazione.
- Conoscenza della lingua italiana Valido solo per il curriculum Ingegneria e Scienze Informatiche (in italiano) Per accedere al corso devi soddisfare il requisito di conoscenza della lingua italiana e puoi farlo in due modi: Per maggiori dettagli e scadenze

### Conoscenza della lingua italiana

Valido solo per il curriculum Ingegneria e Scienze Informatiche (in italiano)

Per accedere al corso devi soddisfare il requisito di conoscenza della lingua italiana e puoi farlo in due modi:

- superando una prova di lingua italiana organizzata dall’Università di Bologna;
- presentando un valido certificato di conoscenza della lingua italiana o un titolo di scuola superiore ottenuto in lingua italiana. Se presenti un certificato o un titolo di studio in lingua italiana verifica anche se devi concorrere con i cittadini italiani e UE.

Per maggiori dettagli e scadenze

## Per cominciare

- Borse di studio, esoneri e incentivi



Puoi contare su sostegni economici già all'inizio del tuo percorso. In base alla tua situazione economica, al merito o a determinati requisiti puoi far domanda per ottenere una riduzione o un esonero sulla tassa di iscrizione.
Scopri le opportunità
- Tasse e importi



L'importo delle tasse è calcolato in base all’attestazione ISEE 2025 per prestazioni agevolate di diritto allo studio. È previsto l’esonero totale per le matricole con ISEE basso.
L'attestazione ISEE deve essere inserita entro il 30 ottobre 2025 ore 18:00 (o entro il 17 novembre 2025 ore 18:00 con una mora di 100 €) accedendo ai Servizi online di ER.GO, altrimenti dovrai versare l'importo massimo.
Se non puoi ottenere l'ISEE, verifica come viene calcolato l'importo delle tasse a seconda del Paese da cui provieni e da dove la tua famiglia ha redditi e patrimoni.
Consulta tutte le informazioni su Tasse ed esoneri

Ricordati
Di preparare i documenti e presentare le domande per borse di studio e altre  agevolazioni. In base alla tua condizione economica, puoi ottenere borse di studio, alloggio negli studentati, un’esenzione totale o parziale dalle tasse e altre agevolazioni. Per farne richiesta dovrai preparare la documentazione sui redditi e i patrimoni della tua famiglia.
- Copertura sanitaria Dall'arrivo in Italia e per tutto il tuo soggiorno devi avere una copertura sanitaria. Hai diverse opzioni: Tessera TEAM, Assicurazione privata o Iscrizione al Sistema Sanitario Nazionale italiano (SSN). Se possiedi la tessera TEAM Se sei in possesso della tessera sanitaria europea (TEAM) del tuo Paese UE di provenienza in corso di validità, puoi ricevere tutte le prestazioni sanitarie medicalmente necessarie. Per ottenere le prestazioni, puoi recarti direttamente presso un medico o una struttura sanitaria pubblica o convenzionata ed esibire la TEAM. L’assistenza è in forma diretta e pertanto nulla è dovuto, eccetto il pagamento di un eventuale contributo (“ticket”) che è a tuo carico e non rimborsabile. Con la TEAM puoi andare direttamente da un medico di base (detto anche medico di famiglia), scegliendolo dall’elenco dei medici di medicina generale (MMG) convenzionati disponibile sui siti Salute Bologna , se studi a Bologna, o dell'AUSL della Romagna , se studi negli altri campus. Con la tessera TEAM Card non puoi accedere alle cure "programmate all'estero", ossia prevedibili (es. cure dentarie non urgenti, cure termali, ecc.). Se possiedi un Attestato di diritto (es. E106, E109, etc.) Se sei in possesso di un attestato di diritto diverso dalla TEAM, di norma, per poter usufruire dell’assistenza sanitaria, devi preventivamente presentare tale attestato a uno degli Sportelli Unici dell’AUSL (CUP) , che verifica se è possibile iscriverti al Servizio Sanitario Nazionale (SSN) e in tal caso avrai diritto ad un’assistenza sanitaria completa alle stesse condizioni previste per i cittadini italiani. Il modo per accedere all’assistenza può variare a seconda dell’attestato di diritto in tuo possesso. Chiedi maggiori informazioni allo Sportello Unico (CUP) al momento dell’iscrizione. Consulta l’elenco degli Sportelli Unici (CUP) di Bologna , e della Romagna (province di Cesena, Forlì, Ravenna e Rimini). Altri casi Nel caso in cui tu non abbia né la tessera TEAM né un Attestato di diritto, devi stipulare un’assicurazione sanitaria privata valida in Italia o iscriverti al Servizio Sanitario Nazionale (SSN) italiano, dove previsto. Se hai un’assicurazione sanitaria privata , puoi andare da qualsiasi medico di base. Nel caso tu abbia bisogno di una visita specialistica, puoi scegliere tu direttamente a quale medico rivolgerti, eventualmente facendoti consigliare dal medico di base.Le polizze sanitarie private: Se il tuo soggiorno è per motivi di studio, verifica presso uno degli Sportelli Unici dell’AUSL (CUP) se puoi iscriverti al SSN . Per effettuare l’iscrizione volontaria al SSN da studente devi essere residente in Italia e pagare un contributo forfettario annuale non frazionabile di minimo 700 €.L’iscrizione al SSN viene effettuata per anno solare, dal 1° gennaio al 31 dicembre. Se fai un lavoro subordinato o autonomo e paghi le tasse in Italia hai diritto all’iscrizione obbligatoria e gratuita al Servizio Sanitario Nazionale . Verifica presso uno degli Sportelli Unici dell’AUSL (CUP) come iscriverti al SSN. Se sei residente in Italia da almeno 5 anni , puoi richiedere al Comune di residenza l’"Attestato di Soggiorno Permanente" che dà diritto all’iscrizione al Servizio Sanitario Nazionale italiano (SSN) con scelta del medico di base, a tempo indeterminato. Verifica presso uno degli Sportelli Unici dell’AUSL (CUP) come iscriverti al SSN. Come effettuare l’iscrizione volontaria al Servizio Sanitario Nazionale da studente Per chi richiede o possiede un permesso di soggiorno per motivi di studio, dal 2024 il costo minimo è di 700 € all’anno. L’iscrizione è fatta solo per anno solare (per es. dal 1° gennaio 2024 al 31 dicembre 2024) e non è possibile pagare quote ridotte per periodi più brevi. È consentito pagare l’iscrizione per l’anno corrente e anche per l’intero anno solare successivo (ad es. 2024 e 2025). Questa possibilità permette di avere la copertura sanitaria per un anno accademico ed è utile per gli studenti che arrivano, ad esempio, a settembre e intendono chiedere un permesso di soggiorno per studio valido un anno. Per la copertura di eventuali familiari a carico l’importo del contributo minimo è di 2000 € all’anno. Per iscriverti: Vai ad uno Sportello Unico dell’AUSL (CUP) . Consulta la lista degli Sportelli Unici (CUP) di Bologna , e della Romagna (province di Cesena, Forlì, Ravenna e Rimini). Porta con te: Chiedi le informazioni per effettuare il pagamento per l’iscrizione volontaria per studenti; ricorda che il pagamento deve essere fatto tramite il modello F24 ordinario .Devi compilare le parti: Paga il contributo annuale presentando il modello F24 per ciascun anno di iscrizione al SSN presso gli uffici postali, gli sportelli bancari, online tramite il tuo conto corrente o carte Pagobancomat, Postepay o Postamat e conserva le ricevute di pagamento. Fai una copia delle ricevute di pagamento e allegale alla tua domanda di primo rilascio o di rinnovo del permesso di soggiorno. Dopo aver inviato la domanda di permesso di soggiorno, ritorna il più presto possibile allo Sportello Unico (CUP) per attivare la copertura sanitaria e scegliere un medico di base.Porta con te: Il solo pagamento non implica l’attivazione della copertura . Devi completare l’iscrizione presso un ufficio dell’AUSL e scegliere un medico di base. Se paghi per due anni consecutivi, ricordati che alla fine dell’anno in corso devi tornare al CUP con la ricevuta di pagamento per l’anno successivo, e chiedere l’attivazione del servizio. Verifica sempre la data di fine copertura. Gli iscritti e le iscritte all’SSN ricevono per posta una Tessera Sanitaria. La tessera viene spedita all’indirizzo comunicato all’Agenzia delle Entrate; puoi contattare l’Agenzia delle Entrate per l’aggiornamento del tuo indirizzo e per richiedere la ristampa della tessera .

### Copertura sanitaria

Dall'arrivo in Italia e per tutto il tuo soggiorno devi avere una copertura sanitaria. Hai diverse opzioni: Tessera TEAM, Assicurazione privata o Iscrizione al Sistema Sanitario Nazionale italiano (SSN).

### Se possiedi la tessera TEAM

Se sei in possesso della tessera sanitaria europea (TEAM) del tuo Paese UE di provenienza in corso di validità, puoi ricevere tutte le prestazioni sanitarie medicalmente necessarie.

Per ottenere le prestazioni, puoi recarti direttamente presso un medico o una struttura sanitaria pubblica o convenzionata ed esibire la TEAM. L’assistenza è in forma diretta e pertanto nulla è dovuto, eccetto il pagamento di un eventuale contributo (“ticket”) che è a tuo carico e non rimborsabile.

Con la TEAM puoi andare direttamente da un medico di base (detto anche medico di famiglia), scegliendolo dall’elenco dei medici di medicina generale (MMG) convenzionati disponibile sui siti Salute Bologna, se studi a Bologna, o dell'AUSL della Romagna, se studi negli altri campus.

Con la tessera TEAM Card non puoi accedere alle cure "programmate all'estero", ossia prevedibili (es. cure dentarie non urgenti, cure termali, ecc.).

### Se possiedi un Attestato di diritto (es. E106, E109, etc.)

Se sei in possesso di un attestato di diritto diverso dalla TEAM, di norma, per poter usufruire dell’assistenza sanitaria, devi preventivamente presentare tale attestato a uno degli Sportelli Unici dell’AUSL (CUP), che verifica se è possibile iscriverti al Servizio Sanitario Nazionale (SSN) e in tal caso avrai diritto ad un’assistenza sanitaria completa alle stesse condizioni previste per i cittadini italiani.

Il modo per accedere all’assistenza può variare a seconda dell’attestato di diritto in tuo possesso. Chiedi maggiori informazioni allo Sportello Unico (CUP) al momento dell’iscrizione.

Consulta l’elenco degli Sportelli Unici (CUP) di Bologna, e della Romagna (province di Cesena, Forlì, Ravenna e Rimini).

### Altri casi

Nel caso in cui tu non abbia né la tessera TEAM né un Attestato di diritto, devi stipulare un’assicurazione sanitaria privata valida in Italia o iscriverti al Servizio Sanitario Nazionale (SSN) italiano, dove previsto.

Se hai un’assicurazione sanitaria privata, puoi andare da qualsiasi medico di base. Nel caso tu abbia bisogno di una visita specialistica, puoi scegliere tu direttamente a quale medico rivolgerti, eventualmente facendoti consigliare dal medico di base.
Le polizze sanitarie private:

- non prevedono l’iscrizione al SSN né l’assegnazione di un medico di base;
- di norma prevedono che l’utente paghi le spese e poi chieda il rimborso alla compagnia assicurativa.
Quando acquisti la polizza verifica con attenzione le modalità e i limiti dei rimborsi. Ricordati che le spese sanitarie da anticipare potrebbero essere molto alte, ad esempio in caso di ricovero ospedaliero. È consigliabile verificare in anticipo, contattando la tua compagnia di assicurazione, se il tipo di prestazione di cui hai bisogno sia rimborsabile.

Se il tuo soggiorno è per motivi di studio, verifica presso uno degli Sportelli Unici dell’AUSL (CUP) se puoi iscriverti al SSN. Per effettuare l’iscrizione volontaria al SSN da studente devi essere residente in Italia e pagare un contributo forfettario annuale non frazionabile di minimo 700 €.
L’iscrizione al SSN viene effettuata per anno solare, dal 1° gennaio al 31 dicembre.

Se fai un lavoro subordinato o autonomo e paghi le tasse in Italia hai diritto all’iscrizione obbligatoria e gratuita al Servizio Sanitario Nazionale. Verifica presso uno degli Sportelli Unici dell’AUSL (CUP) come iscriverti al SSN.

Se sei residente in Italia da almeno 5 anni, puoi richiedere al Comune di residenza l’"Attestato di Soggiorno Permanente" che dà diritto all’iscrizione al Servizio Sanitario Nazionale italiano (SSN) con scelta del medico di base, a tempo indeterminato. Verifica presso uno degli Sportelli Unici dell’AUSL (CUP) come iscriverti al SSN.

### Come effettuare l’iscrizione volontaria al Servizio Sanitario Nazionale da studente

Per chi richiede o possiede un permesso di soggiorno per motivi di studio, dal 2024 il costo minimo è di 700 € all’anno. L’iscrizione è fatta solo per anno solare (per es. dal 1° gennaio 2024 al 31 dicembre 2024) e non è possibile pagare quote ridotte per periodi più brevi.

È consentito pagare l’iscrizione per l’anno corrente e anche per l’intero anno solare successivo (ad es. 2024 e 2025). Questa possibilità permette di avere la copertura sanitaria per un anno accademico ed è utile per gli studenti che arrivano, ad esempio, a settembre e intendono chiedere un permesso di soggiorno per studio valido un anno.

Per la copertura di eventuali familiari a carico l’importo del contributo minimo è di 2000 € all’anno.

Per iscriverti:

Vai ad uno Sportello Unico dell’AUSL (CUP). Consulta la lista degli Sportelli Unici (CUP) di Bologna, e della Romagna(province di Cesena, Forlì, Ravenna e Rimini).  
Porta con te:

- il tuo passaporto;
- il tuo codice fiscale ufficiale italiano;
- certificato di iscrizione all’Università di Bologna o, per studenti di scambio, la Dichiarazione di arrivo;
- per gli Sportelli Unici (CUP) di Bologna, il modulo di iscrizione volontaria [.pdf 967 KB] per cittadini non-UE; qui puoi trovare un esempio con istruzioni per la compilazione [.pdf 371 KB].

Chiedi le informazioni per effettuare il pagamento per l’iscrizione volontaria per studenti; ricorda che il pagamento deve essere fatto tramite il modello F24 ordinario.
Devi compilare le parti:

- “contribuente” indicando i tuoi dati anagrafici;
- “sezione regioni” indicando codice regione 06 (Emilia-Romagna), codice tributo 8846;
- anno di riferimento: l’anno solare in cui vuoi iscriverti al SSN, ad esempio 2024;
- importi a debito versati: 700 €, se non hai altri redditi oltre alla borsa di studio e non vuoi includere nella copertura i tuoi famigliari. Se vuoi iscriverti per due anni consecutivi (ad esempio 2024 e 2025), devi fare due pagamenti.

Paga il contributo annuale presentando il modello F24 per ciascun anno di iscrizione al SSN presso gli uffici postali, gli sportelli bancari, online tramite il tuo conto corrente o carte Pagobancomat, Postepay o Postamat e conserva le ricevute di pagamento.

Fai una copia delle ricevute di pagamento e allegale alla tua domanda di primo rilascio o di rinnovo del permesso di soggiorno.

Dopo aver inviato la domanda di permesso di soggiorno, ritorna il più presto possibile allo Sportello Unico (CUP) per attivare la copertura sanitaria e scegliere un medico di base.
Porta con te:

- le ricevute di pagamento del contributo annuale;
- la ricevuta postale della domanda di permesso di soggiorno (o il permesso di soggiorno se già ottenuto);
- certificato di iscrizione all’Università di Bologna o, per studenti di scambio, la Dichiarazione di arrivo.

Il solo pagamento non implica l’attivazione della copertura. Devi completare l’iscrizione presso un ufficio dell’AUSL e scegliere un medico di base.

Se paghi per due anni consecutivi, ricordati che alla fine dell’anno in corso devi tornare al CUP con la ricevuta di pagamento per l’anno successivo, e chiedere l’attivazione del servizio.

Verifica sempre la data di fine copertura.

Gli iscritti e le iscritte all’SSN ricevono per posta una Tessera Sanitaria. La tessera viene spedita all’indirizzo comunicato all’Agenzia delle Entrate; puoi contattare l’Agenzia delle Entrate per l’aggiornamento del tuo indirizzo e per richiedere la ristampa della tessera.

Codice fiscale italiano



Per studiare in Italia dovrai richiedere un codice fiscale italiano. Rivolgiti in autonomia all'Agenzia delle Entrate oppure contattaci per avere il nostro aiuto per ottenerlo. Il codice ti sarà utile se vuoi anche per iscriverti al Servizio Sanitario Nazionale (SSN).

Presentazione del titolo di studio estero



Il titolo di studio che dichiarerai di possedere in fase di ammissione verrà controllato dalla Segreteria studenti Internazionali del campus di riferimento dopo la richiesta di immatricolazione e la presentazione in originale di tutti i documenti necessari richiesti.  
Ti consigliamo di presentarli alla Segreteria studenti internazionali il più presto possibile per un controllo preliminare e per ottenere, se ti serve, la validazione senza riserva della preiscrizione.

Codice fiscale italiano



Per studiare in Italia dovrai richiedere un codice fiscale italiano. Rivolgiti in autonomia all'Agenzia delle Entrate oppure contattaci per avere il nostro aiuto per ottenerlo. Il codice ti sarà utile se vuoi anche per iscriverti al Servizio Sanitario Nazionale (SSN).

Presentazione del titolo di studio estero



Il titolo di studio che dichiarerai di possedere in fase di ammissione verrà controllato dalla segreteria studenti internazionali del campus di riferimento dopo la richiesta di immatricolazione e la presentazione in originale di tutti i documenti necessari richiesti.
Ti consigliamo di presentarli alla Segreteria studenti internazionali il più presto possibile per un controllo preliminare e per ottenere, se ti serve, la validazione senza riserva della preiscrizione.

## Verifica dell'adeguatezza della preparazione

- In cosa consiste



Curriculum Ingegneria e Scienze informatiche (in italiano)
La verifica viene svolta da una Commissione analizzando il curriculum vitae e un eventuale colloquio di approfondimento. Le informazioni dettagliate saranno contenute nell'avviso che verrà pubblicato in questa pagina a giugno 2025.
Curriculum Intelligent Embedded Systems” (in inglese) percorso IES local track
Per il percorso IES local track la verifica prevede lo svolgimento di colloqui online. Il calendario dei colloqui sarà pubblicato nel profilo personale di Studenti Online, entro la data indicata nel bando di ammissione.
Curriculum Intelligent Embedded Systems” (in inglese) percorso EIT track
Per il percorso EIT track puoi fare riferimento alle indicazioni presenti sul sito EIT.


Numero posti
Per iscriverti al Curriculum Ingegneria e Scienze informatiche (in italiano)

Non è previsto un numero massimo di posti disponibili. Il curriculum è ad accesso libero.

Per iscriverti al Curriculum Intelligent Embedded Systems” (in inglese)

Per il percorso IES, local track, l'ammissione è limitata a 15 posti.
Per il percorso EIT track, l'ammissione è limitata a 10 posti.
- Come candidarti Per iscriverti al Curriculum Ingegneria e Scienze informatiche (in italiano) Per candidarti all’iscrizione è necessario caricare i documenti richiesti sul servizio Studenti Online entro i termini previsti dall’avviso. L'avviso verrà pubblicato attorno a giugno 2025, e sarà disponibile su questa pagina. Generalmente, i documenti richiesti sono il documento di identità e un'autocertificazione del titolo di studio, ma è opportuno controllare l'avviso per esser certi della documentazione da caricare. Se il titolo è straniero, è necessario che dal documento si evinca il numero di crediti, oppure le ore per insegnamento. Per iscriverti al Curriculum Intelligent Embedded Systems” (in inglese) Percorso IES local track Per accedere alla selezione accedi a Studenti Online e segui le istruzioni per "Iscriviti alla selezione", come indicato nel bando. L'iscrizione all’esame sarà completata solo dopo il pagamento della quota di 50 €, che non sarà rimborsabile in alcun caso. Per iscriverti al Curriculum Intelligent Embedded Systems” (in inglese) percorso EIT Per il percorso EIT track puoi fare riferimento alle indicazioni presenti sul sito EIT . Per iscriverti registrati seguendo le indicazioni nella pagina sulle ammissioni del sito EIT e segui le istruzioni e le scadenze indicate. Per l’anno accademico a.a 2025/26 sono previste tre sessioni di candidatura : A causa delle tempistiche, la terza sessione è aperta solo ai candidati che non hanno bisogno di un visto per studiare nell'UE. A seconda della tua cittadinanza, potresti aver bisogno di più tempo per completare le procedure necessarie al trasferimento. Per questo motivo, EIT consiglia vivamente di candidarsi entro febbraio 2025 . L'intero processo di immatricolazione è gestito dalla EIT Digital Master School .

### Come candidarti

### Per iscriverti al Curriculum Ingegneria e Scienze informatiche (in italiano)

Per candidarti all’iscrizione è necessario caricare i documenti richiesti sul servizio Studenti Online entro i termini previsti dall’avviso.

L'avviso verrà pubblicato attorno a giugno 2025, e sarà disponibile su questa pagina.

Generalmente, i documenti richiesti sono il documento di identità e un'autocertificazione del titolo di studio, ma è opportuno controllare l'avviso per esser certi della documentazione da caricare.

Se il titolo è straniero, è necessario che dal documento si evinca il numero di crediti, oppure le ore per insegnamento.

### Per iscriverti al Curriculum Intelligent Embedded Systems” (in inglese) Percorso IES local track

Per accedere alla selezione accedi a Studenti Online e segui le istruzioni per "Iscriviti alla selezione", come indicato nel bando. 
L'iscrizione all’esame sarà completata solo dopo il pagamento della quota di 50 €, che non sarà rimborsabile in alcun caso.

### Per iscriverti al Curriculum Intelligent Embedded Systems” (in inglese) percorso EIT

Per il percorso EIT track puoi fare riferimento alle indicazioni presenti sul sito EIT.

Per iscriverti registrati seguendo le indicazioni nella pagina sulle ammissioni del sito EIT e segui le istruzioni e le scadenze indicate.

Per l’anno accademico a.a 2025/26 sono previste tre sessioni di candidatura:

- 1ª sessione: 1 novembre 2024, ore 9:00 CET – 10 febbraio 2025, ore 18:00 CET (aperta a cittadini UE/EEA/CH e non-UE)
- 2ª sessione: 11 febbraio 2025, ore 9:00 CET – 14 aprile 2025, ore 18:00 CEST (aperta a cittadini UE/EEA/CH e non-UE)
- 3ª sessione: 15 aprile 2025, ore 9:00 CEST – 22 maggio 2025, ore 18:00 CEST (aperta solo a cittadini UE/EEA/CH e a candidati non-UE che non necessitano di un visto per studio).

A causa delle tempistiche, la terza sessione è aperta solo ai candidati che non hanno bisogno di un visto per studiare nell'UE.

A seconda della tua cittadinanza, potresti aver bisogno di più tempo per completare le procedure necessarie al trasferimento. Per questo motivo, EIT consiglia vivamente di candidarsi entro febbraio 2025.

L'intero processo di immatricolazione è gestito dalla EIT Digital Master School.

Come viene valutata



Per iscriverti al Curriculum Ingegneria e Scienze informatiche (in italiano)
Le domande di iscrizione saranno valutate dalla Commissione del Corso che analizzerà curriculum vitae ed eventualmente chiederà lo svolgimento di un colloquio secondo le modalità, i criteri fissati dal Consiglio di Corso e rese note tramite l'avviso che verrà pubblicato attorno a giugno 2025.
Per iscriverti al Curriculum Intelligent Embedded Systems” (in inglese) percorso IES local track
La modalità di valutazione è descritta nel bando, scaricabile qui in basso. Sono previste due fasi, una fase I di valutazione titoli di studio, una fase II basata su analisi del curriculum e colloquio.
Per iscriverti al Curriculum Intelligent Embedded Systems” (in inglese) percorso EIT track
Per il percorso EIT track è necessario seguire le indicazioni sull’ammissione presenti sul sito EIT.

Valutazione dell'esame Curriculum Ingegneria e scienze Informatiche (Italiano) Il corso è ad accesso libero, pertanto l'eventuale colloquio ha il solo scopo di verificare l'adeguatezza della personale preparazione. Curriculum Intelligent Embedded Systems (Inglese) Percorso IES local track Per le modalità di valutazione, si prega di fare riferimento al bando di ammissione . Percorso EIT track La graduatoria si basa sulla valutazione complessiva dei seguenti criteri: Fonte: FAQ (https://masterschool.eitdigital.eu/faq ) Per informazioni ufficiali e dettagliate sul percorso EIT track , si prega di consultare la pagina specifica , che rappresenta la principale fonte di riferimento.

### Valutazione dell'esame

Curriculum Ingegneria e scienze Informatiche (Italiano)

Il corso è ad accesso libero, pertanto l'eventuale colloquio ha il solo scopo di verificare l'adeguatezza della personale preparazione.

Curriculum Intelligent Embedded Systems (Inglese)

Percorso IES local track

Per le modalità di valutazione, si prega di fare riferimento al bando di ammissione.

Percorso EIT track

La graduatoria si basa sulla valutazione complessiva dei seguenti criteri:

- Adeguatezza della laurea triennale rispetto al programma di studio scelto.
- Eccellenza accademica, considerando la qualità e il riconoscimento dell’università di provenienza, nonché i risultati accademici ottenuti.
- Eccellenza imprenditoriale.
- Potenziale innovativo.

Fonte: FAQ (https://masterschool.eitdigital.eu/faq)

Per informazioni ufficiali e dettagliate sul percorso EIT track, si prega di consultare la pagina specifica, che rappresenta la principale fonte di riferimento.

## Immatricolazione

- Come immatricolarti



Accedi a Studenti Online, compila la richiesta di immatricolazione e paga la prima rata delle tasse o in alternativa la monorata secondo le modalità indicate. Se non effettui il pagamento, secondo le modalità previste, verrai escluso dalla procedura. Inoltre, non sono ammessi pagamenti tardivi con mora.
- Preiscrizione su Universitaly



Dopo aver superato la verifica dell'adeguatezza della preparazione, se non l'hai ancora fatto, presenta online la domanda di preiscrizione su Universitaly, che ti servirà per richiedere il visto d'ingresso.
Nella domanda indica questo corso. Leggi la  Guida e le FAQ [.pdf 730 KB] per capire come compilare la domanda. 
Se hai superato la verifica dell'adeguatezza della preparazione, e hai pagato la prima rata, gli uffici valideranno la preiscrizione.
Scarica il riepilogo della domanda e presentalo all'Ambasciata o al Consolato per richiedere il visto.
Se hai la necessità di cambiare il corso di studio o l’Università che hai inserito nella domanda di preiscrizione, leggi le informazioni su cambio di preiscrizione e riassegnazione.
Gli uffici dell’Università di Bologna potrebbero essere chiusi per un periodo in agosto durante il quale non vengono validate preiscrizioni, quindi nel mese di agosto i tempi validazione delle preiscrizioni potrebbero allungarsi.
Se la tua Ambasciata o Consolato richiede che la tua preiscrizione sia validata senza riserva, vai alla sezione di questa pagina "Attivazione della carriera e badge" e leggi come fare.
Ricordati che la preiscrizione non consente di per sé l’ammissione al corso. Per immatricolarti devi anche sostenere e superare le verifiche dei requisiti di accesso e dell'adeguatezza della preparazione previsti dal corso.
L’Università di Bologna non rilascia lettere di idoneità accademica per l’ottenimento del visto.
Il visto di ingresso per turismo non può essere utilizzato per l’iscrizione all’università o per ottenere un permesso di soggiorno per studio.
- Richiesta del visto e copertura sanitaria Per richiedere il visto devi necessariamente attivare una copertura sanitaria . Dall'arrivo in Italia e per tutto il tuo soggiorno è necessario essere coperti da un'assicurazione sanitaria privata o dal Servizio Sanitario Nazionale italiano. Potrai iscriverti al Servizio Sanitario Nazionale italiano solo dopo l'arrivo in Italia. Se intendi farlo, puoi valutare di acquistare un'assicurazione privata breve per coprire il viaggio e il primo periodo in Italia (salvo diverse indicazioni dell'Ambasciata per il visto). Se non intendi farlo, puoi valutare di acquistare un'assicurazione privata più lunga (almeno 1 anno). Visto di ingresso per "studio/immatricolazione università" Se non hai ancora un visto di lunga durata, prendi un appuntamento all'Ambasciata o al Consolato e porta con te: All'Ambasciata o al Consolato devi ottenere un visto per “studio – immatricolazione università”, i documenti che hai richiesto ed eventualmente il codice fiscale italiano .

### Richiesta del visto e copertura sanitaria

Per richiedere il visto devi necessariamente attivare una copertura sanitaria.

Dall'arrivo in Italia e per tutto il tuo soggiorno è necessario essere coperti da un'assicurazione sanitaria privata o dal Servizio Sanitario Nazionale italiano. Potrai iscriverti al Servizio Sanitario Nazionale italiano solo dopo l'arrivo in Italia. Se intendi farlo, puoi valutare di acquistare un'assicurazione privata breve per coprire il viaggio e il primo periodo in Italia (salvo diverse indicazioni dell'Ambasciata per il visto). Se non intendi farlo, puoi valutare di acquistare un'assicurazione privata più lunga (almeno 1 anno).

### Visto di ingresso per "studio/immatricolazione università"

Se non hai ancora un visto di lunga durata, prendi un appuntamento all'Ambasciata o al Consolato e porta con te:

- il riepilogo della domanda di preiscrizione su Universitaly validata dall’Università di Bologna;
- il documento attestante le risorse economiche necessarie alla permanenza in Italia (minimo richiesto per il 2024: € 6.947,33). Puoi consegnare, per esempio, l'estratto del conto corrente bancario o postale;
- gli eventuali certificati per il requisito di lingua del corso;
- l'eventuale assicurazione sanitaria;
- i moduli dell'agenzia delle entrate per richiedere il codice fiscale italiano. Trovi i moduli sul sito dell'Ambasciata o del Consolato se offre il servizio;
- il titolo di studio per tradurlo, legalizzarlo e autenticarlo, se necessario e se il servizio è previsto;
- l'eventuale documentazione per ottenere agevolazioni economiche

All'Ambasciata o al Consolato devi ottenere un visto per “studio – immatricolazione università”, i documenti che hai richiesto ed eventualmente il codice fiscale italiano.

Validazione dell'identità Validare la tua identità vuol dire associare l’account nome.cognome@studio.unibo.it alla tua identità. Cosa fare La tua identità sarà automaticamente validata , senza che tu debba fare nulla, in uno di questi casi: Se non rientri in una delle condizioni indicate sopra e non puoi avere le credenziali SPID, perché sei minorenne o risiedi all’estero, contatta la segreteria studenti o, se hai la residenza all’estero e hai un titolo di studio estero, la segreteria studenti internazionale.

### Validazione dell'identità

Validare la tua identità vuol dire associare l’account nome.cognome@studio.unibo.it alla tua identità.

### Cosa fare

La tua identità sarà automaticamente validata, senza che tu debba fare nulla, in uno di questi casi:

- possiedi le credenziali SPID e accedi con queste a Studenti Online almeno una volta;
- possiedi la carta di identità elettronica e accedi a Studenti Online tramite il percorso Entra con CIE;
- hai già fatto parte della comunità studentesca dell’Università di Bologna, dal 2004 in avanti;
- hai sostenuto una prova scritta o orale, anche a distanza, presso l’Ateneo di Bologna (ad esclusione di TOLC e prove di selezioni per concorsi nazionali).

Se non rientri in una delle condizioni indicate sopra e non puoi avere le credenziali SPID, perché sei minorenne o risiedi all’estero, contatta la segreteria studenti o, se hai la residenza all’estero e hai un titolo di studio estero, la segreteria studenti internazionale.

Attivazione della carriera e badge L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi. La tua carriera sarà automaticamente attivata dopo l'identificazione. Non è attiva automaticamente se: La carriera deve essere attivata entro il 26 febbraio 2026. Appena la carriera sarà attivata riceverai un’email con le istruzioni per stampare il badge.

### Attivazione della carriera e badge

L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi.

La tua carriera sarà automaticamente attivata dopo l'identificazione.

Non è attiva automaticamente se:

- hai conseguito il titolo di studio all’estero:  devi presentare il tuo titolo di studio alla segreteria studenti internazionali del Campus in cui andrai a studiare. Raccogli tutta la documentazione necessaria sul tuo titolo di studio; accedi a Studenti Online nella sezione “Bandi”, seleziona “Immatricolazione a.a. 25\_26- caricamento dei documenti degli studenti internazionali e con titolo estero” e carica i documenti di studio elencati. Prenota un appuntamento presso la Segreteria studenti internazionali per mostrare i documenti in originale;
- non hai ancora conseguito la laurea in Italia in un Ateneo diverso dal nostro: non appena ti laureerai, collegati a Studenti Online e completa le informazioni sul voto. Ricorda che il titolo deve essere conseguito entro il 31 dicembre 2025, altrimenti l’immatricolazione sarà annullata.

La carriera deve essere attivata entro il 26 febbraio 2026.

Appena la carriera sarà attivata riceverai un’email con le istruzioni per stampare il badge.

Attivazione della carriera e badge L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi. La tua carriera sarà automaticamente attivata dopo la validazione della tua identità. Non è attiva automaticamente se: La carriera deve essere attivata entro il 26 febbraio 2026. Appena la carriera sarà attivata riceverai un’email con le istruzioni per stampare il badge.

### Attivazione della carriera e badge

L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi.

La tua carriera sarà automaticamente attivata dopo la validazione della tua identità.

Non è attiva automaticamente se:

- hai la cittadinanza di un Paese non-UE, ma possiedi un titolo di equiparazione e hai conseguito il titolo di studio in Italia: invia per email alla segreteria studenti del tuo corso la copia del permesso di soggiorno che consente l’equiparazione;
- hai la cittadinanza di un Paese non-UE, ma possiedi un titolo di equiparazione e hai conseguito il titolo di studio all’estero : presenta il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare:
    - raccogli tutta la documentazione necessaria sul tuo titolo di studio;
    - accedi a Studenti Online;
    - se non lo hai ancora fatto, e sei ancora in tempo, paga la prima rata delle tasse;
    - vai nella sezione "Bandi", cerca il bando "Immatricolazione a.a. 25\_26 - caricamento dei documenti degli studenti internazionali e con titolo estero";
    - carica i documenti richiesti e il permesso di soggiorno che consente l’equiparazione.
La Segreteria studenti internazionali controllerà i documenti. 
Prenota un appuntamento presso la segreteria studenti internazionali per mostrare i documenti in originale. 
Al tuo arrivo in Italia, vai all’appuntamento e porta con te i documenti relativi al tuo titolo di studio e il passaporto.
- hai la cittadinanza di un Paese UE e hai conseguito il titolo di studio all’estero : presenta il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare:
    - raccogli tutta la documentazione necessaria sul tuo titolo di studio;
    - accedi a Studenti Online;
    - se non lo hai ancora fatto, e sei ancora in tempo, paga la prima rata delle tasse;
    - vai nella sezione "Bandi", cerca il bando "Immatricolazione a.a. 25\_26 - caricamento dei documenti degli studenti internazionali e con titolo estero";
    - carica i documenti richiesti.
La segreteria studenti internazionali controllerà i documenti. 
Prenota un appuntamento presso la segreteria studenti internazionali per mostrare i documenti in originale. All’appuntamento porta con te i documenti relativi al tuo titolo di studio e il documento di identità.

- non hai ancora conseguito la laurea in Italia in un Ateneo diverso dal nostro: non appena ti laureerai, collegati a Studenti Online e completa le informazioni sul voto. Ricorda che il titolo deve essere conseguito entro il 31 dicembre 2025, altrimenti l’immatricolazione sarà annullata.

La carriera deve essere attivata entro il 26 febbraio 2026.

Appena la carriera sarà attivata riceverai un’email con le istruzioni per stampare il badge.

Attivazione della carriera e badge L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi. Se hai conseguito il titolo di studio all’estero devi presentare il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare: Se hai bisogno della validazione senza riserva su Universitaly segnalalo per e-mail alla Segreteria Studenti Internazionali. La Segreteria studenti internazionali controllerà i documenti. Se sono completi e se sarà possibile verificarne l’autenticità e il valore, validerà la tua preiscrizione su Universitaly senza riserva. Prenota un appuntamento presso la segreteria studenti internazionali per mostrare i documenti in originale.Al tuo arrivo in Italia, vai all’appuntamento e porta con te i documenti relativi al tuo titolo di studio e il passaporto. Se i documenti sono completi, la segreteria ti darà un certificato di iscrizione. Successivamente dovrai inviare per e-mail la ricevuta della richiesta del permesso di soggiorno alla segreteria studenti internazionali per attivare la carriera. La tua immatricolazione sarà accolta con riserva fino a quando non ti verrà consegnato il permesso di soggiorno e ne invierai una copia alla segreteria studenti. Se hai la cittadinanza di un Paese non-UE, risiedi all’estero, ma hai un titolo italiano conseguito in Italia, contatta la segreteria studenti internazionali del tuo campus per sapere come fare. La carriera deve essere attivata entro il 26 febbraio 2026. Appena la carriera sarà attivata riceverai un’e-mail con le istruzioni per stampare il badge.

### Attivazione della carriera e badge

L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi.

Se hai conseguito il titolo di studio all’estero devi presentare il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare:

- raccogli tutta la documentazione necessaria sul tuo titolo di studio;
- accedi a Studenti Online;
- se non lo hai ancora fatto, e sei ancora in tempo, paga la prima rata delle tasse;
- vai nella sezione "Bandi", cerca il bando "Immatricolazione a.a. 25\_26 - caricamento dei documenti degli studenti internazionali e con titolo estero";
- carica i documenti richiesti e, se lo possiedi già, il visto di ingresso per motivi di studio.

Se hai bisogno della validazione senza riserva su Universitaly segnalalo per e-mail alla Segreteria Studenti Internazionali. La Segreteria studenti internazionali controllerà i documenti. Se sono completi e se sarà possibile verificarne l’autenticità e il valore, validerà la tua preiscrizione su Universitaly senza riserva.

Prenota un appuntamento presso la segreteria studenti internazionali per mostrare i documenti in originale.
Al tuo arrivo in Italia, vai all’appuntamento e porta con te i documenti relativi al tuo titolo di studio e il passaporto. Se i documenti sono completi, la segreteria ti darà un certificato di iscrizione.

Successivamente dovrai inviare per e-mail la ricevuta della richiesta del permesso di soggiorno alla segreteria studenti internazionali per attivare la carriera. La tua immatricolazione sarà accolta con riserva fino a quando non ti verrà consegnato il permesso di soggiorno e ne invierai una copia alla segreteria studenti.

Se hai la cittadinanza di un Paese non-UE, risiedi all’estero, ma hai un titolo italiano conseguito in Italia, contatta la segreteria studenti internazionali del tuo campus per sapere come fare.

La carriera deve essere attivata entro il 26 febbraio 2026.
Appena la carriera sarà attivata riceverai un’e-mail con le istruzioni per stampare il badge.

Permesso di soggiorno e copertura sanitaria Iscrizione al Servizio Sanitario Nazionale italiano (SSN) Per iscriverti al SSN occorre pagare la quota annuale. Se richiedi o possiedi un permesso di soggiorno per motivi di studio, dal 2024 il costo minimo è di 700€ all’anno. L’iscrizione è fatta solo per anno solare (es. dal 1 gennaio 2024 al 31 dicembre 2024) e non è possibile pagare quote ridotte per periodi più brevi. È consentito pagare l’iscrizione per l’anno corrente e anche per l’intero anno solare successivo (es. 2024 e 2025). Questa possibilità ti permette di avere la copertura sanitaria per un anno accademico ed è utile se arrivi, ad esempio, a settembre e intendi chiedere un permesso di soggiorno per studio valido un anno. Per la copertura di eventuali familiari a carico l’importo del contributo minimo è di 2000 euro all’anno. Iscriviti ad uno Sportello Unico dell’AUSL (CUP) e porta con te: Chiedi le informazioni per effettuare il pagamento per "l’iscrizione volontaria per studenti". Il pagamento devi farlo tramite il modello F24 ordinario e le parti da compilare sono: Paga il contributo annuale presentando il modello F24 per ciascun anno di iscrizione al SSN presso gli uffici postali, gli sportelli bancari, online tramite il tuo conto corrente o carte Pagobancomat, Postepay o Postamat e conserva le ricevute di pagamento. Fai una copia delle ricevute di pagamento e allegale alla tua domanda di primo rilascio o di rinnovo del permesso di soggiorno. Il solo pagamento non implica l’attivazione della copertura. Devi completare l’iscrizione presso un ufficio dell’AUSL e scegliere un medico di base. Fai domanda per il Permesso di soggiorno Entro otto giorni dall'arrivo in Italia presenta la domanda per ottenere il permesso . Lo puoi fare in autonomia oppure con il nostro supporto.Invia per e-mail la ricevuta della richiesta del permesso di soggiorno alla tua Segreteria studenti internazionali. Ricordati che il permesso di soggiorno va rinnovato ogni anno . Attiva la copertura sanitaria e scegli il medico di base Dopo aver inviato la domanda di permesso di soggiorno, ritorna il più presto possibile allo Sportello Unico (CUP) per attivare la copertura sanitaria e scegliere un medico di base. Porta con te: Se paghi per due anni consecutivi, ricordati che alla fine dell’anno in corso devi tornare al CUP con la ricevuta di pagamento per l’anno successivo, e chiedere l’attivazione del servizio. Verifica sempre la data di fine copertura.Riceverai per posta una Tessera sanitaria e verrà spedita all’indirizzo che hai comunicato all’Agenzia delle Entrate. Puoi contattare l’Agenzia delle Entrate per l’aggiornamento del tuo indirizzo ed eventualmente per richiedere la ristampa della tessera.

### Permesso di soggiorno e copertura sanitaria

#### Iscrizione al Servizio Sanitario Nazionale italiano (SSN)

Per iscriverti al SSN occorre pagare la quota annuale. Se richiedi o possiedi un permesso di soggiorno per motivi di studio, dal 2024 il costo minimo è di 700€ all’anno. L’iscrizione è fatta solo per anno solare (es. dal 1 gennaio 2024 al 31 dicembre 2024) e non è possibile pagare quote ridotte per periodi più brevi.

È consentito pagare l’iscrizione per l’anno corrente e anche per l’intero anno solare successivo (es. 2024 e 2025). Questa possibilità ti permette di avere la copertura sanitaria per un anno accademico ed è utile se arrivi, ad esempio, a settembre e intendi chiedere un permesso di soggiorno per studio valido un anno. Per la copertura di eventuali familiari a carico l’importo del contributo minimo è di 2000 euro all’anno.

Iscriviti ad uno Sportello Unico dell’AUSL (CUP) e porta con te:

- il passaporto;
- il codice fiscale ufficiale italiano;
- il certificato di iscrizione all’Università di Bologna;
- per gli Sportelli Unici (CUP) di Bologna, il modulo di iscrizione volontaria [.pdf 967 KB].  Un esempio con le istruzioni per la compilazione [.pdf 371 KB].

Chiedi le informazioni per effettuare il pagamento per "l’iscrizione volontaria per studenti". Il pagamento devi farlo tramite il modello F24 ordinario e le parti da compilare sono:

- "contribuente" indica i tuoi dati anagrafici;
- "sezione regioni" indica il codice regione 06 (Emilia-Romagna) e il codice tributo 8846;
- anno di riferimento: l’anno solare in cui vuoi iscriverti al SSN (es. 2024);
- importi a debito versati: 700 €, se non hai altri redditi oltre alla borsa di studio e non vuoi includere nella copertura i tuoi famigliari. Se vuoi iscriverti per due anni consecutivi (es. 2024 e 2025), devi fare due pagamenti.

Paga il contributo annuale presentando il modello F24 per ciascun anno di iscrizione al SSN presso gli uffici postali, gli sportelli bancari, online tramite il tuo conto corrente o carte Pagobancomat, Postepay o Postamat e conserva le ricevute di pagamento.

Fai una copia delle ricevute di pagamento e allegale alla tua domanda di primo rilascio o di rinnovo del permesso di soggiorno.

#### Fai domanda per il Permesso di soggiorno

Entro otto giorni dall'arrivo in Italia presenta la domanda per ottenere il permesso. Lo puoi fare in autonomia oppure con il nostro supporto.
Invia per e-mail la ricevuta della richiesta del permesso di soggiorno alla tua Segreteria studenti internazionali. Ricordati che il permesso di soggiorno va rinnovato ogni anno.

#### Attiva la copertura sanitaria e scegli il medico di base

Dopo aver inviato la domanda di permesso di soggiorno, ritorna il più presto possibile allo Sportello Unico (CUP) per attivare la copertura sanitaria e scegliere un medico di base. Porta con te:

- le ricevute di pagamento del contributo annuale;
- la ricevuta postale della domanda di permesso di soggiorno (o il permesso di soggiorno se già ottenuto);
- il certificato di iscrizione all’Università di Bologna o, se sei studente o studentessa di scambio, la Dichiarazione di arrivo.

Se paghi per due anni consecutivi, ricordati che alla fine dell’anno in corso devi tornare al CUP con la ricevuta di pagamento per l’anno successivo, e chiedere l’attivazione del servizio. Verifica sempre la data di fine copertura.
Riceverai per posta una Tessera sanitaria e verrà spedita all’indirizzo che hai comunicato all’Agenzia delle Entrate.

Puoi contattare l’Agenzia delle Entrate per l’aggiornamento del tuo indirizzo ed eventualmente per richiedere la ristampa della tessera.

## Bandi

- BANDO Curriculum inglese Intelligent Embedded Systems 25/26 - local track
        
          [.pdf
          602Kb]
          
        
Scadenza iscrizioni: 22 aprile 2025 ore 13.00 italiane
- Bando Intelligent embedded Systems 25/26 - ENGLISH VERSION
        
          [.pdf
          2656Kb]

## Bando Curriculum in Italiano Ingegneria e Scienze Informatiche 25/26

- Bando curriculum Italiano 25/26 Ingegneria e Scienze Informatiche
        
          [.pdf
          600Kb]

<!-- image -->

Ti vuoi trasferire?

Sei di un altro Ateneo e vuoi trasferirti all'Unibo.

<!-- image -->

Vuoi cambiare corso?

Segui le tue passioni e scopri come puoi cambiare.

- Sosteniamo il diritto alla conoscenza