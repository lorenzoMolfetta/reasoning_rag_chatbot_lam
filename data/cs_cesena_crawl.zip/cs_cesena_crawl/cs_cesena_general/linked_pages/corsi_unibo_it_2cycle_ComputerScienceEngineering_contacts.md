# Contacts

- category
- name

## Alias Career Support Service

How can we help you:
                          Activating an alias career, that is, having your legal name replaced with a chosen name.

Virtual Helpdesk

## Career Guidance Service

How can we help you:
                          Creating your curriculum vitae and LinkedIn profile, getting ready for a job interview, successfully looking for a job.

E-mail
campuscesena.orientamentourp@unibo.it

Phone
+39 0547 338900
Telephone hours

                                  Monday
                                  9-11:30 a.m.
                                

                                  Tuesday
                                  9-11:30 a.m.
                                

                                  Wednesday
                                  9-11:30 a.m.
                                

                                  Thursday
                                  1:30-3:30 p.m.

Address
Via Montalti n. 69 - 47521 Cesena (FC)
Public opening hours

## Degree Programme Tutor

How can we help you:
                          From choosing a degree programme to your course timetable, from preparing your study plan to taking exams or writing your dissertation. Studying together, getting advice on how to plan your activities.

Contact person's name for the office
                            Luca Patrignani

E-mail
campuscesena.tutorlmisi@unibo.it

## ER.GO – Regional Authority for the Right to Higher Education

How can we help you:
                          Learning about benefits for the right to higher education: study grants, accommodation and canteens.

Web site

## Guidance Service

How can we help you:
                          Choosing a degree programme, getting involved in university life also through guidance events.

E-mail
campuscesena.orientamentourp@unibo.it

Phone
+39 0547 338900
Telephone hours

                                  Monday
                                  9-11:30 a.m.
                                

                                  Tuesday
                                  9-11:30 a.m.
                                

                                  Wednesday
                                  9-11:30 a.m.
                                

                                  Thursday
                                  1:30-3:30 p.m.

Address
Via Montalti 69, Cesena
Public opening hours

## Guidance Tutor

How can we help you:
                          How can we help you: Choosing the degree programme that best suits your needs, getting information on how to enrol.

Contact person's name for the office
                            Elvis Perlika

E-mail
elvis.perlika2@unibo.it

## Internationalisation Tutor

How can we help you:
                          Information on study and research opportunities and mobility programmes abroad.

Contact person's name for the office
                            Alberto Antonello

E-mail
campuscesena.internazionalizzazioneingegneria@unibo.it

Other information
Information on study and research opportunities and mobility programmes abroad.

## Internship Office

How can we help you:
                          Activate and manage a curricular internship or one for the preparation for the final dissertation, in Italy and abroad, outside of international mobility programmes.

E-mail
campuscesena.tirocini@unibo.it

Phone
+39 0547 338914
Telephone hours

                                  Monday
                                  11am-12pm
                                

                                  Tuesday
                                  11am-12pm
                                

                                  Wednesday
                                  11am-12pm
                                

                                  Thursday
                                  11am-12pm

Address
Via Montalti 69 - 47521 Cesena FC
Public opening hours

Other information
Schedule via email or by telephone an online appointment or an in-person reception.

## Job Placement

How can we help you:
                          Learning about opportunities for professional growth, getting in touch with businesses for job opportunities.

E-mail
Jobplacement@unibo.it

Phone
+39 051 2088564;
                            
                              +39 051 2099783;
                            
                              +39 051 2099872;
                            
                              +39 051 2098931
Telephone hours

Address
Palazzo Paleotti - Largo Trombetti, 1 40126 – Bologna
Public opening hours

## Programme Coordinator

How can we help you:
                          Notices about logistics and organisational aspects concerning your degree programme, general information on admissions, exams, course timetable, study plan and graduation.

Contact person's name for the office
                            Alessia Pollice

E-mail
campuscesena.tutorlmisi@unibo.it

Address
Via dell'Università 50, Cesena 47521
Public opening hours

Other information
To schedule an appointmnent on MS TEAMS please contact the office via email.

## Service for Students with Disabilities and SLD

How can we help you:
                          Taking the necessary actions to ensure that each person can study and take exams and tests in the most effective way possible.

Contact person's name for the office
                            Silvia Mirri

Virtual Helpdesk

E-mail
disabilita@unibo.it;
                            
                              dsa@unibo.it;
                            
                              silvia.mirri@unibo.it

Phone
+39 051 2080740
Telephone hours

                                  Monday
                                  9:30 a.m. - 12 p.m

## Student Administration Office

How can we help you:
                          Enrolling, changing your degree programme, transferring to and from the University of Bologna, graduating, diploma supplement and other procedures.

Virtual Helpdesk

E-mail
segcesena@unibo.it

Address
Palazzo Urbinati - Via Montalti 69 - 47521 Cesena FC
Public opening hours

                                  Wednesday
                                  9am-12pm

Other information
Make an appointment via email for the delivery of the documents or send them by mail.

## Student Ombudsman

How can we help you:
                          Report dysfunctions, shortfalls or violations of the law or the principles of good administration.

E-mail
garante@unibo.it

## Student-Athlete Career Support Service

How can we help you:
                          Applying for the Student-Athlete Dual Career Status and finding the right balance between your academic studies and professional sports career.

E-mail
studenteatleta@unibo.it

## Study Grant Office

How can we help you:
                          Detailed information on study grants, awards and discounts made available by the University.

Virtual Helpdesk

E-mail
uborstudio@unibo.it

## Teaching Service

How can we help you:
                          Indications on your student career status and credit recognition if you transfer from another university or change your degree programme

E-mail
campuscesena.didattica.isa@unibo.it

Phone
+39 0547338300
Telephone hours

Other information
You can contact us via e-mail and MsTeams. You can write an email to get further information or to book a call on Teams: you will receive an e-mail with the day, time and link to connect, after you have downloaded the app.

## Teaching Support for Mobility

How can we help you:
                          Information about teaching matters for incoming and outgoing mobility programmes within and outside the EU, Learning Agreement and credit recognition.

E-mail
campuscesena.uri@unibo.it

Phone
+39 0547 339006
Telephone hours

                                  Monday
                                  10 a.m. - 12 p.m.
                                

                                  Thursday
                                  11 a.m. - 12 p.m.

Address
Palazzo Urbinati - Via Montalti 69, 47521 Cesena
Public opening hours

Other information
Schedule via email an online appointment or, if you are an incoming student, an in-person reception.

## Technical support Studenti Online application

How can we help you:
                          Technical issues and requests for support on the Studenti Online application.

E-mail
help.studentionline@unibo.it

Phone
+39 051 2080301
Telephone hours

                                  Monday
                                  9 am-13 pm e 14 pm-17 pm
                                

                                  Tuesday
                                  9 am-13 pm e 14 pm-17 pm
                                

                                  Wednesday
                                  9 am-13 pm e 14 pm-17 pm
                                

                                  Thursday
                                  9 am-13 pm e 14 pm-17 pm
                                

                                  Friday
                                  9 am-13 pm e 14 pm-17 pm

## Tuition Fees Office

How can we help you:
                          Learning about fees and exemptions, amounts due, payment deadlines and required documentation.

Virtual Helpdesk

E-mail
ases.contribuzionistudentesche@unibo.it

## Working Student Support Service

How can we help you:
                          Applying for the "working student" status.

E-mail
conciliazione.studiolavoro@unibo.it

The name you entered is not in the list.

- Support the right to knowledge