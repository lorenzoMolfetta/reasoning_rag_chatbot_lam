# Il Corso

<!-- image -->

## Profilo

- Esplora il Corso
- Cosa si studia?
- Insegnamenti: piano didattico
- Obiettivi formativi
- Risultati di apprendimento attesi
- Prospettive
- Docenti
- Curriculum: Intelligent Embedded Systems - EIT Digital track
- Cosa dicono i nostri studenti

<!-- image -->

## Organizzazione e Qualità

- Coordinatore e Consiglio di Corso
- Tutor del Corso
- Rappresentanti degli studenti
- Servizi di orientamento
- Segreteria e uffici
- Aule, laboratori e biblioteche
- Sistema di assicurazione di qualità
- Commissione di gestione AQ e altre
- Qualità: il Corso in cifre
- Comitato Consultivo
- Opinioni della comunità studentesca

### Regolamenti

- Regolamento didattico
- Regolamento Studenti d'Ateneo

- Sosteniamo il diritto alla conoscenza