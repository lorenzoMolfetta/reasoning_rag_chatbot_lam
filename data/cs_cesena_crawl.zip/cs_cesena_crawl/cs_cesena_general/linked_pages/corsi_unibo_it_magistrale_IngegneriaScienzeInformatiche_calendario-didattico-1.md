# Calendario didattico

Periodi di lezione e di esame del Corso di Laurea Magistrale in Ingegneria e Scienze Informatiche

CALENDARIO DIDATTICO 2024/2025

Periodi di lezioni:

I ciclo: inizio lezioni: 18/09/2024 - Fine lezioni: 18/12/2024.

Sospensione delle lezioni per festività e/o ponti: 01/11/2024 (Festa Ognissanti).

II ciclo: dal 17/02/2025 al 10/06/2025.
Sospensione delle lezioni per festività e/o ponti: festività di Pasqua dal 17/04/2025 al 22/04/2025 compresi, 23-24/04/2025 (ponte), 25/04/2025 (Festa della Liberazione), 1 maggio 2025 (Festa del Lavoro), 2 maggio 2025 (ponte), 2 giugno 2025 (Festa della Repubblica).

Periodi di esami:
Primo periodo: dal 19/12/2024 al 14/02/2025
Secondo periodo dall' 11/06/2025 all'inizio delle lezioni dell'a. a. 2025/26 (settembre 2025)

Si ricordano alcune norme di buona organizzazione, in merito alla fissazione degli appelli d’esame, che il Corso di Studio si è dato:

- evitare la di sovrapposizione di appelli relativi ad insegnamenti dello stesso anno di corso ogni volta che sia possibile;

- evitare di fissare appelli durante il periodo delle lezioni, per consentire a tutti gli studenti di frequentare tutte le lezioni, fino al termine delle stesse;

- fissare le date con congruo anticipo, verificando la disponibilità dell’aula attraverso l'Ufficio Gestione corsi di studio, prima di pubblicare le prove su AlmaEsami;

- fissare almeno due appelli nel periodo di esame immediatamente successivo alla fine delle lezioni, e almeno uno in ogni altro periodo di esame successivo alla fine delle lezioni.

CALENDARIO DIDATTICO 2025/2026

Periodi di lezioni:

I ciclo: inizio lezioni: 17/09/2025 - Fine lezioni: 19/12/2025.

Sospensione delle lezioni per festività e/o ponti: 08/12/2025 (Immacolata).

II ciclo: dal 16/02/2026 al 05/06/2026.
Sospensione delle lezioni per festività e/o ponti: festività di Pasqua dal 02/04/2026 al 08/04/2026 compresi, 1 maggio 2026 (Festa del Lavoro), 1 giugno 2026 (ponte), 2 giugno (Festa della Repubblica).

Periodi di esami:
Primo periodo: dal 22/12/2025 al 13/02/2026 (escludendo la giornata del 24.12.2025)
Secondo periodo dall' 08/06/2026 all'11/09/2026

Si ricordano alcune norme di buona organizzazione, in merito alla fissazione degli appelli d’esame, che il Corso di Studio si è dato:

- evitare la di sovrapposizione di appelli relativi ad insegnamenti dello stesso anno di corso ogni volta che sia possibile;

- evitare di fissare appelli durante il periodo delle lezioni, per consentire a tutti gli studenti di frequentare tutte le lezioni, fino al termine delle stesse;

- fissare le date con congruo anticipo, verificando la disponibilità dell’aula attraverso l'Ufficio Gestione corsi di studio, prima di pubblicare le prove su AlmaEsami;

- fissare almeno due appelli nel periodo di esame immediatamente successivo alla fine delle lezioni, e almeno uno in ogni altro periodo di esame successivo alla fine delle lezioni.

- Sosteniamo il diritto alla conoscenza