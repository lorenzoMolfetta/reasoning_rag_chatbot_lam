# Bando tirocini MAECI – Scadenza: 20 maggio

È online il bando di selezione per 14 tirocini curriculari della durata di tre mesi presso le Scuole italiane all’estero.

Pubblicato il
        06 maggio 2025

### Per maggiori informazioni:

- Link:

- Sosteniamo il diritto alla conoscenza