# Compilare il Piano di studi

Informazioni per preparare e presentare il piano di studi.

## Che cos'è il piano di studi

Il piano di studi è l'insieme di tutti gli esami che lo studente deve sostenere per potersi laureare. Alcuni esami sono obbligatori, mentre altri sono a scelta dello studente.

Lo studente può sostenere soltanto gli esami già presenti nel proprio piano di studi.

Per una presentazione dei due profili che possono essere approfonditi con le attività per la scelta guidata, si può consultare la pagina dedicata.

## Periodi di presentazione del piano di studi

Per l'A.A 2024/2025 le finestre di apertura sono le seguenti:

• I semestre: 07 ottobre - 10 novembre 2024
• II semestre: 10 febbraio - 07 marzo 2025

In tale periodo è possibile compilare via web oppure in modalità cartacea il piano di studi del corrente anno accademico o effettuare delle modifiche.

Accesso a StudentiOnLine

La compilazione e la presentazione del proprio piano di studi avviene accedendo al servizio Studenti Online con le proprie credenziali d’Ateneo. Il Servizio è attivo solo nei periodi in cui è consentita la presentazione.

## Chi può compilare il piano di studi on line

Possono compilare il piano di studio on line tutti gli studenti regolarmente iscritti in corso e fuori corso al corso di laurea magistrale, sia che abbiano effettuato passaggio che trasferimento o abbiano riconoscimenti da titoli precedenti.

Gli studenti iscritti al percorso flessibile/lungo o che intendono scegliere insegnamenti attivati presso Corsi di Studio a numero programmato devono compilare il piano di studio cartaceo, compilando il modulo scaricabile dalla sezione "Allegati" e inviandolo via e-mail alla Segreteria Studenti dalla casella di posta istituzionale all'indirizzo segcesena@unibo.it, sempre nelle scadenze previste.

N.B. Per quanto riguarda la scelta di attività libere tipologia D (12 cfu) lo studente ha la possibilità di scegliere tra gli insegnamenti consigliati e gli insegnamenti attivi in altri corsi di laurea magistrale dell’Ateneo.

Nel caso in cui la scelta ricada su insegnamenti attivi in corsi di laurea triennale dell’Ateneo, la stessa deve essere compilata con modulo cartaceo e sottoposta ad approvazione dal parte della Commissione Pratiche Studenti che ne valuterà la congruenza con il piano formativo complessivo.

Il modulo cartaceo deve essere inviato tramite e-mail istituzionale alla Segreteria Studenti all’indirizzo: segcesena@unibo.it comprensivo della lettera motivazionale, che viene richiesta per indicare ed illustrare brevemente le ragioni della scelta.

Prova finale

E’ obbligatorio, per poter chiudere correttamente, il piano di studi scegliere fin da ora come si vorrà svolgere la prova finale.
La prova finale è così regolata:

- GRUPPO A: PROVA FINALE 24 cfu

- GRUPPO B: PROVA FINALE 6 cfu + un’altra attività da massimo 18 cfu fra Preparazione prova finale all’estero o Tirocinio all'estero in preparazione della prova finale o Tirocinio in preparazione della prova finale.

Questa scelta non è vincolante e potrà essere cambiata in qualsiasi momento, anche con una comunicazione dall’email istituzionale alla segreteria studenti segcesena@unibo.it, prima di intraprendere la preparazione alla prova finale.

Preparazione prova finale all'estero
Lo studente di Laurea Magistrale può, se previsto nel piano didattico del suo corso di studio, scegliere l’attività di Preparazione della prova finale all'estero. Tale scelta implica che l’attività sia svolta nel corso di una mobilità Erasmus+ Studio o Overseas, oppure in seguito all'ottenimento di una Borsa di studio per tesi all'estero erogata dal Dipartimento, o attraverso altra mobilità comunque autorizzata dal Corso di studio. 
Se la decisione di effettuare l’attività di preparazione di tesi all'estero matura al di fuori dei periodi utili alla presentazione del piano di studio, lo studente potrà inserirla prevedendola all'interno del Learning Agreement, in caso di mobilità Erasmus+ Studio o Overseas, o facendone richiesta alla Segreteria Studenti in caso di mobilità in seguito all'ottenimento di Borsa di studio per tesi all'estero.

Tirocinio in preparazione della prova finale
Lo studente di Laurea Magistrale che intende svolgere il Tirocinio in preparazione della prova finale/ Tirocinio all'estero in preparazione della prova finale può inserirlo in carriera nei periodi di presentazione del piano di studio previsti dal corso di studio. 
Se la decisione di effettuare il tirocinio in preparazione della prova finale matura​ in un periodo al di fuori delle finestre di presentazione del piano di studio, l’attività formativa sarà inserita nel piano di studio dalla Segreteria Studenti contestualmente alla presentazione della richiesta di tirocinio sull'applicativo tirocini, contattando l'ufficio Tirocini di Campus.
Per il tirocinio all'estero in preparazione della prova finale svolto nell'ambito della mobilità Erasmus+ Traineeship, la relativa attività potrà essere inserita in piano di studio attraverso il Learning Agreement for Traineeship.

### ALLEGATI

- Modulo 8614 scelte

[
          .pdf
          172Kb
          ]
- Modulo 8614 percorso lungo/flessibile

[
          .pdf
          15Kb
          ]

### VEDI ANCHE

- Corsi a scelta
Attività per la scelta guidata degli insegnamenti nel secondo anno di corso.

### Contatti

#### Servizio didattico

Come ti può aiutare
                    Informazioni sull'orario delle lezioni, supporto per l’iscrizione agli appelli d’esame, compilazione del piano degli studi, riconoscimento dei crediti nel caso di trasferimenti o passaggi di corso e organizzazione delle sedute di laurea.

E-mail
campuscesena.didattica.isa@unibo.it

Telefono
+39 0547338300
Orario telefonico

Altre informazioni
Puoi contattarci via e-mail e via Teams. Scrivi una e-mail per informazioni o per un collegamento diretto tramite l'app Teams. Riceverai una e-mail con data, ora e link a cui collegarti dopo aver scaricato l'app.

#### Segreteria studenti

Come ti può aiutare
                    Iscrizioni, cambi di corso, trasferimenti da e verso altri atenei, laurea, diploma supplement e altre procedure.

Nome referente
                      Stefano Macrelli

Sportello virtuale

E-mail
segcesena@unibo.it

Indirizzo
Palazzo Urbinati - Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico

                            Mercoledì
                            9-12

Altre informazioni
Prendi un appuntamento via e-mail per la consegna dei documenti oppure inviali per posta.

- Sosteniamo il diritto alla conoscenza