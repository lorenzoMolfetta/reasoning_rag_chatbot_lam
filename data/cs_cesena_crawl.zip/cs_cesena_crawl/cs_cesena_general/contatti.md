# Contatti

- categoria
- nome

- Conciliare studio-lavoro, studio-sport






Servizio studente atleta





Come ti può aiutare:
                          Richiedere l’accesso al percorso "Dual Career Status Studente-Atleta" e conciliare studio universitario e carriera agonistica sportiva.
                        


Hai bisogno di chiarimenti


E-mail
studenteatleta@unibo.it





Servizio studente lavoratore





Come ti può aiutare:
                          Richiedere il riconoscimento dello "status di lavoratore".
                        


Hai bisogno di chiarimenti


E-mail
conciliazione.studiolavoro@unibo.it
- Iscrizione






Segreteria studenti





Come ti può aiutare:
                          Iscrizioni, cambi di corso, trasferimenti da e verso altri atenei, laurea, diploma supplement e altre procedure.
                        


Nome referente
                            Stefano Macrelli
                        


Hai bisogno di chiarimenti


Sportello virtuale



E-mail
segcesena@unibo.it

Hai bisogno di consegnare dei documenti


Indirizzo
Palazzo Urbinati - Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico

                                  Mercoledì
                                  9-12
                                


Altre informazioni
Prendi un appuntamento via e-mail per la consegna dei documenti oppure inviali per posta.





Supporto tecnico Studenti Online





Come ti può aiutare:
                          Problemi tecnici e richieste di assistenza sull'applicativo Studenti Online.
                        


Hai bisogno di chiarimenti


E-mail
help.studentionline@unibo.it



Telefono
+39 051 2080301
Orario telefonico

                                  Lunedì
                                  9-13 e 14-17
                                

                                  Martedì
                                  9-13 e 14-17
                                

                                  Mercoledì
                                  9-13 e 14-17
                                

                                  Giovedì
                                  9-13 e 14-17
                                

                                  Venerdì
                                  9-13 e 14-17
- Lezioni, esami, piano di studi e prova finale






Manager didattico





Come ti può aiutare:
                          Segnalazioni su aspetti logistici e organizzativi relativamente allo svolgimento delle attività del corso, informazioni generali su ammissioni, esami, orari, piano di studi e laurea.
                        


Nome referente
                            Enrica Zanelli
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.tutorltisi@unibo.it





Servizio didattico





Come ti può aiutare:
                          Informazioni sull'orario delle lezioni, supporto per l’iscrizione agli appelli d’esame, compilazione del piano degli studi, riconoscimento dei crediti nel caso di trasferimenti o passaggi di corso e organizzazione delle sedute di laurea.
                        


Hai bisogno di consegnare dei documenti


E-mail
campuscesena.didattica.isa@unibo.it



Telefono
+39 0547338300
Orario telefonico


Altre informazioni
Puoi contattarci via e-mail e via Teams. Scrivi una e-mail per informazioni o per un collegamento diretto tramite l'app Teams. Riceverai una e-mail con data, ora e link a cui collegarti dopo aver scaricato l'app.





Servizio per gli Studenti con Disabilità o con DSA





Come ti può aiutare:
                          Individuare le azioni necessarie per garantire ad ogni persona di studiare e sostenere esami e test nel modo più efficace.
                        


Nome referente
                            Silvia Mirri
                        


Hai bisogno di chiarimenti


Sportello virtuale



E-mail
disabilita@unibo.it;
                            
                              dsa@unibo.it;
                            
                              silvia.mirri@unibo.it



Telefono
+39 051 2080740
Orario telefonico

                                  Lunedì
                                  9:30-12
                                





Tutor del corso





Come ti può aiutare:
                          Dalla scelta del corso all’orario delle lezioni, dalla compilazione del piano di studi agli esami o alle indicazioni per la tesi. Studia come te, può consigliarti su come organizzare gli studi.
                        


Nome referente
                            Filippo Berveglieri
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.tutorltisi@unibo.it


Altre informazioni
Riceve su appuntamento tramite e-mail.
- Mobilità internazionale






Supporto didattico alla mobilità





Come ti può aiutare:
                          Informazioni relative alla didattica per programmi di mobilità europei ed extraeuropei, incoming e outgoing, Learning Agreement e riconoscimento crediti.
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.uri@unibo.it



Telefono
+39 0547 339006
Orario telefonico

                                  Lunedì
                                  10-12
                                

                                  Giovedì
                                  11-12
                                



Indirizzo
Palazzo Urbinati - Via Montalti 69, 47521 Cesena
Orario apertura al pubblico


Altre informazioni
Prenota per email un appuntamento online oppure, se sei incoming, un ricevimento in presenza.





Tutor per l'internazionalizzazione.





Come ti può aiutare:
                          Informazioni su opportunità di studio e ricerca all'estero e programmi di mobilità.
                        


Nome referente
                            Alberto Antonello
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.internazionalizzazioneingegneria@unibo.it


Altre informazioni
Riceve su appuntamento tramite email.
- Orientamento alla scelta del corso universitario






                        
                        Coordinatore del Corso
                      


Come ti può aiutare:
                          Informazioni sugli obiettivi e contenuti didattici del corso.
                        


Nome referente
                            Franco Callegati
                        

Sito web





Manager didattico





Come ti può aiutare:
                          Segnalazioni su aspetti logistici e organizzativi relativamente allo svolgimento delle attività del corso, informazioni generali su ammissioni, esami, orari, piano di studi e laurea.
                        


Nome referente
                            Enrica Zanelli
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.tutorltisi@unibo.it





Rappresentante degli studenti





Come ti può aiutare:
                          Si fa portavoce dei bisogni, delle segnalazioni e dei progetti della comunità studentesca  presso il Consiglio di corso.
                        


Nome referente
                            Giacomo Antonelli
                        


Hai bisogno di chiarimenti


E-mail
giacomo.antonelli4@studio.unibo.it





Servizio Orientamento





Come ti può aiutare:
                          Scelta del corso di studio, inserimento nella vita universitaria anche con eventi di orientamento.
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.orientamentourp@unibo.it



Telefono
+39 0547 338900
Orario telefonico

                                  Lunedì
                                  9-11:30
                                

                                  Martedì
                                  9-11:30
                                

                                  Mercoledì
                                  9-11:30
                                

                                  Giovedì
                                  13:30-15:30
                                



Indirizzo
Via Montalti 69, Cesena
Orario apertura al pubblico





Servizio per gli Studenti con Disabilità o con DSA





Come ti può aiutare:
                          Individuare le azioni necessarie per garantire ad ogni persona di studiare e sostenere esami e test nel modo più efficace.
                        


Nome referente
                            Silvia Mirri
                        


Hai bisogno di chiarimenti


Sportello virtuale



E-mail
disabilita@unibo.it;
                            
                              dsa@unibo.it;
                            
                              silvia.mirri@unibo.it



Telefono
+39 051 2080740
Orario telefonico

                                  Lunedì
                                  9:30-12
                                





Tutor di Orientamento





Come ti può aiutare:
                          Scelta più consapevole del percorso di studi, indicazioni sulle modalità per iscriverti.
                        


Nome referente
                            Elvis Perlika
                        

Sito web




Altre informazioni
Il Tutor riceve su appuntamento tramite email: elvis.perlika2@unibo.it
Live chat: Mercoledì dalle 18.00 alle 19.00 (al link nella sezione Sito Web)





                        
                        Tutor di orientamento
                      


Come ti può aiutare:
                          Scelta più consapevole del percorso di studi, indicazioni sulle modalità per iscriverti.
- Orientamento verso il mondo del lavoro






Job placement





Come ti può aiutare:
                          Conoscere iniziative per la crescita professionale, incontrare imprese per le opportunità di lavoro.
                        


Hai bisogno di chiarimenti


E-mail
Jobplacement@unibo.it



Telefono
+39 051 2088564;
                            
                              +39 051 2099783;
                            
                              +39 051 2099872;
                            
                              +39 051 2098931
Orario telefonico



Indirizzo
Palazzo Paleotti - Largo Trombetti, 1 40126 – Bologna
Orario apertura al pubblico





Servizio Orientamento al lavoro





Come ti può aiutare:
                          Costruire il tuo curriculum vitae e profilo Linkedin, prepararti per colloqui professionali, impostare efficacemente la ricerca del lavoro.
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.orientamentourp@unibo.it



Telefono
+39 0547 338900
Orario telefonico

                                  Lunedì
                                  9-11:30
                                

                                  Martedì
                                  9-11:30
                                

                                  Mercoledì
                                  9-11:30
                                

                                  Giovedì
                                  13:30-15:30
                                



Indirizzo
Via Montalti n. 69 - 47521 Cesena (FC)
Orario apertura al pubblico
- Riprendere, prolungare o lasciare gli studi






Segreteria studenti





Come ti può aiutare:
                          Iscrizioni, cambi di corso, trasferimenti da e verso altri atenei, laurea, diploma supplement e altre procedure.
                        


Nome referente
                            Stefano Macrelli
                        


Hai bisogno di chiarimenti


Sportello virtuale



E-mail
segcesena@unibo.it

Hai bisogno di consegnare dei documenti


Indirizzo
Palazzo Urbinati - Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico

                                  Mercoledì
                                  9-12
                                


Altre informazioni
Prendi un appuntamento via e-mail per la consegna dei documenti oppure inviali per posta.





Servizio didattico





Come ti può aiutare:
                          Informazioni sull'orario delle lezioni, supporto per l’iscrizione agli appelli d’esame, compilazione del piano degli studi, riconoscimento dei crediti nel caso di trasferimenti o passaggi di corso e organizzazione delle sedute di laurea.
                        


Hai bisogno di consegnare dei documenti


E-mail
campuscesena.didattica.isa@unibo.it



Telefono
+39 0547338300
Orario telefonico


Altre informazioni
Puoi contattarci via e-mail e via Teams. Scrivi una e-mail per informazioni o per un collegamento diretto tramite l'app Teams. Riceverai una e-mail con data, ora e link a cui collegarti dopo aver scaricato l'app.
- Supporto per la Carriera alias






                        
                        Servizio carriere alias
                      


Come ti può aiutare:
                          Attivazione di una carriera alias, cioè la sostituzione del proprio nome anagrafico con un nome di elezione.
                        


Hai bisogno di chiarimenti


Sportello virtuale
- Tasse, esoneri e borse di studio






                        
                        ErGO – Azienda Regionale per il Diritto agli Studi Superiori
                      


Come ti può aiutare:
                          Conoscere i benefici per il Diritto allo Studio: borse di studio, alloggi e mense.
                        

Sito web





Settore Diritto allo studio





Come ti può aiutare:
                          Informazioni su servizi e opportunità messi a disposizione dall’Ateneo.
                        


Hai bisogno di chiarimenti


Sportello virtuale



E-mail
uborstudio@unibo.it





Ufficio contribuzioni studentesche





Come ti può aiutare:
                          Chiarimenti su tasse e esenzioni, importi, scadenze e documenti da presentare.
                        


Hai bisogno di chiarimenti


Sportello virtuale



E-mail
ases.contribuzionistudentesche@unibo.it
- Tirocinio






Ufficio tirocini





Come ti può aiutare:
                          Attivare e gestire un tirocinio curriculare o in preparazione della tesi finale, in Italia e all’estero, al di fuori dei programmi di mobilità internazionale.
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.tirocini@unibo.it



Telefono
+39 0547 338914
Orario telefonico

                                  Lunedì
                                  11-12
                                

                                  Martedì
                                  11-12
                                

                                  Mercoledì
                                  11-12
                                

                                  Giovedì
                                  11-12
                                



Indirizzo
Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico


Altre informazioni
Prenota per email o telefono un appuntamento online o in presenza.
- Trasferimenti, cambi di corso o passaggi






Manager didattico





Come ti può aiutare:
                          Segnalazioni su aspetti logistici e organizzativi relativamente allo svolgimento delle attività del corso, informazioni generali su ammissioni, esami, orari, piano di studi e laurea.
                        


Nome referente
                            Enrica Zanelli
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.tutorltisi@unibo.it





Segreteria studenti





Come ti può aiutare:
                          Iscrizioni, cambi di corso, trasferimenti da e verso altri atenei, laurea, diploma supplement e altre procedure.
                        


Nome referente
                            Stefano Macrelli
                        


Hai bisogno di chiarimenti


Sportello virtuale



E-mail
segcesena@unibo.it

Hai bisogno di consegnare dei documenti


Indirizzo
Palazzo Urbinati - Via Montalti 69 - 47521 Cesena FC
Orario apertura al pubblico

                                  Mercoledì
                                  9-12
                                


Altre informazioni
Prendi un appuntamento via e-mail per la consegna dei documenti oppure inviali per posta.





Servizio didattico





Come ti può aiutare:
                          Informazioni sull'orario delle lezioni, supporto per l’iscrizione agli appelli d’esame, compilazione del piano degli studi, riconoscimento dei crediti nel caso di trasferimenti o passaggi di corso e organizzazione delle sedute di laurea.
                        


Hai bisogno di consegnare dei documenti


E-mail
campuscesena.didattica.isa@unibo.it



Telefono
+39 0547338300
Orario telefonico


Altre informazioni
Puoi contattarci via e-mail e via Teams. Scrivi una e-mail per informazioni o per un collegamento diretto tramite l'app Teams. Riceverai una e-mail con data, ora e link a cui collegarti dopo aver scaricato l'app.
- Vuoi inviare suggerimenti o segnalazioni






                        
                        Coordinatore del Corso
                      


Come ti può aiutare:
                          Informazioni sugli obiettivi e contenuti didattici del corso.
                        


Nome referente
                            Franco Callegati
                        

Sito web





Garante degli studenti





Come ti può aiutare:
                          Segnalare disfunzioni, carenze o comportamenti che violino la legge o i principi di buona amministrazione in Ateneo.
                        


Hai bisogno di chiarimenti


E-mail
garante@unibo.it





Manager didattico





Come ti può aiutare:
                          Segnalazioni su aspetti logistici e organizzativi relativamente allo svolgimento delle attività del corso, informazioni generali su ammissioni, esami, orari, piano di studi e laurea.
                        


Nome referente
                            Enrica Zanelli
                        


Hai bisogno di chiarimenti


E-mail
campuscesena.tutorltisi@unibo.it





Rappresentante degli studenti





Come ti può aiutare:
                          Si fa portavoce dei bisogni, delle segnalazioni e dei progetti della comunità studentesca  presso il Consiglio di corso.
                        


Nome referente
                            Giacomo Antonelli
                        


Hai bisogno di chiarimenti


E-mail
giacomo.antonelli4@studio.unibo.it

- Sosteniamo il diritto alla conoscenza