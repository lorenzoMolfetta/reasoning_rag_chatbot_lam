# Orario delle lezioni

Consulta il calendario delle lezioni in base all'anno a cui sei iscritto.

Le lezioni nel prossimo a.a. 2024/25 si svolgeranno in presenza.

Consulta il Calendario Didattico delle lezioni del Corso di Studio.

Gli orari di lezione del 1° Anno - Ingegneria e scienze informatiche (codice 8615)

I dati possono subire variazioni. Controlla questa pagina frequentemente.

- ALGEBRA E GEOMETRIA / (1) Modulo 1
- ALGEBRA E GEOMETRIA / (2) Modulo 2
- ALGORITMI E STRUTTURE DATI / (CL.A) / (1) Modulo 1
- ALGORITMI E STRUTTURE DATI / (CL.A) / (2) Modulo 2
- ALGORITMI E STRUTTURE DATI / (CL.B) / (1) Modulo 1
- ALGORITMI E STRUTTURE DATI / (CL.B) / (2) Modulo 2
- ANALISI MATEMATICA / (1) Modulo 1
- ANALISI MATEMATICA / (2) Modulo 2
- ANALISI MATEMATICA / (3) Modulo 3
- ARCHITETTURE DEGLI ELABORATORI / (CL.A) / (1) Modulo 1
- ARCHITETTURE DEGLI ELABORATORI / (CL.A) / (2) Modulo 2
- ARCHITETTURE DEGLI ELABORATORI / (CL.B) / (1) Modulo 1
- ARCHITETTURE DEGLI ELABORATORI / (CL.B) / (2) Modulo 2
- PROGRAMMAZIONE / (CL.A) / (1) Modulo 1
- PROGRAMMAZIONE / (CL.A) / (2) Modulo 2
- PROGRAMMAZIONE / (CL.B) / (1) Modulo 1
- PROGRAMMAZIONE / (CL.B) / (2) Modulo 2

12 Dicembre 2017 09:00 - 11:30

Crediti formativi:
                                                                9

Periodo di lezione:
                                                                September 2017 - 18 December 2017

Docente:
                                                                ORESTE ANDRISANO

Luogo:
                                                                AULA 4.1 - Piano Terra - Viale del Risorgimento 2 - Bologna

Si segnala che la lezione avrà inizio anticipato alle 8.45

### MATRICOLE CLASSE A e B

- Matricole Classe A - A.A. 2024/2025

[
          .pdf
          27Kb
          ]
La Classe A è già completa.
- Matricole Classe B - A.A. 2024/2025

[
          .pdf
          27Kb
          ]
La Classe B si completerà con gli iscritti di settembre 2024.
- Matricole Classe A - A.A. 2023/2024

[
          .pdf
          27Kb
          ]
- Matricole Classe B - A.A. 2023/2024

[
          .pdf
          27Kb
          ]
- Matricole Classe A - A.A. 2022/2023

[
          .pdf
          26Kb
          ]
- Matricole Classe B - A.A. 2022/2023

[
          .pdf
          26Kb
          ]
- Matricole Classe A - A.A. 2021/2022

[
          .pdf
          26Kb
          ]
- Matricole Classe B - A.A. 2021/2022

[
          .pdf
          26Kb
          ]

### ORARIO DELLE LEZIONI

- Orario lezioni Idoneità di Lingua Inglese B-2

- Sosteniamo il diritto alla conoscenza