# Iscriversi al Corso: requisiti, tempi e modalità

## I passi principali da seguire

1. Requisiti

Verifica cosa serve per accedere.
2. Test di accesso

Sostieni il TOLC e iscriviti a una selezione.
3. Graduatoria

Controlla l'esito della selezione.
4. Immatricolazione

Completa la tua iscrizione.

Di seguito alcune informazioni su come iscriverti, che troverai dettagliate nel bando, che cambiano a seconda della tua cittadinanza.
Se hai dei dubbi verifica il percorso da seguire.

## Requisiti

- Informazioni generali sui requisiti di accesso




                          Requisiti per l'accesso al corso
Per essere ammessi al corso di laurea in Ingegneria e Scienze Informatiche, occorre essere in possesso di un diploma di scuola secondaria superiore o di altro titolo di studio conseguito all'estero, riconosciuti idonei secondo la normativa vigente.
Sono inoltre richieste le seguenti conoscenze e competenze: una buona cultura generale, capacità di ragionamento logico e di comprensione del testo, una buona conoscenza delle nozioni fondamentali della matematica e delle scienze sperimentali.

Le modalità di verifica delle conoscenze richieste per l’accesso sono definite nel Regolamento didattico del Corso di Studio.
Se la verifica non è positiva vengono indicati specifici Obblighi Formativi Aggiuntivi (OFA), il cui assolvimento è oggetto di specifica verifica.
La relativa modalità di accertamento è indicata nel Regolamento didattico del Corso di Studio.
Gli studenti che non assolvano agli OFA entro la data stabilita dagli Organi competenti e comunque entro il primo anno di corso devono ripetere l’iscrizione al medesimo anno.

## Requisiti

- Titolo di studio richiesto Per accedere al corso devi possedere:

### Titolo di studio richiesto

Per accedere al corso devi possedere:

- Diploma di istruzione secondaria superiore di durata quinquennale (compresi istituti magistrali e licei artistici con superamento del corso annuale integrativo).
- Diploma sperimentale in 4 anni, rilasciato dagli istituti ammessi al piano nazionale per la sperimentazione di percorsi quadriennali di istruzione secondaria di secondo grado.
- Diploma rilasciato da istituti di istruzione secondaria superiore di durata quadriennale presso i quali non sia attivo l’anno integrativo. Con questo titolo hai l’obbligo di assolvere entro il 31 marzo 2026, presso l’Ateneo di Bologna, lo specifico debito formativo aggiuntivo, il cui mancato superamento comporterà, nell’anno accademico successivo, l’iscrizione al primo anno come ripetente.
- Titolo conseguito all'estero al termine di un periodo scolastico di almeno dodici anni, che consenta l'accesso alla formazione universitaria in Italia secondo la normativa italiana, gli accordi internazionali vigenti e le disposizione contenute nella circolare MUR “Procedure per l’ingresso, il soggiorno, l’immatricolazione degli studenti internazionali e il relativo riconoscimento dei titoli, per i corsi accademici della Formazione Superiore valide per l’anno accademico 2025/2026” pubblicata sul sito di Universitaly.
Approfondisci

Conoscenza della lingua inglese



Nel TOLC è presente una sezione di verifica delle conoscenze della lingua inglese. Tale sezione non è obbligatoria, è meramente auto-valutativa.
Il punteggio ottenuto in questa sezione non concorre a formare il punteggio che sarà considerato per la graduatoria.

Conoscenza della lingua italiana Per accedere al corso devi soddisfare il requisito di conoscenza della lingua italiana e puoi farlo in due modi: Per maggiori dettagli e scadenze

### Conoscenza della lingua italiana

Per accedere al corso devi soddisfare il requisito di conoscenza della lingua italiana e puoi farlo in due modi:

- superando una prova di lingua italiana organizzata dall’Università di Bologna;
- presentando un valido certificato di conoscenza della lingua italiana o un titolo di scuola superiore ottenuto in lingua italiana. Se presenti un certificato o un titolo di studio in lingua italiana verifica anche se devi concorrere con i cittadini italiani e UE.

Per maggiori dettagli e scadenze

## Per cominciare

- Borse di studio, esoneri e incentivi



Puoi contare su sostegni economici già all'inizio del tuo percorso. In base alla tua situazione economica, al merito o a determinati requisiti puoi far domanda per ottenere una riduzione o un esonero sulla tassa di iscrizione.
Scopri le opportunità
- Tasse e importi



L'importo delle tasse è calcolato in base all’attestazione ISEE 2025 per prestazioni agevolate di diritto allo studio. È previsto l’esonero totale per le matricole con ISEE basso.
L'attestazione ISEE deve essere inserita entro il 30 ottobre 2025 ore 18:00 (o entro il 17 novembre 2025 ore 18:00 con una mora di 100 €) accedendo ai Servizi online di ER.GO, altrimenti dovrai versare l'importo massimo.
Se non puoi ottenere l'ISEE, verifica come viene calcolato l'importo delle tasse a seconda del Paese da cui provieni e da dove la tua famiglia ha redditi e patrimoni.
Consulta tutte le informazioni su Tasse ed esoneri.

Ricordati
Di preparare i documenti e presentare le domande per borse di studio e altre  agevolazioni. In base alla tua condizione economica, puoi ottenere borse di studio, alloggio negli studentati, un’esenzione totale o parziale dalle tasse e altre agevolazioni. Per farne richiesta dovrai preparare la documentazione sui redditi e i patrimoni della tua famiglia.
- Copertura sanitaria Dall'arrivo in Italia e per tutto il tuo soggiorno devi avere una copertura sanitaria. Hai diverse opzioni: Tessera TEAM, Assicurazione privata o Iscrizione al Sistema Sanitario Nazionale italiano (SSN). Se possiedi la tessera TEAM Se sei in possesso della tessera sanitaria europea (TEAM) del tuo Paese UE di provenienza in corso di validità, puoi ricevere tutte le prestazioni sanitarie medicalmente necessarie. Per ottenere le prestazioni, puoi recarti direttamente presso un medico o una struttura sanitaria pubblica o convenzionata ed esibire la TEAM. L’assistenza è in forma diretta e pertanto nulla è dovuto, eccetto il pagamento di un eventuale contributo (“ticket”) che è a tuo carico e non rimborsabile. Con la TEAM puoi andare direttamente da un medico di base (detto anche medico di famiglia), scegliendolo dall’elenco dei medici di medicina generale (MMG) convenzionati disponibile sui siti Salute Bologna , se studi a Bologna, o dell'AUSL della Romagna , se studi negli altri campus. Con la tessera TEAM Card non puoi accedere alle cure "programmate all'estero", ossia prevedibili (es. cure dentarie non urgenti, cure termali, ecc.). Se possiedi un Attestato di diritto (es. E106, E109, etc.) Se sei in possesso di un attestato di diritto diverso dalla TEAM, di norma, per poter usufruire dell’assistenza sanitaria, devi preventivamente presentare tale attestato a uno degli Sportelli Unici dell’AUSL (CUP) , che verifica se è possibile iscriverti al Servizio Sanitario Nazionale (SSN) e in tal caso avrai diritto ad un’assistenza sanitaria completa alle stesse condizioni previste per i cittadini italiani. Il modo per accedere all’assistenza può variare a seconda dell’attestato di diritto in tuo possesso. Chiedi maggiori informazioni allo Sportello Unico (CUP) al momento dell’iscrizione. Consulta l’elenco degli Sportelli Unici (CUP) di Bologna , e della Romagna (province di Cesena, Forlì, Ravenna e Rimini). Altri casi Nel caso in cui tu non abbia né la tessera TEAM né un Attestato di diritto, devi stipulare un’assicurazione sanitaria privata valida in Italia o iscriverti al Servizio Sanitario Nazionale (SSN) italiano, dove previsto. Se hai un’assicurazione sanitaria privata , puoi andare da qualsiasi medico di base. Nel caso tu abbia bisogno di una visita specialistica, puoi scegliere tu direttamente a quale medico rivolgerti, eventualmente facendoti consigliare dal medico di base.Le polizze sanitarie private: Se il tuo soggiorno è per motivi di studio, verifica presso uno degli Sportelli Unici dell’AUSL (CUP) se puoi iscriverti al SSN . Per effettuare l’iscrizione volontaria al SSN da studente devi essere residente in Italia e pagare un contributo forfettario annuale non frazionabile di minimo 700 €.L’iscrizione al SSN viene effettuata per anno solare, dal 1° gennaio al 31 dicembre. Se fai un lavoro subordinato o autonomo e paghi le tasse in Italia hai diritto all’iscrizione obbligatoria e gratuita al Servizio Sanitario Nazionale . Verifica presso uno degli Sportelli Unici dell’AUSL (CUP) come iscriverti al SSN. Se sei residente in Italia da almeno 5 anni , puoi richiedere al Comune di residenza l’"Attestato di Soggiorno Permanente" che dà diritto all’iscrizione al Servizio Sanitario Nazionale italiano (SSN) con scelta del medico di base, a tempo indeterminato. Verifica presso uno degli Sportelli Unici dell’AUSL (CUP) come iscriverti al SSN. Come effettuare l’iscrizione volontaria al Servizio Sanitario Nazionale da studente Per chi richiede o possiede un permesso di soggiorno per motivi di studio, dal 2024 il costo minimo è di 700 € all’anno. L’iscrizione è fatta solo per anno solare (per es. dal 1° gennaio 2024 al 31 dicembre 2024) e non è possibile pagare quote ridotte per periodi più brevi. È consentito pagare l’iscrizione per l’anno corrente e anche per l’intero anno solare successivo (ad es. 2024 e 2025). Questa possibilità permette di avere la copertura sanitaria per un anno accademico ed è utile per gli studenti che arrivano, ad esempio, a settembre e intendono chiedere un permesso di soggiorno per studio valido un anno. Per la copertura di eventuali familiari a carico l’importo del contributo minimo è di 2000 € all’anno. Per iscriverti: Vai ad uno Sportello Unico dell’AUSL (CUP) . Consulta la lista degli Sportelli Unici (CUP) di Bologna , e della Romagna (province di Cesena, Forlì, Ravenna e Rimini). Porta con te: Chiedi le informazioni per effettuare il pagamento per l’iscrizione volontaria per studenti; ricorda che il pagamento deve essere fatto tramite il modello F24 ordinario .Devi compilare le parti: Paga il contributo annuale presentando il modello F24 per ciascun anno di iscrizione al SSN presso gli uffici postali, gli sportelli bancari, online tramite il tuo conto corrente o carte Pagobancomat, Postepay o Postamat e conserva le ricevute di pagamento. Fai una copia delle ricevute di pagamento e allegale alla tua domanda di primo rilascio o di rinnovo del permesso di soggiorno. Dopo aver inviato la domanda di permesso di soggiorno, ritorna il più presto possibile allo Sportello Unico (CUP) per attivare la copertura sanitaria e scegliere un medico di base.Porta con te: Il solo pagamento non implica l’attivazione della copertura . Devi completare l’iscrizione presso un ufficio dell’AUSL e scegliere un medico di base. Se paghi per due anni consecutivi, ricordati che alla fine dell’anno in corso devi tornare al CUP con la ricevuta di pagamento per l’anno successivo, e chiedere l’attivazione del servizio. Verifica sempre la data di fine copertura. Gli iscritti e le iscritte all’SSN ricevono per posta una Tessera Sanitaria. La tessera viene spedita all’indirizzo comunicato all’Agenzia delle Entrate; puoi contattare l’Agenzia delle Entrate per l’aggiornamento del tuo indirizzo e per richiedere la ristampa della tessera .

### Copertura sanitaria

Dall'arrivo in Italia e per tutto il tuo soggiorno devi avere una copertura sanitaria. Hai diverse opzioni: Tessera TEAM, Assicurazione privata o Iscrizione al Sistema Sanitario Nazionale italiano (SSN).

### Se possiedi la tessera TEAM

Se sei in possesso della tessera sanitaria europea (TEAM) del tuo Paese UE di provenienza in corso di validità, puoi ricevere tutte le prestazioni sanitarie medicalmente necessarie.

Per ottenere le prestazioni, puoi recarti direttamente presso un medico o una struttura sanitaria pubblica o convenzionata ed esibire la TEAM. L’assistenza è in forma diretta e pertanto nulla è dovuto, eccetto il pagamento di un eventuale contributo (“ticket”) che è a tuo carico e non rimborsabile.

Con la TEAM puoi andare direttamente da un medico di base (detto anche medico di famiglia), scegliendolo dall’elenco dei medici di medicina generale (MMG) convenzionati disponibile sui siti Salute Bologna, se studi a Bologna, o dell'AUSL della Romagna, se studi negli altri campus.

Con la tessera TEAM Card non puoi accedere alle cure "programmate all'estero", ossia prevedibili (es. cure dentarie non urgenti, cure termali, ecc.).

### Se possiedi un Attestato di diritto (es. E106, E109, etc.)

Se sei in possesso di un attestato di diritto diverso dalla TEAM, di norma, per poter usufruire dell’assistenza sanitaria, devi preventivamente presentare tale attestato a uno degli Sportelli Unici dell’AUSL (CUP), che verifica se è possibile iscriverti al Servizio Sanitario Nazionale (SSN) e in tal caso avrai diritto ad un’assistenza sanitaria completa alle stesse condizioni previste per i cittadini italiani.

Il modo per accedere all’assistenza può variare a seconda dell’attestato di diritto in tuo possesso. Chiedi maggiori informazioni allo Sportello Unico (CUP) al momento dell’iscrizione.

Consulta l’elenco degli Sportelli Unici (CUP) di Bologna, e della Romagna (province di Cesena, Forlì, Ravenna e Rimini).

### Altri casi

Nel caso in cui tu non abbia né la tessera TEAM né un Attestato di diritto, devi stipulare un’assicurazione sanitaria privata valida in Italia o iscriverti al Servizio Sanitario Nazionale (SSN) italiano, dove previsto.

Se hai un’assicurazione sanitaria privata, puoi andare da qualsiasi medico di base. Nel caso tu abbia bisogno di una visita specialistica, puoi scegliere tu direttamente a quale medico rivolgerti, eventualmente facendoti consigliare dal medico di base.
Le polizze sanitarie private:

- non prevedono l’iscrizione al SSN né l’assegnazione di un medico di base;
- di norma prevedono che l’utente paghi le spese e poi chieda il rimborso alla compagnia assicurativa.
Quando acquisti la polizza verifica con attenzione le modalità e i limiti dei rimborsi. Ricordati che le spese sanitarie da anticipare potrebbero essere molto alte, ad esempio in caso di ricovero ospedaliero. È consigliabile verificare in anticipo, contattando la tua compagnia di assicurazione, se il tipo di prestazione di cui hai bisogno sia rimborsabile.

Se il tuo soggiorno è per motivi di studio, verifica presso uno degli Sportelli Unici dell’AUSL (CUP) se puoi iscriverti al SSN. Per effettuare l’iscrizione volontaria al SSN da studente devi essere residente in Italia e pagare un contributo forfettario annuale non frazionabile di minimo 700 €.
L’iscrizione al SSN viene effettuata per anno solare, dal 1° gennaio al 31 dicembre.

Se fai un lavoro subordinato o autonomo e paghi le tasse in Italia hai diritto all’iscrizione obbligatoria e gratuita al Servizio Sanitario Nazionale. Verifica presso uno degli Sportelli Unici dell’AUSL (CUP) come iscriverti al SSN.

Se sei residente in Italia da almeno 5 anni, puoi richiedere al Comune di residenza l’"Attestato di Soggiorno Permanente" che dà diritto all’iscrizione al Servizio Sanitario Nazionale italiano (SSN) con scelta del medico di base, a tempo indeterminato. Verifica presso uno degli Sportelli Unici dell’AUSL (CUP) come iscriverti al SSN.

### Come effettuare l’iscrizione volontaria al Servizio Sanitario Nazionale da studente

Per chi richiede o possiede un permesso di soggiorno per motivi di studio, dal 2024 il costo minimo è di 700 € all’anno. L’iscrizione è fatta solo per anno solare (per es. dal 1° gennaio 2024 al 31 dicembre 2024) e non è possibile pagare quote ridotte per periodi più brevi.

È consentito pagare l’iscrizione per l’anno corrente e anche per l’intero anno solare successivo (ad es. 2024 e 2025). Questa possibilità permette di avere la copertura sanitaria per un anno accademico ed è utile per gli studenti che arrivano, ad esempio, a settembre e intendono chiedere un permesso di soggiorno per studio valido un anno.

Per la copertura di eventuali familiari a carico l’importo del contributo minimo è di 2000 € all’anno.

Per iscriverti:

Vai ad uno Sportello Unico dell’AUSL (CUP). Consulta la lista degli Sportelli Unici (CUP) di Bologna, e della Romagna(province di Cesena, Forlì, Ravenna e Rimini).  
Porta con te:

- il tuo passaporto;
- il tuo codice fiscale ufficiale italiano;
- certificato di iscrizione all’Università di Bologna o, per studenti di scambio, la Dichiarazione di arrivo;
- per gli Sportelli Unici (CUP) di Bologna, il modulo di iscrizione volontaria [.pdf 967 KB] per cittadini non-UE; qui puoi trovare un esempio con istruzioni per la compilazione [.pdf 371 KB].

Chiedi le informazioni per effettuare il pagamento per l’iscrizione volontaria per studenti; ricorda che il pagamento deve essere fatto tramite il modello F24 ordinario.
Devi compilare le parti:

- “contribuente” indicando i tuoi dati anagrafici;
- “sezione regioni” indicando codice regione 06 (Emilia-Romagna), codice tributo 8846;
- anno di riferimento: l’anno solare in cui vuoi iscriverti al SSN, ad esempio 2024;
- importi a debito versati: 700 €, se non hai altri redditi oltre alla borsa di studio e non vuoi includere nella copertura i tuoi famigliari. Se vuoi iscriverti per due anni consecutivi (ad esempio 2024 e 2025), devi fare due pagamenti.

Paga il contributo annuale presentando il modello F24 per ciascun anno di iscrizione al SSN presso gli uffici postali, gli sportelli bancari, online tramite il tuo conto corrente o carte Pagobancomat, Postepay o Postamat e conserva le ricevute di pagamento.

Fai una copia delle ricevute di pagamento e allegale alla tua domanda di primo rilascio o di rinnovo del permesso di soggiorno.

Dopo aver inviato la domanda di permesso di soggiorno, ritorna il più presto possibile allo Sportello Unico (CUP) per attivare la copertura sanitaria e scegliere un medico di base.
Porta con te:

- le ricevute di pagamento del contributo annuale;
- la ricevuta postale della domanda di permesso di soggiorno (o il permesso di soggiorno se già ottenuto);
- certificato di iscrizione all’Università di Bologna o, per studenti di scambio, la Dichiarazione di arrivo.

Il solo pagamento non implica l’attivazione della copertura. Devi completare l’iscrizione presso un ufficio dell’AUSL e scegliere un medico di base.

Se paghi per due anni consecutivi, ricordati che alla fine dell’anno in corso devi tornare al CUP con la ricevuta di pagamento per l’anno successivo, e chiedere l’attivazione del servizio.

Verifica sempre la data di fine copertura.

Gli iscritti e le iscritte all’SSN ricevono per posta una Tessera Sanitaria. La tessera viene spedita all’indirizzo comunicato all’Agenzia delle Entrate; puoi contattare l’Agenzia delle Entrate per l’aggiornamento del tuo indirizzo e per richiedere la ristampa della tessera.

Codice fiscale italiano



Per studiare in Italia dovrai richiedere un codice fiscale italiano. Rivolgiti in autonomia all'Agenzia delle Entrate oppure contattaci per avere il nostro aiuto per ottenerlo. Il codice ti sarà utile se vuoi anche per iscriverti al Servizio Sanitario Nazionale (SSN).

Presentazione del titolo di studio estero



Il titolo di studio che dichiarerai di possedere in fase di ammissione verrà controllato dalla Segreteria studenti Internazionali del campus di riferimento dopo la richiesta di immatricolazione e la presentazione in originale di tutti i documenti necessari richiesti.  
Ti consigliamo di presentarli alla Segreteria studenti internazionali il più presto possibile per un controllo preliminare e per ottenere, se ti serve, la validazione senza riserva della preiscrizione.

Codice fiscale italiano



Per studiare in Italia dovrai richiedere un codice fiscale italiano. Rivolgiti in autonomia all'Agenzia delle Entrate oppure contattaci per avere il nostro aiuto per ottenerlo. Il codice ti sarà utile se vuoi anche per iscriverti al Servizio Sanitario Nazionale (SSN).

Presentazione del titolo di studio estero



Il titolo di studio che dichiarerai di possedere in fase di ammissione verrà controllato dalla segreteria studenti internazionali del campus di riferimento dopo la richiesta di immatricolazione e la presentazione in originale di tutti i documenti necessari richiesti.
Ti consigliamo di presentarli alla Segreteria studenti internazionali il più presto possibile per un controllo preliminare e per ottenere, se ti serve, la validazione senza riserva della preiscrizione.

## TOLC

- In cosa consiste




Il Test Online Cisia (TOLC) è uno strumento di orientamento e valutazione delle capacità iniziali. 
È un test individuale, diverso per ogni partecipante, composto da quesiti selezionati automaticamente e casualmente dal database CISIA TOLC con un software realizzato e gestito dal CISIA - Consorzio Interuniversitario Sistemi Integrati per l'Accesso.
Per questo corso dovrai sostenere il TOLC-I, composto da 50 quesiti (10 di logica, 10 scienze, 10 di comprensione verbale, 20 di matematica) con durata di 110 minuti.
Al termine di ciascun test è prevista una sezione aggiuntiva di inglese. Il punteggio ottenuto in questa sezione non concorre a formare il punteggio che sarà considerato per la graduatoria.
- Dove sostenerlo Puoi svolgere il TOLC in qualsiasi sede universitaria, anche diversa da quella in cui vuoi immatricolarti. Trovi date e sedi per sostenere il TOLC sul sito del CISIA . L’Università di Bologna organizza TOLC solo in presenza presso tutte le proprie sedi (Bologna, Cesena, Forlì, Ravenna, Rimini). Quali TOLC sono validi Per questo corso sono validi:

### Dove sostenerlo

Puoi svolgere il TOLC in qualsiasi sede universitaria, anche diversa da quella in cui vuoi immatricolarti. Trovi date e sedi per sostenere il TOLC sul sito del CISIA.

L’Università di Bologna organizza TOLC solo in presenza presso tutte le proprie sedi (Bologna, Cesena, Forlì, Ravenna, Rimini).

#### Quali TOLC sono validi

Per questo corso sono validi:

- TOLC in presenza (TOLC@UNI) svolti nel 2024 o nel 2025

Dove sostenerlo Puoi svolgere il TOLC in qualsiasi sede universitaria, anche diversa da quella in cui vuoi immatricolarti. Trovi date e sedi per sostenere il TOLC sul sito del CISIA . L’Università di Bologna organizza TOLC solo in presenza presso tutte le proprie sedi (Bologna, Cesena, Forlì, Ravenna, Rimini). Quali TOLC sono validi Per questo corso sono validi:

### Dove sostenerlo

Puoi svolgere il TOLC in qualsiasi sede universitaria, anche diversa da quella in cui vuoi immatricolarti. Trovi date e sedi per sostenere il TOLC sul sito del CISIA.

L’Università di Bologna organizza TOLC solo in presenza presso tutte le proprie sedi (Bologna, Cesena, Forlì, Ravenna, Rimini).

#### Quali TOLC sono validi

Per questo corso sono validi:

- TOLC in presenza (TOLC@UNI) svolti nel 2024 o nel 2025

Dove sostenerlo Puoi svolgere il TOLC in qualsiasi sede universitaria, anche diversa da quella in cui vuoi immatricolarti. Trovi date e sedi per sostenere il TOLC sul sito del CISIA . L’Università di Bologna organizza TOLC solo in presenza presso tutte le proprie sedi (Bologna, Cesena, Forlì, Ravenna, Rimini). Quali TOLC sono validi Per questo corso sono validi:

### Dove sostenerlo

Puoi svolgere il TOLC in qualsiasi sede universitaria, anche diversa da quella in cui vuoi immatricolarti. Trovi date e sedi per sostenere il TOLC sul sito del CISIA.

L’Università di Bologna organizza TOLC solo in presenza presso tutte le proprie sedi (Bologna, Cesena, Forlì, Ravenna, Rimini).

#### Quali TOLC sono validi

Per questo corso sono validi:

- TOLC in presenza (TOLC@UNI) svolti nel 2024 o nel 2025
- TOLC@casa svolti nel 2024 o nel 2025 solo per chi appartiene al contingente “non-UE residenti all’estero” (scopri a quale contingente appartieni).

Cosa fare prima di sostenerlo in presenza Per sostenere il TOLC in presenza, verifica se hai bisogno di un visto per l’Italia. Se hai bisogno di un visto:

### Cosa fare prima di sostenerlo in presenza

Per sostenere il TOLC in presenza, verifica se hai bisogno di un visto per l’Italia.

Se hai bisogno di un visto:

- preiscriviti su Universitaly, indicando questo corso di studio I nostri uffici verificheranno la tua iscrizione alla prova e valideranno preiscrizione;
- se non l'hai già fatto, prendi un appuntamento all'Ambasciata e chiedi quale visto devi ottenere e quali sono i documenti necessari.

Quando sostenerlo Verifica sul portale del CISIA, nel Calendario del TOLC-I , i termini per l’iscrizione al test TOLC che vuoi sostenere.

### Quando sostenerlo

Verifica sul portale del CISIA, nel Calendario del TOLC-I, i termini per l’iscrizione al test TOLC che vuoi sostenere.

- Per la prima selezione sono validi i TOLC-I svolti tra il 1° gennaio 2024 e il 28 aprile 2025
- Per la seconda selezione sono validi i TOLC-I svolti  tra il 1° gennaio 2024 e l'11 luglio 2025
- Per l’eventuale selezione straordinaria sono validi i TOLC-I svolti tra il 1° gennaio 2024 e il 17 settembre 2025

Quando sostenerlo Verifica sul portale del CISIA, nel Calendario del TOLC-I , i termini per l’iscrizione al test TOLC che vuoi sostenere.

### Quando sostenerlo

Verifica sul portale del CISIA, nel Calendario del TOLC-I, i termini per l’iscrizione al test TOLC che vuoi sostenere.

- Per la prima selezione sono validi i TOLC-I svolti tra il 1° gennaio 2024 e il 28 aprile 2025
- Per la seconda selezione sono validi i TOLC-I svolti  tra il 1° gennaio 2024 e l'11 luglio 2025
- Per l’eventuale selezione straordinaria sono validi i TOLC-I svolti tra il 1° gennaio 2024 e il 17 settembre 2025

Quando sostenerlo



Verifica sul portale del CISIA, nel Calendario del TOLC-I, i termini per l’iscrizione al test TOLC che vuoi sostenere.
Per la seconda selezione sono validi i TOLC-I svolti entro l'11 luglio 2025.

Come iscriversi Per sostenere il TOLC è necessario iscriversi con anticipo alle prove, sulla base delle scadenze definite dal CISIA . L'iscrizione avviene online sul sito del CISIA e prevede il versamento di € 35. Verifica sul sito del CISIA:

### Come iscriversi

Per sostenere il TOLC è necessario iscriversi con anticipo alle prove, sulla base delle scadenze definite dal CISIA. 
L'iscrizione avviene online sul sito del CISIA e prevede il versamento di € 35.

Verifica sul sito del CISIA:

- le date e le sedi alle quali puoi già iscriverti
- la scadenza entro la quale devi iscriverti
- i posti disponibili

Adattamenti per persone con disabilità o con DSA



Per chiedere adattamenti per la prova di ammissione devi farne richiesta nel momento in cui fai l’iscrizione su StudentiOnLine. Alla richiesta devi allegare il modulo che trovi su Studenti Online e allegare la documentazione specialistica che attesta lo stato di disabilità o di DSA rilasciata.
Consulta il sito del servizio per avere più informazioni

Come viene valutato Il punteggio ottenuto in ciascuna sezione, non ancora pesato secondo i criteri sopra indicati, viene visualizzato alla fine del TOLC-I e resta disponibile nella tua area riservata sul sito del CISIA . Per calcolare il punteggio col quale comparirai in graduatoria, moltiplica il punteggio ottenuto in ciascuna sezione per il relativo peso e somma i prodotti ottenuti. Come vengono pesate le sezioni: In caso di parità di punteggio (ex aequo), fare riferimento al Bando.

### Come viene valutato

Il punteggio ottenuto in ciascuna sezione, non ancora pesato secondo i criteri sopra indicati, viene visualizzato alla fine del TOLC-I e resta disponibile nella tua area riservata sul sito del CISIA.

Per calcolare il punteggio col quale comparirai in graduatoria, moltiplica il punteggio ottenuto in ciascuna sezione per il relativo peso e somma i prodotti ottenuti.

Come vengono pesate le sezioni:

- Matematica: 1
- Logica: 1,25
- Scienze: 0,5
- Comprensione verbale: 1,25
- Inglese: 0

In caso di parità di punteggio (ex aequo), fare riferimento al Bando.

## Selezione

- Posti disponibili



Per l’ammissione al corso sono disponibili 244 posti.
Nella prima selezione 122 posti sono riservati per soli cittadini comunitari ed equiparati.
Nella seconda selezione 117 posti sono riservati a Comunitari più i posti residui delle precedenti selezioni e 5 posti per cittadini non comunitari residenti all’estero.
- Quando candidarti Puoi candidarti anche prima di aver sostenuto il TOLC, purché tu lo svolga con le modalità ed entro le scadenze previste. Puoi scegliere tra:

### Quando candidarti

Puoi candidarti anche prima di aver sostenuto il TOLC, purché tu lo svolga con le modalità ed entro le scadenze previste.

Puoi scegliere tra:

- Prima selezione: dal 3 marzo 2025 al 29 aprile 2025, ore 13.00
- Seconda selezione: dal 30 aprile 2025 al 14 luglio 2025, ore 13.00
- Eventuale selezione straordinaria: dal 09 settembre 2025 al 18 settembre 2025, ore 13.00

Quando candidarti Puoi candidarti anche prima di aver sostenuto il TOLC, purché tu lo svolga con le modalità ed entro le scadenze previste. Puoi scegliere tra:

### Quando candidarti

Puoi candidarti anche prima di aver sostenuto il TOLC, purché tu lo svolga con le modalità ed entro le scadenze previste.

Puoi scegliere tra:

- Prima selezione: dal 3 marzo 2025 al 29 aprile 2025, ore 13.00
- Seconda selezione: dal 30 aprile 2025 al 14 luglio 2025, ore 13.00
- Eventuale selezione straordinaria: dal 09 settembre 2025 al 18 settembre 2025, ore 13.00

Quando candidarti Puoi candidarti anche prima di aver sostenuto il TOLC, purché tu lo svolga con le modalità ed entro le scadenze previste.

### Quando candidarti

Puoi candidarti anche prima di aver sostenuto il TOLC, purché tu lo svolga con le modalità ed entro le scadenze previste.

- Seconda selezione: dal 30 aprile 2025 al 14 luglio 2025, ore 13.00

Come candidarti Come fare La candidatura è valida solo dopo il versamento del contributo e per la selezione scelta, non per quelle successive. Se vuoi candidarti alla selezione successiva devi ripetere la procedura senza versare nuovamente il contributo. Cosa posso fare se non rientro nei posti disponibili? Se non rientri nei posti utili per l’immatricolazione e vuoi partecipare alla successiva selezione ordinaria e all’eventuale selezione straordinaria: devi candidarti nuovamente, rispettando requisiti, modalità e scadenze indicate nel bando. Non devi pagare di nuovo il contributo di iscrizione alla selezione.

### Come candidarti

### Come fare

1. Accedi e registrati su Studenti Online.
2. Puoi indicare 1 corso nella prima selezione  e fino a due corsi tra quelli previsti nel bando nella 2 e 3 selezione.
La preferenza espressa è vincolante e dopo il termine di presentazione della candidatura non potrai più modificarla.
3. Verifica se devi inviare via e-mail il TOLC alla Segreteria Studenti oppure se è già stato recepito automaticamente
4. Paga il contributo di 20 € attraverso la piattaforma PagoPA. Il contributo è valido per candidarti anche alla selezione ordinaria successiva e all’eventuale selezione straordinaria e non potrà essere in nessun caso rimborsato.

La candidatura è valida solo dopo il versamento del contributo e per la selezione scelta, non per quelle successive. Se vuoi candidarti alla selezione successiva devi ripetere la procedura senza versare nuovamente il contributo.

#### Cosa posso fare se non rientro nei posti disponibili?

Se non rientri nei posti utili per l’immatricolazione e vuoi partecipare alla successiva selezione ordinaria e all’eventuale selezione straordinaria: devi candidarti nuovamente, rispettando requisiti, modalità e scadenze indicate nel bando. Non devi pagare di nuovo il contributo di iscrizione alla selezione.

Come candidarti Come fare La candidatura è valida solo dopo il versamento del contributo e per la selezione scelta, non per quelle successive. Se vuoi candidarti alla selezione successiva devi ripetere la procedura senza versare nuovamente il contributo. Cosa posso fare se non rientro nei posti disponibili? Se non rientri nei posti utili per l’immatricolazione e vuoi partecipare alla successiva selezione ordinaria e all’eventuale selezione straordinaria: devi candidarti nuovamente, rispettando requisiti, modalità e scadenze indicate nel bando. Non devi pagare di nuovo il contributo di iscrizione alla selezione.

### Come candidarti

### Come fare

1. Accedi e registrati su Studenti Online.
2. Puoi indicare 1 corso nella prima selezione  e fino a due corsi tra quelli previsti nel bando nella 2 e 3 selezione.
La preferenza espressa è vincolante e dopo il termine di presentazione della candidatura non potrai più modificarla.
3. Verifica se devi inviare via e-mail il TOLC alla Segreteria Studenti oppure se è già stato recepito automaticamente
4. Paga il contributo di 20 € attraverso la piattaforma PagoPA. Il contributo è valido per candidarti anche alla selezione ordinaria successiva e all’eventuale selezione straordinaria e non potrà essere in nessun caso rimborsato.

La candidatura è valida solo dopo il versamento del contributo e per la selezione scelta, non per quelle successive. Se vuoi candidarti alla selezione successiva devi ripetere la procedura senza versare nuovamente il contributo.

#### Cosa posso fare se non rientro nei posti disponibili?

Se non rientri nei posti utili per l’immatricolazione e vuoi partecipare alla successiva selezione ordinaria e all’eventuale selezione straordinaria:  devi candidarti nuovamente, rispettando requisiti, modalità e scadenze indicate nel bando. Non devi pagare di nuovo il contributo di iscrizione alla selezione.

Come candidarti Come fare La candidatura è valida solo dopo il versamento del contributo.

### Come candidarti

### Come fare

1. Accedi e registrati su Studenti Online.
2. Puoi indicare fino a due corsi tra quelli previsti nel bando.
La preferenza espressa è vincolante e dopo il termine di presentazione della candidatura non potrai più modificarla.
3. Verifica se devi inviare via e-mail il TOLC alla Segreteria Studenti oppure se è già stato recepito automaticamente
4. Paga il contributo di 20 € attraverso la piattaforma PagoPA. Il contributo è valido per candidarti anche alla selezione ordinaria successiva e all’eventuale selezione straordinaria e non potrà essere in nessun caso rimborsato.

La candidatura è valida solo dopo il versamento del contributo.

Verifica della ricezione del TOLC



In alcuni casi, la Segreteria studenti potrebbe non aver ricevuto automaticamente il tuo TOLC (per esempio in caso di dati discordanti nelle registrazioni sul portale CISIA e su Studenti Online). 
Su Studenti Online, nella sezione di dettaglio delle “Richieste in corso”, potrai trovare l’elenco delle candidature con TOLC non ricevuto automaticamente.
Verifica se rientri nell’elenco, in questo caso dovrai inviare il tuo TOLC per e-mail alla Segreteria Studenti.
Nel bando trovi le date, per ogni selezione, in cui verrà pubblicato l’elenco.

## Graduatoria

- Modalità



Per ogni selezione sarà pubblicata una graduatoria su Studenti Online.
Il posizionamento in graduatoria avviene in ordine decrescente, sulla base esclusiva del risultato della pesatura del punteggio TOLC-I secondo i criteri previsti da bando.
- Vincitore Prima selezione Se hai ottenuto un punteggio maggiore o uguale a 18/50 e rientri nei posti disponibili: Seconda ed eventuale selezione straordinaria OFA Verifica, inoltre, se ti viene assegnato un Obbligo Formativo Aggiuntivo in una delle tematiche del Test (OFA) sulla base di quanto indicato nel bando di ammissione. L'OFA non ti impedisce di partecipare al recupero posti.

### Vincitore

### Prima selezione

Se hai ottenuto un punteggio maggiore o uguale a 18/50 e rientri nei posti disponibili:

- procedi all’ “Immatricolazione” secondo le modalità e scadenze indicate nel Bando.

### Seconda ed eventuale selezione straordinaria

- Se hai scelto un solo corso di studi procedi all’ “Immatricolazione”
- Se hai scelto 2 corsi di studi e risulti “Vincitore” nella graduatoria del corso di maggior interesse, non figurerai in quella del corso di riserva. Procedi all’ “Immatricolazione”
- Se hai scelto 2 corsi di studi e risulti “Vincitore” nella graduatoria del corso di riserva, hai due opzioni. Puoi immatricolarti al corso di riserva e, se lo desideri, dichiarare il tuo interesse allo spostamento nel corso di maggior interesse. Se non riuscirai a entrare nel corso di maggior interesse, rimarrà valida la tua immatricolazione a quello di riserva.
Oppure, puoi non immatricolarti al corso di riserva e dichiarare il tuo interesse al recupero nel corso di maggior interesse. In questo caso, non potrai più immatricolarti al corso di riserva nell’ambito della prima selezione ma potrai candidarti nella selezione successiva, nel caso non ottenessi un posto nel corso di prima scelta con il recupero. Trovi tutti i dettagli nel bando.

### OFA

Verifica, inoltre, se ti viene assegnato un Obbligo Formativo Aggiuntivo in una delle tematiche del Test (OFA) sulla base di quanto indicato nel bando di ammissione. L'OFA non ti impedisce di partecipare al recupero posti.

Vincitore Prima selezione Se hai ottenuto un punteggio maggiore o uguale a 18/50 e rientri nei posti disponibili: Seconda ed eventuale selezione straordinaria Verifica, inoltre, se ti viene assegnato un Obbligo Formativo Aggiuntivo in una delle tematiche del Test (OFA) sulla base di quanto indicato nel bando di ammissione. L'OFA non ti impedisce di partecipare al recupero posti.

### Vincitore

### Prima selezione

Se hai ottenuto un punteggio maggiore o uguale a 18/50 e rientri nei posti disponibili:

- procedi all’ “Immatricolazione” secondo le modalità e scadenze indicate nel Bando.

### Seconda ed eventuale selezione straordinaria

- Se hai scelto un solo corso di studi procedi all’ “Immatricolazione”
- Se hai scelto 2 corsi di studi e risulti “Vincitore” nella graduatoria del corso di maggior interesse, non figurerai in quella del corso di riserva. Procedi all’ “Immatricolazione”
- Se hai scelto 2 corsi di studi e risulti “Vincitore” nella graduatoria del corso di riserva, hai due opzioni. Puoi immatricolarti al corso di riserva e, se lo desideri, dichiarare il tuo interesse allo spostamento nel corso di maggior interesse. Se non riuscirai a entrare nel corso di maggior interesse, rimarrà valida la tua immatricolazione a quello di riserva.
Oppure, puoi non immatricolarti al corso di riserva e dichiarare il tuo interesse al recupero nel corso di maggior interesse. In questo caso, non potrai più immatricolarti al corso di riserva nell’ambito della prima selezione ma potrai candidarti nella selezione successiva, nel caso non ottenessi un posto nel corso di prima scelta con il recupero. Trovi tutti i dettagli nel bando.

Verifica, inoltre, se ti viene assegnato un Obbligo Formativo Aggiuntivo in una delle tematiche del Test (OFA) sulla base di quanto indicato nel bando di ammissione. L'OFA non ti impedisce di partecipare al recupero posti.

Vincitore Se rientri nei posti disponibili: OFA Verifica, inoltre, se ti viene assegnato un Obbligo Formativo Aggiuntivo in una delle tematiche del Test (OFA) sulla base di quanto indicato nel bando di ammissione. L'OFA non ti impedisce di partecipare al recupero posti.

### Vincitore

Se rientri nei posti disponibili:

- Se hai scelto un solo corso di studi procedi all’ “Immatricolazione”
- Se hai scelto 2 corsi di studi e risulti “Vincitore” nella graduatoria del corso di maggior interesse, non figurerai in quella del corso di riserva. Procedi all’ “Immatricolazione”
- Se hai scelto 2 corsi di studi e risulti “Vincitore” nella graduatoria del corso di riserva, hai due opzioni. Puoi immatricolarti al corso di riserva e, se lo desideri, dichiarare il tuo interesse allo spostamento nel corso di maggior interesse. Se non riuscirai a entrare nel corso di maggior interesse, rimarrà valida la tua immatricolazione a quello di riserva. 
Oppure, puoi non immatricolarti al corso di riserva e dichiarare il tuo interesse al recupero nel corso di maggior interesse. In questo caso, non potrai più immatricolarti al corso di riserva nell’ambito della prima selezione ma potrai candidarti nella selezione successiva, nel caso non ottenessi un posto nel corso di prima scelta con il recupero. Trovi tutti i dettagli nel bando.

### OFA

Verifica, inoltre, se ti viene assegnato un Obbligo Formativo Aggiuntivo in una delle tematiche del Test (OFA) sulla base di quanto indicato nel bando di ammissione. L'OFA non ti impedisce di partecipare al recupero posti.

Idoneo



Se hai ottenuto un punteggio maggiore o uguale a 18/50, ma non rientri nei posti disponibili.
Puoi dichiarare il tuo interesse al “Recupero posti”.
Se non ottieni un posto con il recupero, potrai candidarti alla selezione successiva, se prevista.

Non idoneo



Se non hai ottenuto un punteggio maggiore o uguale a 18/50 nella prima selezione,
potrai candidarti alla selezione successiva.

Recupero posti o spostamento al corso di maggiore interesse



Per ogni selezione, i posti eventualmente rimasti disponibili vengono rimessi a disposizione di chi dichiara il proprio interesse al recupero o allo spostamento al corso di maggiore interesse.
Il recupero o lo spostamento non sono automatici: devi dichiararne su Studenti Online l’interesse per ogni selezione. 
Una volta dichiarato, l’interesse è irrevocabile e non può essere modificato.
Nel bando trovi le indicazioni su requisiti, modalità e tempistiche con cui fare la dichiarazione di interesse.

## Immatricolazione

- Come immatricolarti



Accedi a Studenti Online, compila la richiesta di immatricolazione e paga la prima rata delle tasse o in alternativa la monorata secondo le modalità indicate. Se non effettui il pagamento, secondo le modalità previste, verrai escluso dalla procedura. Inoltre, non sono ammessi pagamenti tardivi con mora.
- Preiscrizione su Universitaly



Dopo aver superato il TOLC ed essere risultato vincitore in graduatoria, se non l'hai ancora fatto, presenta online la domanda di preiscrizione su Universitaly, che ti servirà per richiedere il visto d'ingresso.
Nella domanda indica questo corso. Leggi la  Guida e le FAQ [.pdf 730 KB] per capire come compilare la domanda. 
Se hai superato il TOLC, sei risultato vincitore in graduatoria e hai pagato la prima rata entro i termini perentori del bando, gli uffici valideranno la preiscrizione.
Scarica il riepilogo della domanda e presentalo all'Ambasciata o al Consolato per richiedere il visto.
Se hai la necessità di cambiare il corso di studio o l’Università che hai inserito nella domanda di preiscrizione, leggi le informazioni su cambio di preiscrizione e riassegnazione.
Gli uffici dell’Università di Bologna potrebbero essere chiusi per un periodo in agosto durante il quale non vengono validate preiscrizioni, quindi nel mese di agosto i tempi validazione delle preiscrizioni potrebbero allungarsi.
Se la tua Ambasciata o Consolato richiede che la tua preiscrizione sia validata senza riserva, vai alla sezione di questa pagina "Attivazione della carriera e badge" e leggi come fare.
Ricordati che la preiscrizione non consente di per sé l’ammissione al corso. Per immatricolarti devi anche sostenere e superare le verifiche dei requisiti di accesso e la prova di ammissione previsti dal corso.
L’Università di Bologna non rilascia lettere di idoneità accademica per l’ottenimento del visto.
Il visto di ingresso per turismo non può essere utilizzato per l’iscrizione all’università o per ottenere un permesso di soggiorno per studio.
- Richiesta del visto e copertura sanitaria Per richiedere il visto devi necessariamente attivare una copertura sanitaria . Dall'arrivo in Italia e per tutto il tuo soggiorno è necessario essere coperti da un'assicurazione sanitaria privata o dal Servizio Sanitario Nazionale italiano. Potrai iscriverti al Servizio Sanitario Nazionale italiano solo dopo l'arrivo in Italia. Se intendi farlo, puoi valutare di acquistare un'assicurazione privata breve per coprire il viaggio e il primo periodo in Italia (salvo diverse indicazioni dell'Ambasciata per il visto). Se non intendi farlo, puoi valutare di acquistare un'assicurazione privata più lunga (almeno 1 anno). Visto di ingresso per "studio/immatricolazione università" Se non hai ancora un visto di lunga durata, prendi un appuntamento all'Ambasciata o al Consolato e porta con te: All'Ambasciata o al Consolato devi ottenere un visto per “studio – immatricolazione università”, i documenti che hai richiesto ed eventualmente il codice fiscale italiano .

### Richiesta del visto e copertura sanitaria

Per richiedere il visto devi necessariamente attivare una copertura sanitaria.

Dall'arrivo in Italia e per tutto il tuo soggiorno è necessario essere coperti da un'assicurazione sanitaria privata o dal Servizio Sanitario Nazionale italiano. Potrai iscriverti al Servizio Sanitario Nazionale italiano solo dopo l'arrivo in Italia. Se intendi farlo, puoi valutare di acquistare un'assicurazione privata breve per coprire il viaggio e il primo periodo in Italia (salvo diverse indicazioni dell'Ambasciata per il visto). Se non intendi farlo, puoi valutare di acquistare un'assicurazione privata più lunga (almeno 1 anno).

### Visto di ingresso per "studio/immatricolazione università"

Se non hai ancora un visto di lunga durata, prendi un appuntamento all'Ambasciata o al Consolato e porta con te:

- il riepilogo della domanda di preiscrizione su Universitaly validata dall’Università di Bologna;
- il documento attestante le risorse economiche necessarie alla permanenza in Italia (minimo richiesto per il 2024: € 6.947,33). Puoi consegnare, per esempio, l'estratto del conto corrente bancario o postale;
- gli eventuali certificati per il requisito di lingua del corso;
- l'eventuale assicurazione sanitaria;
- i moduli dell'agenzia delle entrate per richiedere il codice fiscale italiano. Trovi i moduli sul sito dell'Ambasciata o del Consolato se offre il servizio;
- il titolo di studio per tradurlo, legalizzarlo e autenticarlo, se necessario e se il servizio è previsto;
- l'eventuale documentazione per ottenere agevolazioni economiche

All'Ambasciata o al Consolato devi ottenere un visto per “studio – immatricolazione università”, i documenti che hai richiesto ed eventualmente il codice fiscale italiano.

Validazione dell'identità Validare la tua identità vuol dire associare l’account nome.cognome@studio.unibo.it alla tua identità. Cosa fare La tua identità sarà automaticamente validata , senza che tu debba fare nulla, in uno di questi casi: Se non rientri in una delle condizioni indicate sopra e non puoi avere le credenziali SPID, perché sei minorenne o risiedi all’estero, contatta la segreteria studenti o, se hai la residenza all’estero e hai un titolo di studio estero, la segreteria studenti internazionale.

### Validazione dell'identità

Validare la tua identità vuol dire associare l’account nome.cognome@studio.unibo.it alla tua identità.

### Cosa fare

La tua identità sarà automaticamente validata, senza che tu debba fare nulla, in uno di questi casi:

- possiedi le credenziali SPID e accedi con queste a Studenti Online almeno una volta;
- possiedi la carta di identità elettronica e accedi a Studenti Online tramite il percorso Entra con CIE;
- hai già fatto parte della comunità studentesca dell’Università di Bologna, dal 2004 in avanti;
- hai sostenuto una prova scritta o orale, anche a distanza, presso l’Ateneo di Bologna (ad esclusione di TOLC e prove di selezioni per concorsi nazionali).

Se non rientri in una delle condizioni indicate sopra e non puoi avere le credenziali SPID, perché sei minorenne o risiedi all’estero, contatta la segreteria studenti o, se hai la residenza all’estero e hai un titolo di studio estero, la segreteria studenti internazionale.

Attivazione della carriera e badge



L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi.
La tua carriera sarà automaticamente attivata dopo l'identificazione

Non è attiva automaticamente se:
hai conseguito il titolo di studio all’estero:  devi presentare il tuo titolo di studio alla segreteria studenti internazionali del Campus in cui andrai a studiare. Raccogli tutta la documentazione necessaria sul tuo titolo di studio; accedi a Studenti Online nella sezione “Bandi”, seleziona “Immatricolazione a.a. 25\_26- caricamento dei documenti degli studenti internazionali e con titolo estero” e carica i documenti di studio elencati. Prenota un appuntamento presso la Segreteria studenti internazionali per mostrare i documenti in originale;
non hai ancora conseguito il diploma: non appena ti diplomerai, collegati a Studenti Online e completa le informazioni sul voto. Ricorda che il titolo deve essere conseguito entro il 31 dicembre 2025, altrimenti l’immatricolazione sarà annullata.
sei ancora minorenne al momento dell'immatricolazione compila il modulo di consenso genitoriale e invialo, compilato e firmato dai tuoi genitori, all’indirizzo email della segreteria studenti del corso che hai scelto.
La carriera deve essere attivata entro il 26 febbraio 2026.
Appena la carriera sarà attivata riceverai un’email con le istruzioni per stampare il badge.

Attivazione della carriera e badge L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi. La tua carriera sarà automaticamente attivata dopo la validazione della tua identità. Non è attiva automaticamente se: hai la cittadinanza di un Paese non-UE, ma possiedi un titolo di equiparazione e hai conseguito il titolo di studio in Italia : invia per email alla segreteria studenti del tuo corso la copia del permesso di soggiorno che consente l’equiparazione; hai la cittadinanza di un Paese non-UE, ma possiedi un titolo di equiparazione e hai conseguito il titolo di studio all’estero : presenta il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare: hai la cittadinanza di un Paese UE e hai conseguito il titolo di studio all’estero : presenta il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare: non hai ancora conseguito il diploma: non appena ti diplomerai, collegati a Studenti Online e completa le informazioni sul voto. Ricorda che il titolo deve essere conseguito entro il 31 dicembre 2025, altrimenti l’immatricolazione sarà annullata. sei ancora minorenne al momento dell'immatricolazione compila il modulo di consenso genitoriale e invialo, compilato e firmato dai tuoi genitori, all’indirizzo email della segreteria studenti del corso che hai scelto. La carriera deve essere attivata entro il 26 febbraio 2026. Appena la carriera sarà attivata riceverai un’email con le istruzioni per stampare il badge.

### Attivazione della carriera e badge

L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi.

La tua carriera sarà automaticamente attivata dopo la validazione della tua identità.

Non è attiva automaticamente se:

hai la cittadinanza di un Paese non-UE, ma possiedi un titolo di equiparazione e hai conseguito il titolo di studio in Italia: invia per email alla segreteria studenti del tuo corso la copia del permesso di soggiorno che consente l’equiparazione;

hai la cittadinanza di un Paese non-UE, ma possiedi un titolo di equiparazione e hai conseguito il titolo di studio all’estero: presenta il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare:

- raccogli tutta la documentazione necessaria sul tuo titolo di studio;
- accedi a Studenti Online;
- se non lo hai ancora fatto, e sei ancora in tempo, paga la prima rata delle tasse;
- vai nella sezione "Bandi", cerca il bando "Immatricolazione a.a. 25\_26 - caricamento dei documenti degli studenti internazionali e con titolo estero";
- carica i documenti richiesti e il permesso di soggiorno che consente l’equiparazione.
La Segreteria studenti internazionali controllerà i documenti. 
Prenota un appuntamento presso la segreteria studenti internazionali per mostrare i documenti in originale. 
Al tuo arrivo in Italia, vai all’appuntamento e porta con te i documenti relativi al tuo titolo di studio e il passaporto.

hai la cittadinanza di un Paese UE e hai conseguito il titolo di studio all’estero: presenta il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare:

- raccogli tutta la documentazione necessaria sul tuo titolo di studio;
- accedi a Studenti Online;
- se non lo hai ancora fatto, e sei ancora in tempo, paga la prima rata delle tasse;
- vai nella sezione "Bandi", cerca il bando "Immatricolazione a.a. 25\_26 - caricamento dei documenti degli studenti internazionali e con titolo estero";
- carica i documenti richiesti.
La segreteria studenti internazionali controllerà i documenti. 
Prenota un appuntamento presso la segreteria studenti internazionali per mostrare i documenti in originale. All’appuntamento porta con te i documenti relativi al tuo titolo di studio e il documento di identità.

non hai ancora conseguito il diploma: non appena ti diplomerai, collegati a Studenti Online e completa le informazioni sul voto. Ricorda che il titolo deve essere conseguito entro il 31 dicembre 2025, altrimenti l’immatricolazione sarà annullata.

sei ancora minorenne al momento dell'immatricolazione compila il modulo di consenso genitoriale e invialo, compilato e firmato dai tuoi genitori, all’indirizzo email della segreteria studenti del corso che hai scelto.

La carriera deve essere attivata entro il 26 febbraio 2026.

Appena la carriera sarà attivata riceverai un’email con le istruzioni per stampare il badge.

Attivazione della carriera e badge L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi. Se hai conseguito il titolo di studio all’estero devi presentare il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare: Se hai bisogno della validazione senza riserva su Universitaly segnalalo per e-mail alla Segreteria Studenti Internazionali. La Segreteria studenti internazionali controllerà i documenti. Se sono completi e se sarà possibile verificarne l’autenticità e il valore, validerà la tua preiscrizione su Universitaly senza riserva. Prenota un appuntamento presso la segreteria studenti internazionali per mostrare i documenti in originale.Al tuo arrivo in Italia, vai all’appuntamento e porta con te i documenti relativi al tuo titolo di studio e il passaporto. Se i documenti sono completi, la segreteria ti darà un certificato di iscrizione. Successivamente dovrai inviare per e-mail la ricevuta della richiesta del permesso di soggiorno alla segreteria studenti internazionali per attivare la carriera. La tua immatricolazione sarà accolta con riserva fino a quando non ti verrà consegnato il permesso di soggiorno e ne invierai una copia alla segreteria studenti. Se hai la cittadinanza di un Paese non-UE, risiedi all’estero, ma hai un titolo italiano conseguito in Italia, contatta la segreteria studenti internazionali del tuo campus per sapere come fare. Se sei ancora minorenne al momento dell'immatricolazione compila il modulo di consenso genitoriale e invialo, compilato e firmato dai tuoi genitori, all’indirizzo email della segreteria studenti del corso che hai scelto. La carriera deve essere attivata entro il 26 febbraio 2026. Appena la carriera sarà attivata riceverai un’e-mail con le istruzioni per stampare il badge.

### Attivazione della carriera e badge

L’attivazione della carriera è necessaria per compilare il piano di studi, prenotare e sostenere esami, fare passaggi di corso, trasferirsi ad altra Università, rinunciare o sospendere gli studi, laurearsi, stampare certificati. È necessaria anche per utilizzare alcuni servizi, come ad esempio l’accesso alle risorse bibliotecarie online e alla rete wi-fi.

Se hai conseguito il titolo di studio all’estero devi presentare il tuo titolo di studio alla segreteria studenti internazionali del campus in cui andrai a studiare:

- raccogli tutta la documentazione necessaria sul tuo titolo di studio;
- accedi a Studenti Online;
- se non lo hai ancora fatto, e sei ancora in tempo, paga la prima rata delle tasse;
- vai nella sezione "Bandi", cerca il bando "Immatricolazione a.a. 25\_26 - caricamento dei documenti degli studenti internazionali e con titolo estero";
- carica i documenti richiesti e, se lo possiedi già, il visto di ingresso per motivi di studio.

Se hai bisogno della validazione senza riserva su Universitaly segnalalo per e-mail alla Segreteria Studenti Internazionali. La Segreteria studenti internazionali controllerà i documenti. Se sono completi e se sarà possibile verificarne l’autenticità e il valore, validerà la tua preiscrizione su Universitaly senza riserva.

Prenota un appuntamento presso la segreteria studenti internazionali per mostrare i documenti in originale.
Al tuo arrivo in Italia, vai all’appuntamento e porta con te i documenti relativi al tuo titolo di studio e il passaporto. Se i documenti sono completi, la segreteria ti darà un certificato di iscrizione.

Successivamente dovrai inviare per e-mail la ricevuta della richiesta del permesso di soggiorno alla segreteria studenti internazionali per attivare la carriera. La tua immatricolazione sarà accolta con riserva fino a quando non ti verrà consegnato il permesso di soggiorno e ne invierai una copia alla segreteria studenti.

Se hai la cittadinanza di un Paese non-UE, risiedi all’estero, ma hai un titolo italiano conseguito in Italia, contatta la segreteria studenti internazionali del tuo campus per sapere come fare.

Se sei ancora minorenne al momento dell'immatricolazione compila il modulo di consenso genitoriale e invialo, compilato e firmato dai tuoi genitori, all’indirizzo email della segreteria studenti del corso che hai scelto.

La carriera deve essere attivata entro il 26 febbraio 2026.
Appena la carriera sarà attivata riceverai un’e-mail con le istruzioni per stampare il badge.

Permesso di soggiorno e copertura sanitaria Iscrizione al Servizio Sanitario Nazionale italiano (SSN) Per iscriverti al SSN occorre pagare la quota annuale. Se richiedi o possiedi un permesso di soggiorno per motivi di studio, dal 2024 il costo minimo è di 700€ all’anno. L’iscrizione è fatta solo per anno solare (es. dal 1 gennaio 2024 al 31 dicembre 2024) e non è possibile pagare quote ridotte per periodi più brevi. È consentito pagare l’iscrizione per l’anno corrente e anche per l’intero anno solare successivo (es. 2024 e 2025). Questa possibilità ti permette di avere la copertura sanitaria per un anno accademico ed è utile se arrivi, ad esempio, a settembre e intendi chiedere un permesso di soggiorno per studio valido un anno. Per la copertura di eventuali familiari a carico l’importo del contributo minimo è di 2000 euro all’anno. Iscriviti ad uno Sportello Unico dell’AUSL (CUP) e porta con te: Chiedi le informazioni per effettuare il pagamento per "l’iscrizione volontaria per studenti". Il pagamento devi farlo tramite il modello F24 ordinario e le parti da compilare sono: Paga il contributo annuale presentando il modello F24 per ciascun anno di iscrizione al SSN presso gli uffici postali, gli sportelli bancari, online tramite il tuo conto corrente o carte Pagobancomat, Postepay o Postamat e conserva le ricevute di pagamento. Fai una copia delle ricevute di pagamento e allegale alla tua domanda di primo rilascio o di rinnovo del permesso di soggiorno. Il solo pagamento non implica l’attivazione della copertura. Devi completare l’iscrizione presso un ufficio dell’AUSL e scegliere un medico di base. Fai domanda per il Permesso di soggiorno Entro otto giorni dall'arrivo in Italia presenta la domanda per ottenere il permesso . Lo puoi fare in autonomia oppure con il nostro supporto.Invia per e-mail la ricevuta della richiesta del permesso di soggiorno alla tua Segreteria studenti internazionali. Ricordati che il permesso di soggiorno va rinnovato ogni anno . Attiva la copertura sanitaria e scegli il medico di base Dopo aver inviato la domanda di permesso di soggiorno, ritorna il più presto possibile allo Sportello Unico (CUP) per attivare la copertura sanitaria e scegliere un medico di base. Porta con te: Se paghi per due anni consecutivi, ricordati che alla fine dell’anno in corso devi tornare al CUP con la ricevuta di pagamento per l’anno successivo, e chiedere l’attivazione del servizio. Verifica sempre la data di fine copertura.Riceverai per posta una Tessera sanitaria e verrà spedita all’indirizzo che hai comunicato all’Agenzia delle Entrate. Puoi contattare l’Agenzia delle Entrate per l’aggiornamento del tuo indirizzo ed eventualmente per richiedere la ristampa della tessera.

### Permesso di soggiorno e copertura sanitaria

#### Iscrizione al Servizio Sanitario Nazionale italiano (SSN)

Per iscriverti al SSN occorre pagare la quota annuale. Se richiedi o possiedi un permesso di soggiorno per motivi di studio, dal 2024 il costo minimo è di 700€ all’anno. L’iscrizione è fatta solo per anno solare (es. dal 1 gennaio 2024 al 31 dicembre 2024) e non è possibile pagare quote ridotte per periodi più brevi.

È consentito pagare l’iscrizione per l’anno corrente e anche per l’intero anno solare successivo (es. 2024 e 2025). Questa possibilità ti permette di avere la copertura sanitaria per un anno accademico ed è utile se arrivi, ad esempio, a settembre e intendi chiedere un permesso di soggiorno per studio valido un anno. Per la copertura di eventuali familiari a carico l’importo del contributo minimo è di 2000 euro all’anno.

Iscriviti ad uno Sportello Unico dell’AUSL (CUP) e porta con te:

- il passaporto;
- il codice fiscale ufficiale italiano;
- il certificato di iscrizione all’Università di Bologna;
- per gli Sportelli Unici (CUP) di Bologna, il modulo di iscrizione volontaria [.pdf 967 KB].  Un esempio con le istruzioni per la compilazione [.pdf 371 KB].

Chiedi le informazioni per effettuare il pagamento per "l’iscrizione volontaria per studenti". Il pagamento devi farlo tramite il modello F24 ordinario e le parti da compilare sono:

- "contribuente" indica i tuoi dati anagrafici;
- "sezione regioni" indica il codice regione 06 (Emilia-Romagna) e il codice tributo 8846;
- anno di riferimento: l’anno solare in cui vuoi iscriverti al SSN (es. 2024);
- importi a debito versati: 700 €, se non hai altri redditi oltre alla borsa di studio e non vuoi includere nella copertura i tuoi famigliari. Se vuoi iscriverti per due anni consecutivi (es. 2024 e 2025), devi fare due pagamenti.

Paga il contributo annuale presentando il modello F24 per ciascun anno di iscrizione al SSN presso gli uffici postali, gli sportelli bancari, online tramite il tuo conto corrente o carte Pagobancomat, Postepay o Postamat e conserva le ricevute di pagamento.

Fai una copia delle ricevute di pagamento e allegale alla tua domanda di primo rilascio o di rinnovo del permesso di soggiorno.

#### Fai domanda per il Permesso di soggiorno

Entro otto giorni dall'arrivo in Italia presenta la domanda per ottenere il permesso. Lo puoi fare in autonomia oppure con il nostro supporto.
Invia per e-mail la ricevuta della richiesta del permesso di soggiorno alla tua Segreteria studenti internazionali. Ricordati che il permesso di soggiorno va rinnovato ogni anno.

#### Attiva la copertura sanitaria e scegli il medico di base

Dopo aver inviato la domanda di permesso di soggiorno, ritorna il più presto possibile allo Sportello Unico (CUP) per attivare la copertura sanitaria e scegliere un medico di base. Porta con te:

- le ricevute di pagamento del contributo annuale;
- la ricevuta postale della domanda di permesso di soggiorno (o il permesso di soggiorno se già ottenuto);
- il certificato di iscrizione all’Università di Bologna o, se sei studente o studentessa di scambio, la Dichiarazione di arrivo.

Se paghi per due anni consecutivi, ricordati che alla fine dell’anno in corso devi tornare al CUP con la ricevuta di pagamento per l’anno successivo, e chiedere l’attivazione del servizio. Verifica sempre la data di fine copertura.
Riceverai per posta una Tessera sanitaria e verrà spedita all’indirizzo che hai comunicato all’Agenzia delle Entrate.

Puoi contattare l’Agenzia delle Entrate per l’aggiornamento del tuo indirizzo ed eventualmente per richiedere la ristampa della tessera.

## Bando di ammissione al Corso

- Bando Bando per l’ammissione ai corsi di laurea dell’ambito Ingegneria e Scienze a.a. 2025-26
        
          [.pdf
          1408Kb]

<!-- image -->

Ti vuoi trasferire?

Sei di un altro Ateneo e vuoi trasferirti all'Unibo.

<!-- image -->

Vuoi cambiare corso?

Segui le tue passioni e scopri come puoi cambiare.

- Sosteniamo il diritto alla conoscenza