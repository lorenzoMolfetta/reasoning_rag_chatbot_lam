# Segreteria e uffici

## SEGRETERIA STUDENTI

La Segreteria si occupa della gestione delle carriere degli studenti iscritti al Corso. 
In particolare, cura tutte le attività amministrative: dall'immatricolazione ai trasferimenti da e per altri corsi di studi, dal rilascio di certificati e duplicati al controllo delle tasse universitarie, dalla domanda di ammissione all'esame di laurea e al rilascio della pergamena di laurea.

## UFFICIO GESTIONE CDS IN INGEGNERIA, SCIENZE E ARCHITETTURA

L'Ufficio coordina e presidia le attività riferite al funzionamento dei corsi di studio e l'organizzazione delle attività didattiche a supporto di studenti e docenti. STAFF: Alberto Alvisi, Rita Baldrati, Fabio Grotti, Romina Mingozzi, Maria Smurro.

## UFFICIO RELAZIONI INTERNAZIONALI E TIROCINI - SERVIZIO TIROCINI

L’Ufficio favorisce esperienze di completamento del percorso formativo da parte degli studenti ed esperienze di graduale inserimento nel mondo del lavoro da parte di laureandi e laureati attraverso la promozione, l’organizzazione e la gestione di attività di stage e tirocinio curriculare e post-lauream, incluso il tirocinio a carattere professionalizzante, in collaborazione con i soggetti convenzionati e con le Strutture didattiche presenti a Cesena.

L’Ufficio, in particolare, sviluppa e approfondisce i rapporti con le Aziende, gli Enti locali e le Associazioni presenti sul territorio, per facilitare l'ingresso dei laureati nel mondo del lavoro.

## UFFICIO RELAZIONI INTERNAZIONALI E TIROCINI  - SERVIZIO RELAZIONI INTERNAZIONALI

L'Ufficio Relazioni Internazionali collabora con l’Area Relazioni Internazionali di Ateneo nella gestione dei programmi di mobilità internazionale, fornisce informazioni sulle opportunità di studio, tirocinio e formazione all'estero per gli studenti iscritti ai corsi di studio afferenti al Campus di Cesena. L’ufficio inoltre, accoglie e supporta gli studenti stranieri in scambio, gli studenti internazionali e i docenti/personale amministrativo in visita presso la sede di Cesena.

- Sosteniamo il diritto alla conoscenza