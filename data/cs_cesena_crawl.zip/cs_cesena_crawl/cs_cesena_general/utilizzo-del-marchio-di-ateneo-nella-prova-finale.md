# Utilizzo del marchio di Ateneo nella prova finale

## Cosa devo sapere

Il nuovo Regolamento per l'uso del Marchio dell'Ateneo ti consente di inserire il marchio sulla copertina e sul frontespizio della prova finale. Ogni altro uso che non rientri in questi è vietato.

## Come posso utilizzare il marchio di Ateneo

Se desideri inserire il marchio di Ateneo, dovrai seguire la normativa grafica prevista dal Sistema di Identità, utilizzando il modello copertina e il modello frontespizio che si trovano in allegato.

Questi modelli indicano:

- la posizione esatta, le dimensioni e il colore del Marchio sul frontespizio
- la posizione e la dimensione sulla copertina.

Se la copertina è di colore scuro puoi utilizzare eccezionalmente il marchio in colore oro o argento.

## Come inserire le altre informazioni del frontespizio e copertina

Le altre informazioni come la struttura di appartenenza, la denominazione del corso di studio, titolo della tesi, nome del relatore o della relatrice, del correlatore o della correlatrice e del candidato o della candidata, la sessione di laurea e anno accademico, sono personalizzabili e devono seguire le indicazioni formali fornite dai corsi, dove presenti.

### In evidenza

- Copertina

[
          .docx
          76Kb
          ]
- Frontespizio

[
          .docx
          77Kb
          ]

- Sosteniamo il diritto alla conoscenza