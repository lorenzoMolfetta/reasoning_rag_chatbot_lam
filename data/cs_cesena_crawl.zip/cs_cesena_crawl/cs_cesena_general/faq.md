# Classi L-8 - Ingegneria dell'Informazione e  L-31 - Scienze e Tecnologie Informatiche

Risposte a domande frequenti

- Cos'è un corso di studio inter-classe?

Sulla base della propria offerta formativa, i corsi di studio sono riuniti in classi. Solitamente un corso di studio appartiene a una sola classe; il corso in Ingegneria e Scienze Informatiche appartiene sia alla classe dei corsi in Scienze Informatiche, sia alla classe dei corsi in Ingegneria Informatica in quanto soddisfa i vincoli di entrambe ed è caratterizzato da un'offerta formativa più ampia che permetterà agli studenti di avere una visione più completa dell'informatica. In Italia il corso in Ingegneria e Scienze Informatiche è uno dei primi a offrire questa opportunità.
- In che cosa mi laureo una volta finiti gli esami?

Il titolo di studio rilasciato è Dottore in Ingegneria e Scienze Informatiche, ma lo studente può liberamente scegliere a quale delle due classi afferire (Ingegneria o Scienze); la scelta viene fatta al primo anno, ma può essere rivista al massimo fino al momento dell'iscrizione al terzo anno quando una conoscenza più approfondita della materia permette una decisione piu consapevole.
- Si è ingegneri solo scegliendo la classe di laurea in Ingegneria dell'Informazione o anche scegliendo quella in Scienze e tecnologie informatiche?

Si diventa ingegneri quando si è superato l'esame di Stato a cui si può accedere con entrambe le classi di laurea.

- Sosteniamo il diritto alla conoscenza